---
name: ds-module-imports
description: Import-path reference (code-level only — nothing checkable on the rendered page)
---

# Module Import Reference

## Manual review
- All cal-* imports must come from their @calypso-webcore/components module subpaths
- After migration, run a build to catch missing module imports (code-level)
