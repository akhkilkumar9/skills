---
name: ds-apply
description: Calypso Design System core rules — cal-* components, Material replacements, typography
---

# Calypso Design System — Core

## Typography & targets
- min-font-size: 12px
- min-target-size: 24x24

## Component usage
- forbidden-element: button:not(cal-button button):not(cal-button):not([mat-icon-button]) → cal-button
- forbidden-element: select:not(cal-single-dropdown select):not(cal-multi-dropdown select):not(mat-form-field select) → cal-single-dropdown or cal-multi-dropdown
- forbidden-element: textarea:not(cal-textarea textarea):not(mat-form-field textarea) → cal-textarea
- forbidden-element: hr → cal-divider
- forbidden-element: mat-icon:not(cal-icon mat-icon):not(cal-button mat-icon) → cal-icon
- forbidden-element: i[class*="fa-"] → cal-icon
- forbidden-element: span[class*="glyphicon"] → cal-icon
- forbidden-element: mat-checkbox → cal-checkbox
- forbidden-element: mat-slide-toggle → cal-toggle
- forbidden-element: mat-form-field:not([appearance="outline"]) → mat-form-field with appearance="outline"
- forbidden-element: .toast → cal-notification-msg
- forbidden-element: .alert:not(cal-notification-msg .alert) → cal-notification-msg
- forbidden-element: .badge:not(cal-badge):not(cal-badge .badge) → cal-badge
- require-attr: cal-button[appearance="icon"] → ariaLabel
- require-within: cal-chip → mat-chip-set

## Manual review
- Imports must use @calypso-webcore/components subpaths (code-level, not visible on the page)
- No confirm() or MatSnackBar in TypeScript — use cal-notification-msg (code-level)
- Body text should follow the DS type scale (14px base) — check off-scale sizes like 13/15/17px
