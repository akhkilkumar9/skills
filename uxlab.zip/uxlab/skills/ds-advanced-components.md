---
name: ds-advanced-components
description: Steppers, trees, tabs, carousels — DS replacements for Material or custom builds
---

# Calypso Design System — Advanced Components

## Component usage
- forbidden-element: mat-stepper → the DS stepper pattern
- forbidden-element: mat-horizontal-stepper → the DS stepper pattern
- forbidden-element: mat-vertical-stepper → the DS stepper pattern
- forbidden-element: mat-tree → the DS tree-view pattern
- forbidden-element: mat-tab-group:not(cal-tab-group mat-tab-group) → the DS tabs component

## Manual review
- Carousels / rotating banners must use the DS carousel reference (transform-based sliders are heuristic)
- AI chat panels and template pickers follow the advanced-components reference (judgment call)
