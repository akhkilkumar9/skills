---
name: ds-tables
description: Calypso Design System table rules — cal-table over raw or Material tables
---

# Calypso Design System — Tables

## Component usage
- forbidden-element: table:not(cal-table table):not(mat-table):not([mat-table]) → cal-table
- forbidden-element: mat-table → cal-table
- forbidden-element: [mat-table] → cal-table
- forbidden-element: mat-paginator:not(cal-table mat-paginator) → cal-table built-in pagination
- forbidden-element: ag-grid-angular → cal-table

## Manual review
- Preserve existing sort/filter/selection behavior when migrating to cal-table (code-level)
- Empty grids must show the cal-table no-data placeholder with a helpful message
- Column order and default sort must match the legacy screen spec
