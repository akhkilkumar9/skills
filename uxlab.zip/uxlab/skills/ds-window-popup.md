---
name: ds-window-popup
description: Window/popup navigation rules (mostly code-level — manual review)
---

# Window & Popup Reference

## Component usage
- forbidden-element: a[target="_blank"]:not([rel*="noopener"]) → add rel="noopener"

## Manual review
- Routes opened via window.open() must follow the DS window-popup reference (code-level)
- Same-tab vs new-tab behavior must match the legacy screen spec
