/**
 * index.js — the UX Workbench local server.
 * Serves the UI from /public and a small local API:
 *   GET  /api/overview             — aggregated dashboard data (reads stored results only)
 *   POST /api/analyze              — run a UX Audit (optionally only some categories)
 *   GET  /api/reports/:id          — a saved audit report
 *   GET  /api/patterns             — pattern index
 *   POST /api/patterns/extract     — deep-scan a URL (layout, grid metrics, labels)
 *   POST /api/patterns/save        — save the reviewed pattern as markdown + sidecar
 *   GET  /api/patterns/:id/data    — structured pattern data (for re-editing)
 *   GET  /api/patterns/:id/file    — the raw markdown pattern file
 *   POST /api/patterns/:id/prompt  — compose (and record) the apply prompt
 * Runs 100% locally. No telemetry, no external requests, no AI.
 */

const express = require('express');
const path = require('path');
const { analyze } = require('./analyzer');
const { extractPattern } = require('./pattern-extractor');
const { syncLibrary, getProgress } = require('./library-sync');
const store = require('../src/engine/store');
const overview = require('../src/engine/overview');
const patternFormat = require('../templates/pattern-format');

const app = express();
const PORT = process.env.PORT || 5000;
store.ensureDirs();

app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
  res.setHeader('Access-Control-Allow-Private-Network', 'true');
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  next();
});
app.use(express.json({ limit: '2mb' }));
app.use(express.static(path.join(__dirname, '..', 'public')));
app.use('/patterns', express.static(store.PATTERNS_DIR)); // thumbnails + .md files
app.use('/library', express.static(store.LIBRARY_DIR));   // component screenshots + JSON

app.get('/api/health', (req, res) => res.json({ ok: true }));

/* ---- Overview: read-only aggregation, never runs analysis ---- */
app.get('/api/overview', (req, res) => res.json(overview.buildOverview()));

/* ---- UX Audit ---- */
let busy = false; // one browser job at a time keeps things predictable
app.post('/api/analyze', async (req, res) => {
  const url = (req.body && req.body.url || '').trim();
  const lenses = Array.isArray(req.body && req.body.lenses) ? req.body.lenses : null;
  if (!/^https?:\/\//i.test(url)) {
    return res.status(400).json({ error: 'Please enter a full URL starting with http:// or https:// (e.g. http://localhost:4200/trades).' });
  }
  if (busy) return res.status(409).json({ error: 'Another browser job is already running — give it a moment and try again.' });
  busy = true;
  console.log('[ux-workbench] Auditing ' + url + ' (' + (lenses && lenses.length ? lenses.join(', ') : 'all categories') + ') …');
  try {
    const report = await analyze(url, lenses);
    store.saveReport(report);
    console.log('[ux-workbench] Done in ' + Math.round(report.durationMs / 1000) + 's — ' + report.issues.length + ' issue(s), score ' + report.overall);
    res.json(report);
  } catch (e) {
    console.error('[ux-workbench] Audit failed:', e.message);
    res.status(500).json({ error: friendly(e, url) });
  } finally {
    busy = false;
  }
});

app.get('/api/reports/:id', (req, res) => {
  const report = store.getReport(req.params.id);
  if (!report) return res.status(404).json({ error: 'Report not found.' });
  res.json(report);
});

/* ---- Pattern Generator ---- */
app.get('/api/patterns', (req, res) => res.json(store.listPatterns()));

/** Capture: extract the layout, save the Copilot-readable JSON + thumbnail in one step. */
app.post('/api/patterns', async (req, res) => {
  const url = (req.body && req.body.url || '').trim();
  const name = (req.body && req.body.name || '').trim();
  if (!/^https?:\/\//i.test(url)) return res.status(400).json({ error: 'Please enter a full URL starting with http:// or https://.' });
  if (!name) return res.status(400).json({ error: 'Give the pattern a short name (e.g. "Dense trade blotter").' });
  if (busy) return res.status(409).json({ error: 'Another browser job is already running — give it a moment and try again.' });
  busy = true;
  console.log('[ux-workbench] Capturing pattern "' + name + '" from ' + url + ' …');
  try {
    const extraction = await extractPattern(url);
    const id = patternFormat.kebab(name);
    const json = patternFormat.buildPatternJson(name, extraction, store.getLibraryIndex());
    const entry = store.savePattern({ id, name, url, json, png: extraction.png });
    console.log('[ux-workbench] Pattern saved: patterns/' + id + '.json');
    res.json(Object.assign({}, entry, { json: json, thumb: extraction.png ? 'data:image/png;base64,' + extraction.png.toString('base64') : null }));
  } catch (e) {
    console.error('[ux-workbench] Capture failed:', e.message);
    res.status(500).json({ error: friendly(e, url) });
  } finally {
    busy = false;
  }
});

/* ---- Component Library (Storybook sync) ---- */
app.get('/api/library', (req, res) => {
  const index = store.getLibraryIndex();
  res.json(index || { syncedAt: null, components: [] });
});

app.post('/api/screenshot', async (req, res) => {
  const url = (req.body && req.body.url || '').trim();
  if (!/^https?:\/\//i.test(url)) return res.status(400).json({ error: 'Invalid URL' });
  try {
    const { chromium } = require('playwright');
    const browser = await chromium.launch({ headless: true });
    const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
    await page.goto(url, { waitUntil: 'load', timeout: 30000 }).catch(() => {});
    await page.waitForLoadState('networkidle', { timeout: 6000 }).catch(() => {});
    await page.waitForTimeout(800);
    const tall = await page.evaluate(() => document.documentElement.scrollHeight).catch(() => 900);
    const buf = await page.screenshot({ fullPage: tall < 8000 });
    await browser.close();
    res.json({ dataUrl: 'data:image/png;base64,' + buf.toString('base64'), width: buf.readUInt32BE(16), height: buf.readUInt32BE(20) });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/snapshot-html', async (req, res) => {
  const url = (req.body && req.body.url || '').trim();
  if (!/^https?:\/\//i.test(url)) return res.status(400).json({ error: 'Invalid URL' });
  try {
    const { chromium } = require('playwright');
    const browser = await chromium.launch({ headless: true });
    const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
    await page.goto(url, { waitUntil: 'load', timeout: 30000 }).catch(() => {});
    await page.waitForLoadState('networkidle', { timeout: 6000 }).catch(() => {});
    await page.waitForTimeout(800);
    const html = await page.evaluate(async () => {
      document.querySelectorAll('script,noscript').forEach(e => e.remove());
      document.querySelectorAll('img').forEach(img => {
        try {
          const c = document.createElement('canvas');
          c.width = img.naturalWidth || img.width; c.height = img.naturalHeight || img.height;
          if (!c.width || !c.height) return;
          c.getContext('2d').drawImage(img, 0, 0);
          img.src = c.toDataURL('image/png'); img.removeAttribute('srcset');
        } catch (e) {}
      });
      for (const link of [...document.querySelectorAll('link[rel="stylesheet"]')]) {
        try { const css = await (await fetch(link.href)).text(); const st = document.createElement('style'); st.textContent = css; link.replaceWith(st); } catch (e) {}
      }
      document.querySelectorAll('input,textarea,select').forEach(f => { try { if (f.type === 'checkbox' || f.type === 'radio') { if (f.checked) f.setAttribute('checked', ''); } else if (f.tagName === 'SELECT') { [...f.options].forEach(o => { if (o.selected) o.setAttribute('selected', ''); }); } else f.setAttribute('value', f.value); } catch (e) {} });
      return '<!doctype html>' + document.documentElement.outerHTML;
    });
    await browser.close();
    res.json({ html: html });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/source-audit', (req, res) => {
  const fsx = require('fs'), pth = require('path');
  const root = (req.body && req.body.path || '').trim();
  const skills = (req.body && req.body.skills) || [];
  if (!root) return res.status(400).json({ error: 'No folder path given' });
  let st; try { st = fsx.statSync(root); } catch (e) { st = null; }
  if (!st || !st.isDirectory()) return res.status(400).json({ error: 'Folder not found on this machine: ' + root });
  const SKIP = /^(node_modules|dist|\.git|coverage|\.angular|out|build|e2e)$/;
  const files = [];
  (function walk(dir, depth) {
    if (depth > 12 || files.length > 4000) return;
    let ents = []; try { ents = fsx.readdirSync(dir, { withFileTypes: true }); } catch (e) { return; }
    for (const en of ents) {
      if (files.length > 4000) break;
      if (en.isDirectory()) { if (!SKIP.test(en.name)) walk(pth.join(dir, en.name), depth + 1); }
      else if (/\.(ts|html|scss|css)$/.test(en.name) && !/\.spec\.ts$/.test(en.name)) files.push(pth.join(dir, en.name));
    }
  })(root, 0);
  function parseCode(text) {
    let lines = String(text || '').split(/\r?\n/);
    if (lines[0] && lines[0].trim() === '---') { const e = lines.findIndex((l, i) => i > 0 && l.trim() === '---'); if (e > 0) lines = lines.slice(e + 1); }
    const d = [];
    lines.forEach(raw => {
      const line = raw.trim(); let m;
      if (m = line.match(/^-?\s*forbidden-import\s*:\s*(.+?)\s*(?:\u2192|->)\s*(.+)$/i)) d.push({ kind: 'import', find: m[1].trim(), repl: m[2].trim() });
      else if (m = line.match(/^-?\s*forbidden-call\s*:\s*(.+?)\s*(?:\u2192|->)\s*(.+)$/i)) d.push({ kind: 'call', find: m[1].trim(), repl: m[2].trim() });
      else if (m = line.match(/^-?\s*forbidden-style\s*:\s*(.+?)\s*(?:\u2192|->)\s*(.+)$/i)) d.push({ kind: 'style', find: m[1].trim(), repl: m[2].trim() });
      else if (m = line.match(/^-?\s*forbidden-element\s*:\s*(.+?)\s*(?:\u2192|->)\s*(.+)$/i)) d.push({ kind: 'element', sel: m[1].trim(), repl: m[2].trim() });
      else if (m = line.match(/^-?\s*forbidden-(?:label|term)\s*:\s*(.+?)\s*(?:\u2192|->)\s*(.+)$/i)) d.push({ kind: 'term', term: m[1].trim(), preferred: m[2].trim() });
    });
    return d;
  }
  const CAT = { import: ['SRC-IMPORT', 'Information Architecture', 'high'], call: ['SRC-CALL', 'Interaction Design', 'high'], style: ['SRC-STYLE', 'Visual Hierarchy', 'medium'], element: ['SRC-EL', 'Visual Hierarchy', 'medium'], term: ['SRC-TERM', 'Information Architecture', 'high'] };
  const findings = [];
  for (const sk of skills) {
    const dirs = parseCode(sk.text || '');
    if (!dirs.length) continue;
    for (const file of files) {
      if (findings.length >= 300) break;
      let text; try { text = fsx.readFileSync(file, 'utf8'); } catch (e) { continue; }
      const rel = pth.relative(root, file).replace(/\\/g, '/');
      const isTs = /\.ts$/.test(file), isHtml = /\.html$/.test(file), isStyle = /\.(scss|css)$/.test(file);
      const lines = text.split(/\r?\n/);
      dirs.forEach(d => {
        let count = 0;
        for (let ln = 0; ln < lines.length && count < 3 && findings.length < 300; ln++) {
          const L = lines[ln];
          let hit = false, title = '', fix = '';
          if (d.kind === 'import' && isTs && /^\s*import\b/.test(L) && L.includes(d.find)) { hit = true; title = 'Forbidden import: ' + d.find; fix = 'In ' + rel + ' line ' + (ln + 1) + ', replace the import of "' + d.find + '" with ' + d.repl + ' and update usages.'; }
          else if (d.kind === 'call' && isTs && L.includes(d.find)) { hit = true; title = 'Forbidden call: ' + d.find; fix = 'In ' + rel + ' line ' + (ln + 1) + ', replace the ' + d.find + '...) usage with ' + d.repl + '. Keep the behavior identical.'; }
          else if (d.kind === 'style' && (isStyle || isHtml) && L.includes(d.find)) { hit = true; title = 'Forbidden style: ' + d.find; fix = 'In ' + rel + ' line ' + (ln + 1) + ', replace "' + d.find + '" with ' + d.repl + '.'; }
          else if (d.kind === 'element' && isHtml) {
            const base = (d.sel.match(/^([a-zA-Z][\w-]*)/) || [])[1];
            const cls = d.sel[0] === '.' ? (d.sel.match(/^\.([\w-]+)/) || [])[1] : null;
            if (base && new RegExp('<' + base + '(?=[\\s>/])', 'i').test(L)) hit = true;
            else if (cls && new RegExp('class="[^"]*\\b' + cls + '\\b', 'i').test(L)) hit = true;
            if (hit) { title = 'Non-DS element in template \u2014 use ' + d.repl; fix = 'In ' + rel + ' line ' + (ln + 1) + ', replace this element with ' + d.repl + ' from the design system. Keep bindings and layout unchanged.'; }
          }
          else if (d.kind === 'term' && isHtml && new RegExp('\\b' + d.term.replace(/[.*+?^$()|[\]\\{}]/g, '\\$&') + '\\b', 'i').test(L)) { hit = true; title = 'Forbidden label "' + d.term + '"'; fix = 'In ' + rel + ' line ' + (ln + 1) + ', replace "' + d.term + '" with "' + (d.preferred || 'the approved term') + '" in user-visible text only.'; }
          if (!hit) continue;
          count++;
          const c = CAT[d.kind];
          findings.push({ ruleId: c[0], category: c[1], severity: c[2], title: title, message: L.trim().slice(0, 100), file: rel, line: ln + 1, fixPrompt: fix, skill: sk.name });
        }
      });
    }
  }
  res.json({ filesScanned: files.length, findings: findings });
});

app.get('/api/library/sync-status', (req, res) => res.json(getProgress()));

app.post('/api/library/sync', async (req, res) => {
  const url = (req.body && req.body.url || 'http://localhost:6006').trim();
  if (busy) return res.status(409).json({ error: 'Another browser job is already running — give it a moment and try again.' });
  busy = true;
  console.log('[ux-workbench] Syncing Storybook from ' + url + ' …');
  try {
    const summary = await syncLibrary(url);
    console.log('[ux-workbench] Library synced: ' + summary.components + ' components, ' + summary.variants + ' variants, ' + summary.skipped.length + ' skipped');
    res.json(summary);
  } catch (e) {
    if (e.message === 'STORYBOOK_UNREACHABLE') {
      res.status(502).json({ error: 'Could not read the Storybook index at ' + url + '. Is Storybook running? Start it in your component-library repo (usually "npm run storybook"), wait until it opens, then sync again.' });
    } else {
      console.error('[ux-workbench] Sync failed:', e.message);
      res.status(500).json({ error: 'Sync failed: ' + e.message });
    }
  } finally {
    busy = false;
  }
});

app.get('/api/library/:id', (req, res) => {
  const comp = store.getLibraryComponent(req.params.id);
  if (!comp) return res.status(404).json({ error: 'Component not found.' });
  res.json(comp);
});

app.post('/api/library/:id/notes', (req, res) => {
  const comp = store.saveLibraryNotes(req.params.id, req.body || {});
  if (!comp) return res.status(404).json({ error: 'Component not found.' });
  res.json(comp);
});

/** Turn Playwright/network errors into plain-English advice. */
function friendly(e, url) {
  const msg = String(e && e.message || e);
  if (/ERR_CONNECTION_REFUSED|ECONNREFUSED/.test(msg)) {
    return 'Could not reach ' + url + ' — is your Angular app running? Start it (e.g. "ng serve") and try again.';
  }
  if (/Timeout .*exceeded|TimeoutError/i.test(msg)) {
    return 'The page took too long to load. Check the URL opens in your normal browser, then try again.';
  }
  if (/ERR_NAME_NOT_RESOLVED/.test(msg)) {
    return 'That address could not be found. Check the URL for typos.';
  }
  if (/browserType\.launch|Executable doesn't exist/i.test(msg)) {
    return 'Chromium is not installed yet. Run "npx playwright install chromium" in this folder once, then restart.';
  }
  return 'Job failed: ' + msg;
}

const server = app.listen(PORT, () => {
  console.log('');
  console.log('  UX Workbench is running.');
  console.log('  Open  http://localhost:' + PORT + '  in your browser.');
  console.log('');
});
server.on('error', (e) => {
  if (e.code === 'EADDRINUSE') {
    console.error('\nPort ' + PORT + ' is already in use.');
    console.error('Either close the other program, or start UX Workbench on another port:');
    console.error(process.platform === 'win32' ? '  set PORT=5001 && npm start' : '  PORT=5001 npm start');
    process.exit(1);
  }
  throw e;
});
