# Accessibility Audit Checklist

Use WCAG 2.2 Level AA as the usual product target unless the user specifies another standard. Cite success criteria as supporting references, not as a compliance certification.

## Perceivable

- Give informative images useful alternatives; use empty alternatives for genuinely decorative images. (1.1.1)
- Provide captions for prerecorded synchronized media and suitable alternatives for audio/video. (1.2.x)
- Preserve structure and relationships programmatically: headings, lists, labels, tables, and landmarks. (1.3.1)
- Keep a meaningful reading and focus sequence. (1.3.2, 2.4.3)
- Do not rely on color, shape, position, or sound alone. (1.3.3, 1.4.1)
- Meet contrast: normally 4.5:1 for body text, 3:1 for large text, and 3:1 for meaningful UI graphics and component boundaries. (1.4.3, 1.4.11)
- Support text resizing, reflow, and text spacing without loss of content or function. (1.4.4, 1.4.10, 1.4.12)

## Operable

- Make all functionality keyboard operable with no keyboard trap. (2.1.1, 2.1.2)
- Provide ways to pause or stop relevant time limits, movement, blinking, or auto-updating content. (2.2.x)
- Avoid content that flashes more than permitted thresholds. (2.3.1)
- Provide skip mechanisms, descriptive titles/headings/labels, visible focus, and unobscured focus. (2.4.1–2.4.13)
- Avoid dragging-only functionality and provide sufficient pointer target size or an allowed exception. (2.5.7, 2.5.8)

## Understandable

- Set the page language and identify language changes when needed. (3.1.1, 3.1.2)
- Keep navigation, labels, and repeated components consistent. (3.2.x)
- Identify errors in text, associate instructions with controls, and provide correction help for important submissions. (3.3.x)
- Avoid asking users to re-enter information unnecessarily; make authentication cognitively accessible. (3.3.7, 3.3.8)

## Robust

- Use native elements where possible and expose correct names, roles, values, and states for custom controls. (4.1.2)
- Programmatically expose status messages without forcing focus. (4.1.3)

## Manual Interaction Scripts

### Keyboard

1. Reload and avoid the mouse.
2. Tab through the page and record the first focus target.
3. Confirm focus is always visible and follows a logical order.
4. Activate links and buttons with expected keys.
5. Open and close menus, dialogs, and popovers; check Escape and focus restoration.
6. Confirm no focus trap except intentional modal containment.

### Zoom and reflow

1. Test 200% browser zoom at a desktop viewport.
2. Test a CSS viewport about 320 pixels wide when feasible.
3. Confirm content does not overlap, disappear, or require two-dimensional scrolling except for intrinsically large content.

### Screen reader

1. Navigate by landmarks and headings.
2. Review the controls list for clear, unique names.
3. Complete the primary task and trigger validation errors.
4. Confirm names, roles, values, states, instructions, and dynamic messages are announced at the right time.

### Motion and media

1. Enable reduced-motion preference and reload.
2. Verify nonessential animation is removed or reduced.
3. Check captions/transcripts and whether autoplay can be paused.
