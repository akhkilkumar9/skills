---
name: audit-screen-accessibility
description: Audit or fix the accessibility of a local web screen from an HTML file, localhost URL, screenshot, component, or frontend repository. Use for design-focused accessibility reviews that explain confirmed problems and solutions in simple language. When the user explicitly asks to fix findings, implement the scoped changes, verify them, and provide matching before-and-after screenshots.
---

# Audit Screen Accessibility

Review the rendered experience and source together. Write for designers and non-technical stakeholders by default. Keep implementation language brief and optional.

## Choose the mode

- **Audit mode:** Use when the user asks to check, review, inspect, or report. Do not edit product files.
- **Fix mode:** Use only when the user explicitly asks to fix, implement, apply, or resolve findings. Edit only the screen and supporting files in scope.

## Audit workflow

1. Identify the target screen, route, component, state, and viewport.
2. Read the relevant source. When an HTML file is available, run:

   ```bash
   python3 <skill-directory>/scripts/audit_html.py <page.html> --format markdown
   ```

3. Render the screen when browser or preview tooling is available. Capture the main desktop view and a narrow mobile view when relevant.
4. Inspect visible design concerns: contrast, text readability, labels, errors, focus visibility, control size, spacing, clipping, reflow, color-only meaning, motion, and content hierarchy.
5. Inspect the underlying structure for image descriptions, control names, reading order, keyboard order, page structure, and dynamic messages.
6. Exercise keyboard interaction when the page runs: Tab, Shift+Tab, Enter, Space, arrows where expected, and Escape for dismissible overlays.
7. Read [references/audit-checklist.md](references/audit-checklist.md) for a full audit or standards mapping.
8. Report confirmed problems only. Hide passes unless the user requests them.

## Evidence rules

- Report a problem only when the rendered screen, source, or interaction provides reproducible evidence.
- Treat automated warnings as leads and verify them before reporting.
- Put checks that could not be performed under **Not tested**; do not present them as failures.
- Do not claim formal compliance from one screen review.
- Do not infer keyboard or screen-reader behavior from a screenshot alone.

## Writing style

- Lead with what a user sees or experiences, not with HTML, ARIA, DOM, selector, or WCAG terminology.
- Use familiar phrases such as “the field has no visible label,” “the text is difficult to read,” or “the focus indicator is missing.”
- Keep each summary cell to one short sentence.
- Avoid code snippets and standards codes in the main report unless the user requests technical detail.
- If a development change is necessary, add one short **Developer note** in plain language. Do not explain framework internals.
- Prefer “people using a keyboard” over “non-pointer input users,” and “people using a screen reader” over specialist jargon.

## Audit report format

Start with a one-sentence scope. Do not include a strengths or passing-checks section.

### Findings and solutions

Place this table first:

| Finding | Severity | Design impact | Suggested improvement |
|---|---|---|---|

Use one concise row per confirmed issue. Describe the design problem and solution in language a non-technical reader can act on.

### Design notes

Group related issues under short labels such as **Forms**, **Visibility**, **Interaction**, and **Content structure**. For each issue include only:

- **Problem:** What the user experiences.
- **Design improvement:** The intended visible or interaction change.
- **Developer note:** Optional; one plain sentence only when implementation detail is necessary.

### Priority

List the top three to five improvements in recommended order. Prioritize blocked tasks, keyboard use, field labels and errors, visibility, then refinements.

### Not tested

List unavailable checks in one short section. Do not mix them with confirmed findings.

## Fix workflow

When the user explicitly asks to fix findings:

1. Resolve the exact screen and files before editing.
2. Reproduce the audited state and capture **before** screenshots. Record viewport size, theme, data, interaction state, scroll position, and browser zoom.
3. Implement the confirmed findings while preserving the product's visual language and intended behavior.
4. Re-run the available static, browser, keyboard, and project tests. Correct regressions caused by the changes.
5. Reproduce the same state and capture **after** screenshots at the same viewport, theme, data, interaction state, scroll position, and zoom.
6. Create a clearly labeled side-by-side **Before / After** comparison image for each materially different viewport or state. Preserve the screenshots exactly; do not use generative image tools to simulate either state.
7. For semantic fixes that are not visible in pixels, state this briefly beside the comparison instead of inventing a visual difference.
8. If real screenshots cannot be captured, explain why and provide the separate available images. Never fabricate a comparison.

## Fix response format

### Fixes applied

Summarize the design changes in three to six short bullets. Keep development details minimal.

### Before and after

Show the comparison images directly and label the viewport or state. Link the original full-resolution screenshots when available.

### Verification

State what was retested and list any remaining or unverified issues. Do not claim that all accessibility problems are resolved unless the required interaction and assistive-technology checks passed.

## Severity

- **Critical:** A core task cannot be completed.
- **High:** A core task is very difficult for some users.
- **Medium:** The screen creates meaningful difficulty or confusion.
- **Low:** The issue is localized or a refinement.

## Static audit script

Use `scripts/audit_html.py` for dependency-free HTML checks. It outputs issues only by default and returns exit code `1` when it finds problems; treat that exit code as an audit result, not a crash. The script cannot confirm rendered contrast, layout, JavaScript behavior, keyboard behavior, or screen-reader output.
