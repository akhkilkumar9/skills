#!/usr/bin/env python3
"""Dependency-free static accessibility checks for one HTML file."""

from __future__ import annotations

import argparse
import json
import re
import sys
from collections import Counter
from dataclasses import dataclass, asdict
from html.parser import HTMLParser
from pathlib import Path


VOID = {"area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "param", "source", "track", "wbr"}
INTERACTIVE = {"a", "button", "input", "select", "textarea", "summary", "details"}


@dataclass
class Node:
    tag: str
    attrs: dict[str, str]
    line: int
    parent: "Node | None" = None
    text: str = ""

    def ancestor(self, tag: str) -> bool:
        current = self.parent
        while current:
            if current.tag == tag:
                return True
            current = current.parent
        return False


@dataclass
class Finding:
    status: str
    severity: str
    rule: str
    message: str
    line: int | None
    wcag: str


class TreeParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.root = Node("document", {}, 1)
        self.stack = [self.root]
        self.nodes: list[Node] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        values = {key.lower(): (value or "") for key, value in attrs}
        node = Node(tag.lower(), values, self.getpos()[0], self.stack[-1])
        self.stack[-1].text += " "
        self.nodes.append(node)
        if node.tag not in VOID:
            self.stack.append(node)

    def handle_startendtag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        self.handle_starttag(tag, attrs)
        if self.stack[-1].tag == tag.lower():
            self.stack.pop()

    def handle_endtag(self, tag: str) -> None:
        tag = tag.lower()
        for index in range(len(self.stack) - 1, 0, -1):
            if self.stack[index].tag == tag:
                node = self.stack[index]
                combined = " ".join(part for part in [node.text.strip()] if part)
                if index > 0:
                    self.stack[index - 1].text += f" {combined} "
                del self.stack[index:]
                return

    def handle_data(self, data: str) -> None:
        self.stack[-1].text += data


def clean(text: str) -> str:
    return re.sub(r"\s+", " ", text).strip()


def has_name(node: Node) -> bool:
    return bool(clean(node.text) or node.attrs.get("aria-label", "").strip() or node.attrs.get("aria-labelledby", "").strip() or node.attrs.get("title", "").strip())


def audit(path: Path) -> list[Finding]:
    parser = TreeParser()
    parser.feed(path.read_text(encoding="utf-8"))
    nodes = parser.nodes
    findings: list[Finding] = []

    def add(status: str, severity: str, rule: str, message: str, line: int | None, wcag: str) -> None:
        findings.append(Finding(status, severity, rule, message, line, wcag))

    html = next((n for n in nodes if n.tag == "html"), None)
    if html and html.attrs.get("lang", "").strip():
        add("pass", "", "document-language", f"Document language is '{html.attrs['lang']}'.", html.line, "3.1.1")
    else:
        add("fail", "high", "document-language", "The html element has no non-empty lang attribute.", html.line if html else 1, "3.1.1")

    title = next((n for n in nodes if n.tag == "title"), None)
    if title and clean(title.text):
        add("pass", "", "page-title", f"Page has a non-empty title: '{clean(title.text)}'.", title.line, "2.4.2")
    else:
        add("fail", "medium", "page-title", "Page has no non-empty title element.", title.line if title else 1, "2.4.2")

    mains = [n for n in nodes if n.tag == "main" or n.attrs.get("role") == "main"]
    if len(mains) == 1:
        add("pass", "", "main-landmark", "Page has one main landmark.", mains[0].line, "1.3.1")
    elif not mains:
        add("fail", "medium", "main-landmark", "Page has no main landmark.", None, "1.3.1")
    else:
        add("fail", "medium", "main-landmark", f"Page has {len(mains)} main landmarks; use one primary main landmark.", mains[1].line, "1.3.1")

    headings = [n for n in nodes if re.fullmatch(r"h[1-6]", n.tag)]
    h1s = [n for n in headings if n.tag == "h1"]
    if len(h1s) == 1 and clean(h1s[0].text):
        add("pass", "", "primary-heading", f"Page has one named h1: '{clean(h1s[0].text)}'.", h1s[0].line, "1.3.1, 2.4.6")
    else:
        add("fail", "medium", "primary-heading", f"Expected one non-empty h1; found {len(h1s)}.", h1s[0].line if h1s else None, "1.3.1, 2.4.6")
    previous = 0
    for heading in headings:
        level = int(heading.tag[1])
        if previous and level > previous + 1:
            add("fail", "low", "heading-order", f"Heading level jumps from h{previous} to h{level}: '{clean(heading.text)}'.", heading.line, "1.3.1")
        previous = level

    images = [n for n in nodes if n.tag == "img"]
    missing_alt = [n for n in images if "alt" not in n.attrs]
    for image in missing_alt:
        add("fail", "high", "image-alt", "Image has no alt attribute.", image.line, "1.1.1")
    if images and not missing_alt:
        add("pass", "", "image-alt", f"All {len(images)} image element(s) have an alt attribute; verify that each value matches its purpose.", images[0].line, "1.1.1")

    labels_for = {n.attrs.get("for") for n in nodes if n.tag == "label" and n.attrs.get("for")}
    controls = [n for n in nodes if n.tag in {"input", "select", "textarea"} and n.attrs.get("type", "text").lower() not in {"hidden", "button", "submit", "reset", "image"}]
    unlabeled: list[Node] = []
    for control in controls:
        identifier = control.attrs.get("id")
        labeled = bool((identifier and identifier in labels_for) or control.ancestor("label") or control.attrs.get("aria-label", "").strip() or control.attrs.get("aria-labelledby", "").strip())
        if not labeled:
            unlabeled.append(control)
            add("fail", "high", "form-label", f"{control.tag} control has no programmatic label; placeholder text is not a label.", control.line, "1.3.1, 3.3.2, 4.1.2")
    if controls and not unlabeled:
        add("pass", "", "form-label", f"All {len(controls)} form control(s) have a programmatic label.", controls[0].line, "1.3.1, 3.3.2")

    for node in nodes:
        if node.tag == "button" and not has_name(node):
            add("fail", "high", "button-name", "Button has no accessible name.", node.line, "4.1.2")
        if node.tag == "a" and node.attrs.get("href") is not None and not has_name(node):
            add("fail", "high", "link-name", "Link has no accessible name.", node.line, "2.4.4, 4.1.2")
        tabindex = node.attrs.get("tabindex", "")
        if re.fullmatch(r"\+?\d+", tabindex.strip()) and int(tabindex) > 0:
            add("fail", "medium", "positive-tabindex", f"Positive tabindex='{tabindex}' overrides the natural focus order.", node.line, "2.4.3")
        if "onclick" in node.attrs and node.tag not in INTERACTIVE and node.attrs.get("role") not in {"button", "link", "checkbox", "menuitem", "option", "radio", "switch", "tab"}:
            add("fail", "high", "nonsemantic-click", f"Clickable <{node.tag}> is not a native interactive element and exposes no interactive role.", node.line, "2.1.1, 4.1.2")
        if node.tag in {"audio", "video"} and "autoplay" in node.attrs:
            add("fail", "medium", "media-autoplay", f"<{node.tag}> uses autoplay; verify that users can pause or stop it.", node.line, "1.4.2, 2.2.2")

    ids = [n.attrs["id"] for n in nodes if n.attrs.get("id")]
    duplicates = [identifier for identifier, count in Counter(ids).items() if count > 1]
    for identifier in duplicates:
        node = next(n for n in nodes if n.attrs.get("id") == identifier)
        add("fail", "medium", "duplicate-id", f"The id '{identifier}' occurs more than once and can break label or ARIA references.", node.line, "1.3.1, 4.1.2")

    styles = "\n".join(n.text for n in nodes if n.tag == "style")
    if re.search(r"(?:outline\s*:\s*none|outline\s*:\s*0)(?:\s*!important)?\s*;?", styles, re.I):
        add("manual", "high", "focus-visible", "CSS removes outlines. Verify that every focusable element receives an equally visible replacement focus indicator.", None, "2.4.7, 2.4.11")

    add("manual", "", "computed-contrast", "Measure computed text, component, and focus-indicator contrast in the rendered page.", None, "1.4.3, 1.4.11")
    add("manual", "", "keyboard-operation", "Test keyboard reachability, activation, focus order, traps, and focus restoration in a browser.", None, "2.1.1, 2.1.2, 2.4.3")
    add("manual", "", "zoom-reflow", "Test 200% zoom and reflow near 320 CSS pixels without loss of content or function.", None, "1.4.4, 1.4.10")
    add("manual", "", "screen-reader", "Verify names, roles, values, states, reading order, and dynamic announcements with a screen reader.", None, "1.3.2, 4.1.2, 4.1.3")
    return findings


def markdown(path: Path, findings: list[Finding], include_passes: bool = False) -> str:
    groups = {status: [f for f in findings if f.status == status] for status in ("pass", "fail", "manual")}
    severity_counts = Counter(f.severity for f in groups["fail"])
    lines = [
        f"# Static accessibility issues: {path.name}",
        "",
        f"- Confirmed failures: {len(groups['fail'])}",
        f"- High: {severity_counts['high']}",
        f"- Medium: {severity_counts['medium']}",
        f"- Low: {severity_counts['low']}",
        f"- Checks requiring manual testing: {len(groups['manual'])}",
        "",
    ]
    sections = [("fail", "Confirmed problems"), ("manual", "Testing not completed")]
    if include_passes:
        sections.append(("pass", "Passing source checks (explicitly requested)"))
    for status, heading in sections:
        lines.extend([f"## {heading}", ""])
        if not groups[status]:
            lines.extend(["None.", ""])
            continue
        for item in groups[status]:
            where = f"line {item.line}" if item.line else "page-level"
            severity = f" [{item.severity.upper()}]" if item.severity else ""
            lines.append(f"- **{item.rule}**{severity} — {item.message} ({where}; WCAG {item.wcag})")
        lines.append("")
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("html_file", type=Path)
    parser.add_argument("--format", choices=("markdown", "json"), default="markdown")
    parser.add_argument("--include-passes", action="store_true", help="Include passing checks; hidden by default")
    args = parser.parse_args()
    if not args.html_file.is_file():
        parser.error(f"File not found: {args.html_file}")
    findings = audit(args.html_file)
    if args.format == "json":
        visible = findings if args.include_passes else [f for f in findings if f.status != "pass"]
        print(json.dumps({"file": str(args.html_file), "findings": [asdict(f) for f in visible]}, indent=2))
    else:
        print(markdown(args.html_file, findings, args.include_passes))
    return 1 if any(f.status == "fail" for f in findings) else 0


if __name__ == "__main__":
    sys.exit(main())
