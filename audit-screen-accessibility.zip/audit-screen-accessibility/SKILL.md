---
name: audit-screen-accessibility
description: Audit the accessibility of a local web screen from an HTML file, localhost URL, screenshot, or frontend repository. Use when Codex needs to inspect a page or component for WCAG-oriented visual, semantic, keyboard, form, focus, responsive, and assistive-technology problems, then produce an issue-only report explaining what is wrong, who is affected, and exactly how to improve and verify each problem.
---

# Audit Screen Accessibility

Audit rendered experience and source semantics together. Never treat a clean screenshot or automated scan as proof that a screen is fully accessible.

## Workflow

1. Identify the target: HTML file, localhost URL, screenshot, component, or route.
2. Preserve the user's app state. Do not edit production code unless the user asks for fixes.
3. Read the relevant source and run the bundled static audit when an HTML file is available:

   ```bash
   python3 <skill-directory>/scripts/audit_html.py <page.html> --format markdown
   ```

4. Render the target in a browser when browser tooling is available. Capture the default viewport and, when relevant, a narrow mobile viewport.
5. Inspect the rendered screen for contrast, text size, clipping, zoom resilience, visible labels, target size, spacing, color-only meaning, motion, and visible focus.
6. Inspect the DOM/source for names, roles, states, landmarks, heading hierarchy, labels, alternative text, live regions, language, page title, and focus order.
7. Exercise keyboard interaction when the page is runnable: Tab, Shift+Tab, Enter, Space, arrows where expected, Escape for dismissible overlays, and focus restoration after dialogs.
8. Read [references/audit-checklist.md](references/audit-checklist.md) when conducting a full audit or mapping findings to WCAG.
9. Report confirmed problems only. Do not include passing checks unless the user explicitly asks for them.

## Evidence Rules

- Mark **Pass** only when the relevant behavior was actually observed or the source provides sufficient evidence.
- Mark **Fail** only with reproducible evidence: element, selector or source line, observed behavior, user impact, and remediation.
- Mark **Needs manual test** when automation or static inspection cannot establish the result.
- Use passing checks internally to avoid false findings, but omit them from the final report unless requested.
- Treat tool warnings as leads. Verify them before reporting a failure.
- Do not claim formal WCAG compliance from a single-screen review.
- Do not infer accessible names, keyboard support, focus order, or screen-reader output from pixels alone.

## Minimum Test Set

Cover these areas unless the available artifact makes one impossible:

- Page language, title, landmarks, headings, and reading order
- Text and non-text contrast, color-only meaning, and visible focus
- Image alternatives and decorative-image handling
- Form labels, instructions, errors, required state, and autocomplete
- Button, link, and control names, roles, states, and target sizes
- Keyboard reachability, activation, focus order, traps, and focus restoration
- Zoom/reflow at 200% and a narrow viewport when browser tooling permits
- Captions, transcripts, autoplay, animation, and reduced motion when media exists
- Dynamic announcements and status/error messages when the UI updates

## Output Format

Start with scope and limitations, including what was rendered and what was not tested. Do not add a “What is correct,” “Passed checks,” or strengths section. Then provide:

### Findings and solutions summary

Place this section first after scope. Use a concise table with these columns:

- **Finding**: Name the accessibility problem in plain language.
- **Severity**: Critical, High, Medium, or Low.
- **Recommended solution**: State the main actionable fix, not merely “follow WCAG” or “improve accessibility.”

Include one row per confirmed problem so the user can immediately connect every finding to its solution. After the table, state the total confirmed problems and counts by severity. Do not count or mention passing checks.

### Detailed findings

Create one subsection per confirmed problem. Use this structure:

- **Issue and severity**
- **What is wrong**: Explain the failure in plain language.
- **Where**: Give the route, component, visible label, selector, and source line when available.
- **Why it matters**: Describe the task blocked or made difficult and the users affected.
- **How to improve**: Give a concrete design or code change. Include a short code example when useful.
- **How to verify**: Give exact retest steps and expected behavior.
- **WCAG reference**: List the relevant success criterion, without claiming formal conformance.

Order findings by severity and user impact. Avoid dense tables when detailed remediation needs multiple sentences.

Use these severities:

- **Critical**: Blocks a core task for one or more disability groups.
- **High**: Makes a core task very difficult or creates a serious barrier.
- **Medium**: Causes meaningful friction or failure in a secondary task.
- **Low**: Limited impact, best-practice gap, or localized issue.

### Testing not completed

List checks that could not be run, but do not describe them as failures or include them in issue counts. Include exact reproduction steps and expected behavior.

### Suggested fix order

Prioritize task blockers, keyboard and naming issues, forms/errors, contrast/focus, then refinements.

## Static Audit Script

Use `scripts/audit_html.py` for dependency-free HTML checks. It emits Markdown or JSON and returns exit code `1` when it finds failures, so a failing exit code is an audit result rather than a script crash. It does not evaluate computed CSS, browser layout, JavaScript behavior, screen-reader speech, or full accessible-name computation; cover those through rendering and manual checks.
