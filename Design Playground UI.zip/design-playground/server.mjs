#!/usr/bin/env node
// Design Playground server (no dependencies, Node 18+).
// Serves the playground UI, stores patterns in ./data/patterns.json, manages your local repos,
// and reads component source + dependencies from the active repo.
import http from 'node:http';
import { readFile, writeFile, readdir, mkdir, copyFile, unlink, rm } from 'node:fs/promises';
import { exec } from 'node:child_process';
import { existsSync, createReadStream, statSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { installInspector } from './scripts/inspector.mjs';

const here = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT ?? 4300);
const HOST = process.env.DP_HOST ?? '127.0.0.1';
const PUBLIC = path.join(here, 'public');
const DATA = path.join(here, 'data');
const STORE = path.join(DATA, 'patterns.json');
const SETTINGS = path.join(DATA, 'settings.json');
const SKIP = new Set(['node_modules', 'dist', '.angular', '.git']);
const CORE = /^(@angular\/|rxjs|tslib|zone\.js)/;
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon', '.json': 'application/json' };

const send = (res, code, body) => {
  res.writeHead(code, { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type', 'Access-Control-Allow-Private-Network': 'true' });
  res.end(JSON.stringify(body));
};
const readBody = (req) => new Promise((ok) => { let d = ''; req.on('data', (c) => (d += c)); req.on('end', () => { try { ok(JSON.parse(d || '{}')); } catch { ok({}); } }); });
const read = async (f, d = '') => { try { return await readFile(f, 'utf8'); } catch { return d; } };
const json = async (f, d) => { try { return JSON.parse(await readFile(f, 'utf8')); } catch { return d; } };
const slug = (s) => String(s).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '') || 'repo';

/* ---------- repos ---------- */
async function settings() { const s = await json(SETTINGS, {}); s.repos ??= []; return s; }
async function saveSettings(s) { await mkdir(DATA, { recursive: true }); await writeFile(SETTINGS, JSON.stringify(s, null, 2)); }
async function activeRepo() {
  if (process.env.DP_ROOT) return { id: 'env', name: 'DP_ROOT', path: path.dirname(path.resolve(process.env.DP_ROOT)), src: path.resolve(process.env.DP_ROOT) };
  const s = await settings();
  const r = s.repos.find((x) => x.id === s.active) ?? s.repos[0];
  if (r) return { ...r, src: path.join(r.path, 'src') };
  return s.root ? { id: 'legacy', name: 'repo', path: path.dirname(path.resolve(s.root)), src: path.resolve(s.root) } : null;
}

/* ---------- capture with dependencies ---------- */
const cache = new Map();
async function walk(dir, out = []) {
  for (const e of await readdir(dir, { withFileTypes: true })) {
    if (SKIP.has(e.name)) continue;
    const p = path.join(dir, e.name);
    if (e.isDirectory()) await walk(p, out);
    else if (e.name.endsWith('.ts') && !e.name.endsWith('.spec.ts')) out.push(p);
  }
  return out;
}
async function files(root) {
  const c = cache.get(root);
  if (c && Date.now() - c.at < 5000) return c.list;
  const list = await walk(root);
  cache.set(root, { at: Date.now(), list });
  return list;
}
const esc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const stripJsonc = (t) => t.replace(/\/\*[\s\S]*?\*\//g, '').replace(/(^|[^:])\/\/.*$/gm, '$1').replace(/,(\s*[}\]])/g, '$1');

async function tsAliases(repo) {
  const out = [];
  for (const f of ['tsconfig.json', 'tsconfig.base.json', 'tsconfig.app.json']) {
    try {
      const c = JSON.parse(stripJsonc(await readFile(path.join(repo, f), 'utf8')));
      const base = path.resolve(repo, c.compilerOptions?.baseUrl ?? '.');
      for (const [k, v] of Object.entries(c.compilerOptions?.paths ?? {})) out.push({ prefix: k.replace(/\*$/, ''), targets: v.map((t) => path.resolve(base, t.replace(/\*$/, ''))) });
    } catch { /* no tsconfig */ }
  }
  return out;
}
const tryFile = (p) => [p + '.ts', path.join(p, 'index.ts'), p].find((f) => existsSync(f) && statSync(f).isFile() && f.endsWith('.ts'));
const kindOf = (src, file) => /@Component\(/.test(src) ? 'component' : /@Injectable\(/.test(src) ? 'service' : /@Pipe\(/.test(src) ? 'pipe' : /@Directive\(/.test(src) ? 'directive' : /\.(model|interface|types?)\.ts$/.test(file) ? 'model' : 'util';

async function assetsOf(file, src) {
  const dir = path.dirname(file), out = [];
  const tpl = src.match(/templateUrl\s*:\s*['"`]([^'"`]+)['"`]/);
  const sty = src.match(/styleUrls?\s*:\s*\[?\s*['"`]([^'"`]+)['"`]/);
  if (tpl) out.push({ file: tpl[1], code: await read(path.join(dir, tpl[1])) });
  if (sty) out.push({ file: sty[1], code: await read(path.join(dir, sty[1])) });
  return out;
}

async function collect(repo, root, entry) {
  const aliases = await tsAliases(repo);
  const pkg = await json(path.join(repo, 'package.json'), {});
  const declared = { ...(pkg.dependencies ?? {}), ...(pkg.devDependencies ?? {}) };
  const seen = new Map(), packages = new Map(), unresolved = new Set();
  const queue = [entry];
  while (queue.length && seen.size < 60) {
    const f = queue.shift();
    if (seen.has(f)) continue;
    const src = await read(f);
    seen.set(f, src);
    const specs = [...src.matchAll(/(?:import|export)\s+(?:[^'";]*?\s+from\s+)?['"]([^'"]+)['"]/g), ...src.matchAll(/import\(\s*['"]([^'"]+)['"]\s*\)/g)].map((m) => m[1]);
    for (const spec of specs) {
      if (spec.startsWith('.')) {
        const hit = tryFile(path.resolve(path.dirname(f), spec));
        if (hit && hit.startsWith(root)) queue.push(hit);
        else if (!/\.(scss|css|json|svg|png)$/.test(spec)) unresolved.add(spec + '  (from ' + path.relative(root, f) + ')');
        continue;
      }
      const al = aliases.find((a) => a.prefix && spec.startsWith(a.prefix));
      if (al) {
        const hit = al.targets.map((t) => tryFile(path.join(t, spec.slice(al.prefix.length)))).find(Boolean);
        if (hit && hit.startsWith(repo)) { queue.push(hit); continue; }
        unresolved.add(spec + '  (alias not found)');
        continue;
      }
      if (CORE.test(spec)) continue;
      const name = spec.startsWith('@') ? spec.split('/').slice(0, 2).join('/') : spec.split('/')[0];
      if (declared[name]) packages.set(name, declared[name]);
      else unresolved.add(spec);
    }
  }
  const deps = [];
  for (const [f, src] of seen) {
    if (f === entry) continue;
    deps.push({ file: path.relative(root, f), kind: kindOf(src, f), code: src, assets: await assetsOf(f, src) });
  }
  return { deps, packages: [...packages].map(([name, version]) => ({ name, version })), unresolved: [...unresolved] };
}

async function capture(repoObj, name, selector) {
  const { src: root, path: repo } = repoObj;
  name = String(name || '').replace(/^_+/, '');
  for (const file of await files(root)) {
    const src = await readFile(file, 'utf8');
    if (!src.includes('@Component')) continue;
    const byClass = name && new RegExp('export\\s+(?:default\\s+)?class\\s+' + esc(name) + '\\b').test(src);
    const bySel = selector && new RegExp('selector\\s*:\\s*[\'"`]' + esc(selector) + '[\'"`]').test(src);
    if (!byClass && !bySel) continue;
    const dir = path.dirname(file);
    const tpl = src.match(/templateUrl\s*:\s*['"`]([^'"`]+)['"`]/);
    const sty = src.match(/styleUrls?\s*:\s*\[?\s*['"`]([^'"`]+)['"`]/);
    const inl = src.match(/template\s*:\s*`([\s\S]*?)`/);
    const extra = await collect(repo, root, file);
    return {
      file: path.relative(root, file), ts: src, repo: repoObj.id,
      html: tpl ? { file: tpl[1], code: await read(path.join(dir, tpl[1])) } : inl ? { file: '(inline template)', code: inl[1] } : null,
      styles: sty ? [{ file: sty[1], code: await read(path.join(dir, sty[1])) }] : [],
      ...extra,
    };
  }
  return { error: `No component "${name || selector}" found under ${root}` };
}

/* ---------- insert pattern into a repo ---------- */
const UNDO = path.join(DATA, 'undo');
const posix = (p) => p.split(path.sep).join('/');
function findElement(tpl, tag) {
  const open = new RegExp('<' + esc(tag) + '(?=[\\s>/])', 'g');
  const m = open.exec(tpl);
  if (!m) return null;
  const count = (tpl.match(open) || []).length;
  const start = m.index;
  let i = start + m[0].length, q = null;
  for (; i < tpl.length; i++) { const ch = tpl[i]; if (q) { if (ch === q) q = null; } else if (ch === '"' || ch === "'") q = ch; else if (ch === '>') break; }
  if (tpl[i - 1] === '/') return { start, end: i + 1, count };
  const re = new RegExp('<(/?)' + esc(tag) + '(?=[\\s>/])', 'g');
  re.lastIndex = i + 1;
  let depth = 1, mm;
  while ((mm = re.exec(tpl))) { if (mm[1]) { depth--; if (!depth) return { start, end: tpl.indexOf('>', mm.index) + 1, count }; } else depth++; }
  return { start, end: i + 1, count };
}
function editTemplate(tpl, tag, snippet, position) {
  const el = findElement(tpl, tag);
  if (!el) return null;
  const ls = tpl.lastIndexOf('\n', el.start) + 1;
  const indent = (tpl.slice(ls, el.start).match(/^\s*/) || [''])[0];
  const out = position === 'before' ? tpl.slice(0, ls) + indent + snippet + '\n' + tpl.slice(ls) : tpl.slice(0, el.end) + '\n' + indent + snippet + tpl.slice(el.end);
  return { out, count: el.count };
}
const relSpec = (fromAbs, toAbs) => { let r = posix(path.relative(path.dirname(fromAbs), toAbs)).replace(/\.ts$/, '').replace(/\/index$/, ''); return r.startsWith('.') ? r : './' + r; };
const ngMajor = (pkg) => parseInt(String(pkg?.dependencies?.['@angular/core'] ?? '').replace(/[^\d.]/g, '')) || 0;
const isStandalone = (code, major) => /standalone\s*:\s*true/.test(code) || (!/standalone\s*:\s*false/.test(code) && major >= 19);
const classOf = (code) => (String(code).match(/export\s+(?:default\s+)?class\s+(\w+)/) || [])[1];
function addImport(src, cls, spec) {
  if (new RegExp('import\\s*\\{[^}]*\\b' + cls + '\\b[^}]*\\}\\s*from').test(src)) return src;
  const imp = 'import { ' + cls + " } from '" + spec + "';";
  const all = [...src.matchAll(/^import[^;]*?;/gm)];
  if (all.length) { const l = all[all.length - 1]; const e = l.index + l[0].length; return src.slice(0, e) + '\n' + imp + src.slice(e); }
  return imp + '\n' + src;
}
/** Add cls to an array (imports/declarations/providers) inside @Decorator({...}); creates the key if missing. Bracket-aware. */
function addToArray(src, decorator, key, cls) {
  const c = src.indexOf('@' + decorator + '(');
  if (c < 0) return src;
  let i = c + decorator.length + 2, d = 1;
  for (; i < src.length && d; i++) { if (src[i] === '(') d++; else if (src[i] === ')') d--; }
  const end = i;
  const re = new RegExp('\\b' + key + '\\s*:\\s*\\[', 'g');
  re.lastIndex = c;
  const m = re.exec(src);
  if (m && m.index < end) {
    const open = m.index + m[0].length;
    let j = open, dd = 1;
    for (; j < src.length && dd; j++) { if (src[j] === '[') dd++; else if (src[j] === ']') dd--; }
    const close = j - 1, inner = src.slice(open, close);
    if (new RegExp('\\b' + cls + '\\b').test(inner)) return src;
    let k = close;
    while (k > open && /\s/.test(src[k - 1])) k--;
    const t = src.slice(open, k).trim();
    return src.slice(0, k) + (t ? (t.endsWith(',') ? ' ' : ', ') + cls : cls) + src.slice(k);
  }
  const ob = src.indexOf('{', c);
  if (ob < 0 || ob > end) return src;
  return src.slice(0, ob + 1) + '\n  ' + key + ': [' + cls + '],' + src.slice(ob + 1);
}
function makeStandalone(code, children) {
  let out = /standalone\s*:\s*false/.test(code) ? code.replace(/standalone\s*:\s*false/, 'standalone: true') : /standalone\s*:/.test(code) ? code : code.replace(/@(Component|Directive|Pipe)\(\{/, (m) => m + '\n  standalone: true,');
  if (/@Component\(/.test(out)) {
    out = addImport(out, 'CommonModule', '@angular/common');
    out = addToArray(out, 'Component', 'imports', 'CommonModule');
    for (const ch of children) { out = addImport(out, ch.cls, ch.spec); out = addToArray(out, 'Component', 'imports', ch.cls); }
  }
  return out;
}
async function walkExt(dir, re, out = []) {
  let list = [];
  try { list = await readdir(dir, { withFileTypes: true }); } catch { return out; }
  for (const e of list) { if (SKIP.has(e.name)) continue; const p = path.join(dir, e.name); if (e.isDirectory()) await walkExt(p, re, out); else if (re.test(e.name)) out.push(p); }
  return out;
}
const styleFiles = (dir) => walkExt(dir, /\.(s?css|sass)$/);
async function globalStyles(repoPath, tsrc) {
  try {
    const aj = await json(path.join(repoPath, 'angular.json'), {});
    for (const pr of Object.values(aj.projects ?? {})) {
      for (const e of pr?.architect?.build?.options?.styles ?? []) { const f = typeof e === 'string' ? e : e?.input; if (f && /\.(s?css)$/.test(f) && !f.includes('node_modules')) return path.join(repoPath, f); }
    }
  } catch { /* ignore */ }
  return ['styles.scss', 'styles.css'].map((f) => path.join(tsrc, f)).find(existsSync) ?? path.join(tsrc, 'styles.scss');
}
function scssResolve(dir, spec) {
  const p = path.resolve(dir, spec), d = path.dirname(p), bn = path.basename(p);
  return [p, p + '.scss', path.join(d, '_' + bn + '.scss'), p + '.css', path.join(d, '_' + bn), path.join(p, '_index.scss'), path.join(p, 'index.scss')].find((f) => existsSync(f) && statSync(f).isFile());
}
function requiredInputs(ts) {
  const out = [];
  for (const m of ts.matchAll(/(\w+)\s*=\s*input\.required<([^>]+)>\(/g)) out.push({ name: m[1], type: m[2].trim() });
  for (const m of ts.matchAll(/@Input\(\s*\{[^}]*required\s*:\s*true[^}]*\}\s*\)\s*(?:set\s+)?(\w+)\s*[!?]?\s*:\s*([^;=\n{]+)/g)) out.push({ name: m[1], type: m[2].trim() });
  return out.map((x) => ({ ...x, placeholder: /\[\]$|^Array</.test(x.type) ? '[]' : /^string$/.test(x.type) ? "''" : /^number$/.test(x.type) ? '0' : /^boolean$/.test(x.type) ? 'false' : '$any({})' }));
}
async function findModule(tsrc, parentCls, base) {
  for (const f of await files_(tsrc)) {
    if (f.startsWith(base)) continue;
    const c = await read(f);
    if (!c.includes('@NgModule')) continue;
    const m = c.match(/declarations\s*:\s*\[([\s\S]*?)\]/);
    if (m && new RegExp('\\b' + parentCls + '\\b').test(m[1])) return f;
  }
  return null;
}

async function buildPlan(b) {
  const st = await settings();
  const repo = st.repos.find((r) => r.id === b.repoId);
  if (!repo) throw new Error('Pick a repo first.');
  const tsrc = path.join(repo.path, 'src');
  const entry = (await json(STORE, [])).find((x) => x?.p?.id === b.patternId);
  const resp = entry?.resp;
  if (!resp?.ts) throw new Error('This pattern has no captured source. Capture it from a running repo first.');
  const srepo = st.repos.find((r) => r.id === resp.repo) ?? null;
  const ssrc = srepo ? path.join(srepo.path, 'src') : null;
  const warnings = [], edits = [];
  const rel = (abs) => posix(path.relative(repo.path, abs));
  const tpkg = await json(path.join(repo.path, 'package.json'), {});
  const major = ngMajor(tpkg);
  const smajor = srepo ? ngMajor(await json(path.join(srepo.path, 'package.json'), {})) : major;
  const cls = classOf(resp.ts);
  const sel = (resp.ts.match(/selector\s*:\s*['"`]([^'"`]+)['"`]/) || [])[1];
  if (!cls || !sel) throw new Error('Could not read the class name or selector from the captured component.');
  const name = entry.p.name || entry.p.id;
  const base = path.join(tsrc, 'app/patterns', slug(name));
  const dest = (r) => path.join(base, r);
  const writes = new Map();
  const mods = new Map();
  const getMod = async (abs) => (mods.has(abs) ? mods.get(abs) : await read(abs));
  const add = (r, code) => { if (r.startsWith('..')) { warnings.push('Skipped file outside src: ' + r); return; } writes.set(dest(r), { code, rel: r }); };
  add(resp.file, resp.ts);
  const dir = path.dirname(resp.file);
  if (resp.html && resp.html.file !== '(inline template)') add(path.join(dir, resp.html.file), resp.html.code);
  for (const s2 of resp.styles ?? []) add(path.join(dir, s2.file), s2.code);
  for (const d of resp.deps ?? []) { add(d.file, d.code); for (const a2 of d.assets ?? []) add(path.join(path.dirname(d.file), a2.file), a2.code); }
  const compAbs = dest(resp.file);

  /* 2 · rewrite path aliases to relative paths */
  let rewrote = 0;
  const leftAliases = new Set();
  const targetAliases = await tsAliases(repo.path);
  if (ssrc) {
    const aliases = await tsAliases(srepo.path);
    for (const [abs, w] of writes) {
      if (!w.rel.endsWith('.ts')) continue;
      w.code = w.code.replace(/(from\s+|import\(\s*)(['"])([^'"]+)\2/g, (m, pre, q, spec) => {
        if (spec.startsWith('.')) return m;
        const al = aliases.find((x) => x.prefix && spec.startsWith(x.prefix));
        if (!al) return m;
        const hit = al.targets.map((t) => tryFile(path.join(t, spec.slice(al.prefix.length)))).find(Boolean);
        const d = hit ? dest(path.relative(ssrc, hit)) : null;
        if (!d || !writes.has(d)) { if (!targetAliases.some((x) => x.prefix && spec.startsWith(x.prefix))) leftAliases.add(spec); return m; }
        rewrote++;
        return pre + q + relSpec(abs, d) + q;
      });
    }
  } else warnings.push('Source repo is not in your repo list, so path aliases, SCSS partials, assets and theme variables could not be copied. Add it with Add repo.');
  if (rewrote) edits.push({ file: rel(base), desc: 'Rewrote ' + rewrote + ' path alias import(s) to relative paths', snippet: "@app/... → './...'" });
  if (leftAliases.size) warnings.push('Alias imports the target repo cannot resolve: ' + [...leftAliases].join(', '));

  /* 4a · SCSS partials */
  if (ssrc) {
    const queue = [...writes.entries()].filter(([, w]) => /\.(s?css|sass)$/.test(w.rel));
    while (queue.length) {
      const [abs, w] = queue.shift();
      const sdir = path.dirname(path.join(ssrc, w.rel));
      const found = [];
      for (const m of w.code.matchAll(/@(?:use|import|forward)\s+['"]([^'"]+)['"]/g)) {
        const spec = m[1];
        if (/^(sass:|~|@angular|http|url\()/.test(spec)) continue;
        const hit = scssResolve(sdir, spec) ?? (spec.startsWith('.') ? null : scssResolve(ssrc, spec));
        if (!hit) { warnings.push('SCSS import not found: ' + spec); continue; }
        const r = path.relative(ssrc, hit);
        if (r.startsWith('..')) { warnings.push('SCSS import outside src: ' + spec); continue; }
        const d = dest(r);
        found.push({ spec, d });
        if (!writes.has(d)) { const nw = { code: await read(hit), rel: r }; writes.set(d, nw); queue.push([d, nw]); }
      }
      for (const f of found) {
        if (f.spec.startsWith('.')) continue;
        let r = posix(path.relative(path.dirname(abs), f.d)).replace(/\.s?css$/, '').replace(/(^|\/)_([^/]+)$/, '$1$2');
        if (!r.startsWith('.')) r = './' + r;
        w.code = w.code.split("'" + f.spec + "'").join("'" + r + "'").split('"' + f.spec + '"').join('"' + r + '"');
      }
    }
  }

  /* 4b · assets */
  const tAssetBase = existsSync(path.join(tsrc, 'assets')) ? tsrc : existsSync(path.join(repo.path, 'public')) ? path.join(repo.path, 'public') : tsrc;
  let assetCount = 0;
  for (const [, w] of [...writes]) {
    if (!w.code) continue;
    for (const m of String(w.code).matchAll(/(?:^|['"(\s/])(assets\/[\w\-./@%]+?\.[a-z0-9]{2,5})(?=['")\s?#])/gi)) {
      const a2 = m[1];
      if (existsSync(path.join(tsrc, a2)) || existsSync(path.join(repo.path, 'public', a2))) continue;
      const from = [ssrc && path.join(ssrc, a2), srepo && path.join(srepo.path, 'public', a2)].filter(Boolean).find((f) => existsSync(f));
      if (!from) { warnings.push('Asset not found in either repo: ' + a2); continue; }
      const to = path.join(tAssetBase, a2);
      if (!writes.has(to)) { writes.set(to, { from, rel: a2, asset: true }); assetCount++; }
    }
  }

  /* 4c · CSS custom properties (theme variables) */
  const used = new Set(), defined = new Set();
  for (const [, w] of writes) if (w.code) { for (const m of w.code.matchAll(/var\(\s*--([\w-]+)/g)) used.add(m[1]); for (const m of w.code.matchAll(/--([\w-]+)\s*:/g)) defined.add(m[1]); }
  if (used.size) {
    for (const f of await styleFiles(tsrc)) { if (f.startsWith(base)) continue; for (const m of (await read(f)).matchAll(/--([\w-]+)\s*:/g)) defined.add(m[1]); }
    const missing = [...used].filter((v) => !defined.has(v));
    if (missing.length) {
      const srcDefs = new Map();
      if (ssrc) for (const f of await styleFiles(ssrc)) for (const m of (await read(f)).matchAll(/--([\w-]+)\s*:\s*([^;{}]+);/g)) if (!srcDefs.has(m[1])) srcDefs.set(m[1], m[2].trim());
      const take = [], queue2 = [...missing];
      while (queue2.length) { const v = queue2.shift(); if (take.includes(v) || !srcDefs.has(v)) continue; take.push(v); for (const m of srcDefs.get(v).matchAll(/var\(\s*--([\w-]+)/g)) if (!defined.has(m[1])) queue2.push(m[1]); }
      const none = missing.filter((v) => !srcDefs.has(v));
      if (take.length) {
        const gs = await globalStyles(repo.path, tsrc);
        mods.set(gs, (await getMod(gs)) + '\n/* Added by Design Playground for ' + name + ' */\n:root {\n' + take.map((v) => '  --' + v + ': ' + srcDefs.get(v) + ';').join('\n') + '\n}\n');
        edits.push({ file: rel(gs), desc: 'Add ' + take.length + ' theme variable(s) from the source repo', snippet: take.map((v) => '--' + v).join(', ') });
      }
      if (none.length) warnings.push('CSS variables not defined in either repo: ' + none.map((v) => '--' + v).join(', '));
    }
  }

  /* 5 · required inputs */
  const inputs = requiredInputs(resp.ts);
  const snippet = '<' + sel + inputs.map((x) => ' [' + x.name + ']="' + x.placeholder + '"').join('') + '></' + sel + '>';

  /* find the page component whose template contains the target tag */
  const tag = String(b.tag || '');
  if (!tag) throw new Error('Choose a section on the page.');
  let parent = null;
  for (const f of await files_(tsrc)) {
    if (f.startsWith(base)) continue;
    const code = await read(f);
    if (!code.includes('@Component')) continue;
    const tpl = code.match(/templateUrl\s*:\s*['"`]([^'"`]+)['"`]/);
    const inl = code.match(/template\s*:\s*`([\s\S]*?)`/);
    const tplFile = tpl ? path.join(path.dirname(f), tpl[1]) : null;
    const tplCode = tpl ? await read(tplFile) : inl ? inl[1] : '';
    if (new RegExp('<' + esc(tag) + '(?=[\\s>/])').test(tplCode)) { parent = { ts: f, code, tplFile, tplCode, inline: !tpl }; break; }
  }

  const declarables = (resp.deps ?? []).filter((d) => ['component', 'directive', 'pipe'].includes(d.kind) && !d.file.startsWith('..')).map((d) => ({ abs: dest(d.file), cls: classOf(d.code), standalone: isStandalone(d.code, smajor) })).filter((d) => d.cls);
  const patternStandalone = isStandalone(resp.ts, smajor);
  let host = null;
  if (!parent) warnings.push('<' + tag + '> is not written in any component template (it may be loaded by the router). Files will be copied, but nothing is wired into the page.');
  else {
    const r = editTemplate(parent.tplCode, tag, snippet, b.position === 'before' ? 'before' : 'after');
    if (r.count > 1) warnings.push('<' + tag + '> appears ' + r.count + ' times in that template. The first one is used.');
    if (parent.inline) mods.set(parent.ts, parent.code.replace(parent.tplCode, () => r.out));
    else mods.set(parent.tplFile, r.out);
    edits.push({ file: rel(parent.tplFile ?? parent.ts), desc: (b.position === 'before' ? 'Insert before <' : 'Insert after <') + tag + '>', snippet });
    const parentCls = classOf(parent.code);
    if (isStandalone(parent.code, major)) {
      if (!patternStandalone) {
        for (const d of declarables) if (!d.standalone) { const w = writes.get(d.abs); if (w) w.code = makeStandalone(w.code, []); }
        const main = writes.get(compAbs);
        main.code = makeStandalone(main.code, declarables.map((d) => ({ cls: d.cls, spec: relSpec(compAbs, d.abs) })));
        edits.push({ file: rel(compAbs), desc: 'Converted pattern to standalone (page is standalone)', snippet: 'standalone: true, imports: [CommonModule, …]' });
        warnings.push('Pattern was converted to standalone. If it uses forms or other NgModules, add them to its imports.');
      }
      let pc = await getMod(parent.ts);
      pc = addToArray(addImport(pc, cls, relSpec(parent.ts, compAbs)), 'Component', 'imports', cls);
      mods.set(parent.ts, pc);
      host = { abs: parent.ts, decorator: 'Component' };
      edits.push({ file: rel(parent.ts), desc: 'Import and register ' + cls, snippet: 'imports: [' + cls + ', …]' });
    } else {
      const mod = await findModule(tsrc, parentCls, base);
      if (!mod) warnings.push('Could not find the NgModule that declares ' + parentCls + '. Register ' + cls + ' there yourself.');
      else {
        let mc = await getMod(mod);
        mc = addToArray(addImport(mc, cls, relSpec(mod, compAbs)), 'NgModule', patternStandalone ? 'imports' : 'declarations', cls);
        const extra = [];
        if (!patternStandalone) for (const d of declarables) if (!d.standalone) { mc = addToArray(addImport(mc, d.cls, relSpec(mod, d.abs)), 'NgModule', 'declarations', d.cls); extra.push(d.cls); }
        mods.set(mod, mc);
        host = { abs: mod, decorator: 'NgModule' };
        edits.push({ file: rel(mod), desc: 'Register in ' + (classOf(mc) || 'NgModule'), snippet: (patternStandalone ? 'imports: [' : 'declarations: [') + [cls, ...extra].join(', ') + ', …]' });
      }
    }
    /* 3 · services that are not providedIn root */
    const svc = (resp.deps ?? []).filter((d) => d.kind === 'service' && !/providedIn\s*:/.test(d.code) && !d.file.startsWith('..')).map((d) => ({ cls: classOf(d.code), abs: dest(d.file) })).filter((d) => d.cls);
    if (svc.length && host) {
      let hc = await getMod(host.abs);
      for (const sv of svc) hc = addToArray(addImport(hc, sv.cls, relSpec(host.abs, sv.abs)), host.decorator, 'providers', sv.cls);
      mods.set(host.abs, hc);
      edits.push({ file: rel(host.abs), desc: 'Provide ' + svc.length + ' service(s)', snippet: 'providers: [' + svc.map((x) => x.cls).join(', ') + ', …]' });
    }
  }

  const files = [];
  for (const [abs, w] of writes) {
    const exists = existsSync(abs);
    files.push({ path: rel(abs), status: !exists ? 'new' : w.asset ? 'same' : (await read(abs)) === w.code ? 'same' : 'overwrite' });
  }
  if (assetCount) edits.push({ file: rel(tAssetBase), desc: 'Copy ' + assetCount + ' asset file(s) from the source repo', snippet: 'assets/…' });
  const have = { ...(tpkg.dependencies ?? {}), ...(tpkg.devDependencies ?? {}) };
  const missing = (resp.packages ?? []).filter((p) => !have[p.name]);
  for (const u of resp.unresolved ?? []) warnings.push('Unresolved in source repo: ' + u);
  return { repo, writes, mods, plan: { files, edits, warnings, inputs, missing, command: missing.length ? 'npm install ' + missing.map((m) => m.name + '@' + m.version).join(' ') : '', target: parent ? rel(parent.ts) : null } };
}
async function applyPlan(b) {
  const r = await buildPlan(b);
  const id = String(Date.now());
  const dir = path.join(UNDO, id);
  await mkdir(path.join(dir, 'files'), { recursive: true });
  const manifest = { repo: r.repo.path, created: [], modified: [] };
  let n = 0;
  const backup = async (abs) => { if (existsSync(abs)) { const bk = path.join(dir, 'files', String(n++)); await copyFile(abs, bk); manifest.modified.push({ abs, backup: bk }); } else manifest.created.push(abs); await mkdir(path.dirname(abs), { recursive: true }); };
  for (const [abs, w] of r.writes) {
    if (w.asset) { if (existsSync(abs)) continue; await backup(abs); await copyFile(w.from, abs); continue; }
    if (existsSync(abs) && (await read(abs)) === w.code) continue;
    await backup(abs); await writeFile(abs, w.code);
  }
  for (const [abs, code] of r.mods) { await backup(abs); await writeFile(abs, code); }
  await writeFile(path.join(dir, 'manifest.json'), JSON.stringify(manifest));
  let install = '';
  if (b.install && r.plan.command) install = await new Promise((ok) => exec(r.plan.command, { cwd: r.repo.path, timeout: 240000 }, (e, so, se) => ok(e ? 'npm install failed: ' + String(se || e.message).split('\n').slice(-4).join(' ') : 'npm install done.')));
  return { id, plan: r.plan, install };
}
const files_ = (root) => files(root);

/* ---------- http ---------- */
http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost');
  const p = url.pathname;
  try {
    if (req.method === 'OPTIONS') return send(res, 204);
    if (p === '/health') {
      const r = await activeRepo();
      if (!r) return send(res, 200, { ok: true, root: '', components: 0, warning: 'No repo added yet. Add one in the playground or run: npm run repo -- /path/to/repo' });
      if (!existsSync(r.src)) return send(res, 200, { ok: false, root: r.src, error: 'Folder not found' });
      return send(res, 200, { ok: true, repo: r.name, root: r.src, components: (await files(r.src)).length });
    }
    if (p === '/component') {
      const r = await activeRepo();
      if (!r) return send(res, 400, { error: 'No repo selected. Add one in the playground first.' });
      if (!existsSync(r.src)) return send(res, 400, { error: 'Folder not found: ' + r.src });
      const out = await capture(r, url.searchParams.get('name'), url.searchParams.get('selector'));
      return send(res, out.error ? 404 : 200, out);
    }
    if (p === '/api/insert/plan' && req.method === 'POST') { try { const r = await buildPlan(await readBody(req)); return send(res, 200, r.plan); } catch (e) { return send(res, 400, { error: e.message }); } }
    if (p === '/api/insert/apply' && req.method === 'POST') { try { return send(res, 200, await applyPlan(await readBody(req))); } catch (e) { return send(res, 400, { error: e.message }); } }
    if (p === '/api/insert/undo' && req.method === 'POST') {
      const b = await readBody(req);
      const m = await json(path.join(UNDO, String(b.id), 'manifest.json'), null);
      if (!m) return send(res, 404, { error: 'Nothing to undo.' });
      for (const x of m.modified) await copyFile(x.backup, x.abs);
      for (const c of m.created) { try { await unlink(c); } catch { /* gone */ } }
      await rm(path.join(UNDO, String(b.id)), { recursive: true, force: true });
      return send(res, 200, { ok: true });
    }
    if (p === '/api/repos' && req.method === 'GET') { const s = await settings(); return send(res, 200, { repos: s.repos, active: (await activeRepo())?.id ?? null }); }
    if (p === '/api/repos' && req.method === 'POST') {
      const b = await readBody(req);
      let repo = path.resolve(String(b.path || '').replace(/^~(?=\/)/, process.env.HOME ?? '~'));
      if (path.basename(repo) === 'src' && existsSync(path.join(path.dirname(repo), 'angular.json'))) repo = path.dirname(repo);
      if (!existsSync(path.join(repo, 'angular.json'))) return send(res, 400, { error: 'No angular.json found in ' + repo + '. Enter the repo root folder.' });
      const s = await settings();
      const id = slug(b.name || path.basename(repo));
      const entry = { id, name: b.name || path.basename(repo), path: repo, url: b.url || 'http://localhost:4200' };
      s.repos = s.repos.filter((x) => x.id !== id && x.path !== repo).concat(entry);
      s.active = id;
      await saveSettings(s);
      let log = [];
      try { log = installInspector(repo); } catch (e) { log = ['Inspector install failed: ' + e.message]; }
      return send(res, 200, { ok: true, repo: entry, log });
    }
    let m = p.match(/^\/api\/repos\/([^/]+)$/);
    if (m && req.method === 'PUT') { const s = await settings(); if (!s.repos.find((x) => x.id === m[1])) return send(res, 404, { error: 'Unknown repo' }); s.active = m[1]; await saveSettings(s); return send(res, 200, { ok: true }); }
    if (m && req.method === 'DELETE') { const s = await settings(); s.repos = s.repos.filter((x) => x.id !== m[1]); if (s.active === m[1]) s.active = s.repos[0]?.id; await saveSettings(s); return send(res, 200, { ok: true }); }
    const del = p.match(/^\/api\/added(?:\/([^/]+))?$/);
    if (del && req.method === 'DELETE') {
      const id = del[1] ? decodeURIComponent(del[1]) : null;
      const all = await json(STORE, []);
      await mkdir(DATA, { recursive: true });
      await writeFile(STORE, JSON.stringify(id ? all.filter((x) => x?.p?.id !== id) : [], null, 2));
      return send(res, 200, { ok: true });
    }
    if (p === '/api/added') {
      if (req.method === 'POST') {
        const b = await readBody(req);
        if (!b?.p?.id) return send(res, 400, { error: 'Bad pattern' });
        const all = await json(STORE, []);
        const i = all.findIndex((x) => x?.p?.id === b.p.id);
        if (i >= 0) all[i] = b; else all.push(b);
        await mkdir(DATA, { recursive: true });
        await writeFile(STORE, JSON.stringify(all, null, 2));
        return send(res, 200, { ok: true });
      }
      return send(res, 200, await json(STORE, []));
    }
    if (p.startsWith('/api/')) return send(res, 404, { error: 'Not found' });
    let f = path.join(PUBLIC, p === '/' ? 'index.html' : path.normalize(p).replace(/^(\.\.[/\\])+/, ''));
    if (!f.startsWith(PUBLIC) || !existsSync(f) || statSync(f).isDirectory()) f = path.join(PUBLIC, 'index.html');
    res.writeHead(200, { 'Content-Type': MIME[path.extname(f)] ?? 'application/octet-stream' });
    createReadStream(f).pipe(res);
  } catch (e) { send(res, 500, { error: String(e?.message ?? e) }); }
}).listen(PORT, HOST, async () => {
  const r = await activeRepo();
  console.log(`\nDesign Playground → http://localhost:${PORT}`);
  console.log(`  patterns saved in: ${STORE}`);
  console.log(r ? `  active repo: ${r.name} (${r.path})` : '  no repo added yet: add one in the app (Add pattern) or run: npm run repo -- /path/to/repo');
});
