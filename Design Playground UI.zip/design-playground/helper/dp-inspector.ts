/**
 * Design Playground inspector — DEV ONLY.
 *
 * Lets Design Playground highlight and pick Angular components on this page
 * when the app is opened inside the playground's "Add pattern" frame.
 * It does nothing when the app is not framed, and never ships to production
 * if you load it behind isDevMode() (see README).
 *
 * Save as: src/app/dev/dp-inspector.ts
 */
declare const ng: { getComponent<T = unknown>(el: Element): T | null } | undefined;

export interface InspectorOptions {
  /** Origins allowed to drive the inspector, e.g. ['https://playground.acme.dev']. Default: any (dev only). */
  allowedOrigins?: string[];
  /** Highlight colour. */
  color?: string;
}

export function installDesignPlaygroundInspector(opts: InspectorOptions = {}): void {
  if (window.parent === window) {
    console.info('[dp-inspector] loaded, idle (page is not inside the playground frame).');
    return;
  }
  console.info('[dp-inspector] loaded inside the playground frame.');
  if (typeof ng === 'undefined' || !ng?.getComponent) {
    console.warn('[dp-inspector] Angular debug API not found. Run the app in dev mode (ng serve).');
    return;
  }
  const color = opts.color ?? '#0090BA';
  let parentOrigin: string | null = null;
  let active = false;
  let current: Element | null = null;

  const box = document.createElement('div');
  const tag = document.createElement('div');
  Object.assign(box.style, {
    position: 'fixed', pointerEvents: 'none', zIndex: '2147483646', display: 'none',
    border: `2px solid ${color}`, background: `${color}14`, borderRadius: '4px',
  });
  Object.assign(tag.style, {
    position: 'fixed', pointerEvents: 'none', zIndex: '2147483647', display: 'none', whiteSpace: 'nowrap',
    background: color, color: '#fff', font: '600 11px/1 ui-monospace, Menlo, monospace', padding: '4px 6px', borderRadius: '4px',
  });
  document.body.append(box, tag);

  /** Nearest element (self or ancestor) that hosts an Angular component. */
  const cache = new WeakMap<Element, Element | null>();
  const hostOf = (el: Element | null): Element | null => {
    if (!el) return null;
    if (cache.has(el)) return cache.get(el)!;
    let found: Element | null = null;
    for (let n: Element | null = el; n && n !== document.documentElement; n = n.parentElement) {
      try { if (ng!.getComponent(n)) { found = n; break; } } catch { /* not a component host */ }
    }
    cache.set(el, found);
    return found;
  };

  const nameOf = (n: Element): string => { try { const c = ng!.getComponent<any>(n); return c ? String(c.constructor?.name ?? '').replace(/^_+/, '') : ''; } catch { return ''; } };
  const instancesOf = (ctor: any): Element[] => {
    const name = String(ctor?.name ?? '').replace(/^_+/, '');
    return Array.from(document.querySelectorAll('*')).filter((n) => nameOf(n) === name);
  };

  /** Show only one component (keeps overlays like dropdown/calendar working). */
  const isolate = (name: string, index: number, dark: boolean): boolean => {
    const all = Array.from(document.querySelectorAll('*')).filter((n) => nameOf(n) === name);
    const el = all[index] ?? all[0];
    if (!el) return false;
    const keep = /overlay|cdk|popover|tooltip|dialog|modal|menu|toast|snack|datepicker|calendar|dropdown/i;
    let node: Element = el;
    while (node.parentElement) {
      const par = node.parentElement;
      Array.from(par.children).forEach((c) => {
        if (c === node || ['SCRIPT', 'STYLE', 'LINK', 'META'].includes(c.tagName)) return;
        if (keep.test(String((c as HTMLElement).className ?? '')) || keep.test(c.tagName)) return;
        c.setAttribute('data-dp-hide', '');
      });
      if (par !== document.body && par !== document.documentElement) par.setAttribute('data-dp-anc', '');
      node = par;
    }
    el.setAttribute('data-dp-target', '');
    if (!document.getElementById('dp-iso-style')) {
      const st = document.createElement('style');
      st.id = 'dp-iso-style';
      st.textContent = '[data-dp-hide]{display:none!important}[data-dp-anc]{display:block!important;margin:0!important;padding:0!important;width:auto!important;max-width:none!important;height:auto!important;min-height:0!important;position:static!important;overflow:visible!important;border:0!important;box-shadow:none!important;background:transparent!important;transform:none!important}html,body{height:auto!important;overflow:auto!important}body{padding:20px!important;box-sizing:border-box}[data-dp-target]{display:block}';
      document.head.appendChild(st);
    }
    setTheme(dark);
    return true;
  };
  const setTheme = (dark: boolean) => {
    const r = document.documentElement;
    r.classList.toggle('dark', dark);
    if (dark) r.setAttribute('data-theme', 'dark'); else if (r.getAttribute('data-theme') === 'dark') r.setAttribute('data-theme', 'light');
  };

  const describe = (el: Element) => {
    const cmp = ng!.getComponent<any>(el);
    const ctor = cmp?.constructor;
    const def = ctor?.ɵcmp;
    const r = el.getBoundingClientRect();
    return {
      component: String(ctor?.name ?? '').replace(/^_+/, ''), // dev builds may prefix "_"
      selector: el.tagName.toLowerCase(),
      inputs: def?.inputs ? Object.keys(def.inputs) : [],
      route: location.pathname + location.search,
      href: location.href,
      index: instancesOf(ctor).indexOf(el),
      rect: { x: r.x, y: r.y, width: r.width, height: r.height },
      outerHTML: el.outerHTML.slice(0, 20_000),
      htmlClass: document.documentElement.className,
      bodyClass: document.body.className,
      headHtml: Array.from(document.head.querySelectorAll('link[rel="stylesheet"], style')).map((n) => n.outerHTML).join('\n').slice(0, 400_000),
    };
  };

  const draw = (el: Element | null) => {
    if (el === current && el) return;
    current = el;
    if (!el) { box.style.display = 'none'; tag.style.display = 'none'; return; }
    const r = el.getBoundingClientRect();
    Object.assign(box.style, { display: 'block', left: `${r.left}px`, top: `${r.top}px`, width: `${r.width}px`, height: `${r.height}px` });
    tag.textContent = `<${el.tagName.toLowerCase()}>  ${Math.round(r.width)}×${Math.round(r.height)}`;
    Object.assign(tag.style, { display: 'block', left: `${r.left}px`, top: `${Math.max(0, r.top - 22)}px` });
  };

  const send = (msg: object) => { if (parentOrigin) window.parent.postMessage(msg, parentOrigin); };

  const setActive = (on: boolean) => {
    active = on;
    draw(null);
    document.documentElement.style.cursor = on ? 'crosshair' : '';
    send({ type: 'dp:inspect-state', on });
  };

  const block = (e: Event) => { if (active) { e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation(); } };

  let raf = 0, lastTarget: Element | null = null;
  window.addEventListener('mousemove', (e) => {
    if (!active) return;
    lastTarget = e.target as Element;
    if (raf) return;
    raf = requestAnimationFrame(() => { raf = 0; draw(hostOf(lastTarget)); });
  }, true);
  window.addEventListener('pointerdown', block, true);
  window.addEventListener('mousedown', block, true);
  window.addEventListener('click', (e) => {
    if (!active || !current) return;
    block(e);
    send({ type: 'dp:selected', ...describe(current) });
  }, true);
  window.addEventListener('keydown', (e) => {
    if (!active || !current) return;
    if (e.key === 'ArrowUp') { const p = hostOf(current.parentElement); if (p) { e.preventDefault(); draw(p); } }
    if (e.key === 'Escape') setActive(false);
  }, true);
  window.addEventListener('scroll', () => { if (current) { const c = current; current = null; draw(c); } }, true);

  /** Page sections (component hosts) for the "Insert pattern" flow. */
  const sections = () => {
    const out: { name: string; tag: string; index: number; depth: number }[] = [];
    const visit = (root: Element, depth: number) => {
      for (const c of Array.from(root.children)) {
        const name = nameOf(c);
        const tag = c.tagName.toLowerCase();
        const r = (c as HTMLElement).getBoundingClientRect();
        const isCmp = !!name && tag.includes('-') && tag !== 'router-outlet';
        if (isCmp && depth > 0 && depth <= 3 && r.width > 0 && r.height > 0) out.push({ name, tag, index: Array.from(document.querySelectorAll(tag)).indexOf(c), depth });
        if (depth < 6) visit(c, isCmp ? depth + 1 : depth);
      }
    };
    visit(document.body, 0);
    return out;
  };
  let hl: HTMLElement | null = null;
  let hlT: { tag: string; index: number } | null = null;
  const place = () => {
    if (!hl) return;
    const el = hlT ? document.querySelectorAll(hlT.tag)[hlT.index] : null;
    if (!el) { hl.style.display = 'none'; return; }
    const r = el.getBoundingClientRect();
    Object.assign(hl.style, { display: 'block', left: r.left + 'px', top: r.top + 'px', width: r.width + 'px', height: r.height + 'px' });
  };
  const highlight = (tag: string | null, index: number, scroll: boolean) => {
    if (!hl) {
      hl = document.createElement('div');
      hl.style.cssText = 'position:fixed;z-index:2147483646;pointer-events:none;border:2px solid #0090BA;background:rgba(0,144,186,.14);border-radius:4px;transition:all .12s;display:none';
      document.body.appendChild(hl);
      window.addEventListener('scroll', place, true);
      window.addEventListener('resize', place);
    }
    hlT = tag ? { tag, index } : null;
    const el = tag ? document.querySelectorAll(tag)[index] : null;
    if (el && scroll) { const r = el.getBoundingClientRect(); if (r.top < 0 || r.bottom > innerHeight) window.scrollTo({ top: window.scrollY + r.top - 80, behavior: 'smooth' }); }
    place();
  };

  window.addEventListener('message', (e: MessageEvent) => {
    const d = e.data;
    if (!d || typeof d.type !== 'string' || !d.type.startsWith('dp:')) return;
    if (opts.allowedOrigins && !opts.allowedOrigins.includes(e.origin)) return;
    parentOrigin = e.origin;
    if (d.type === 'dp:hello') {
      send({ type: 'dp:ready', angular: document.querySelector('[ng-version]')?.getAttribute('ng-version') ?? null, route: location.pathname });
    }
    if (d.type === 'dp:inspect') setActive(!!d.on);
    if (d.type === 'dp:isolate') send({ type: isolate(String(d.component ?? ''), Number(d.index ?? 0), !!d.dark) ? 'dp:isolated' : 'dp:isolate-failed' });
    if (d.type === 'dp:theme') setTheme(!!d.dark);
    if (d.type === 'dp:sections') send({ type: 'dp:sections', sections: sections() });
    if (d.type === 'dp:highlight') highlight(d.tag ?? null, Number(d.index ?? 0), !!d.scroll);
  });
}
