# Design Playground

The playground UI, the capture server and the inspector helper, all in one folder. No `npm install` needed (no dependencies, Node 18+).

```
design-playground/
  public/index.html          the playground UI
  server.mjs                 serves the UI, saves patterns, reads your repo's source
  helper/dp-inspector.ts     dev-only script that goes into the repo you capture from
  scripts/set-repo.mjs       one command that connects a repo
  data/patterns.json         patterns you add (created on first save)
```

## Setup (once per repo)

```bash
cd design-playground
npm run repo -- /path/to/your/angular-repo
```
This points the playground at that repo's `src` folder, copies the inspector into `src/app/dev/`, and hooks it into `src/main.ts` (dev mode only; backup saved as `main.ts.bak`). Then restart your repo with `npm start`.

## Run

```bash
# Terminal 1: your Angular repo
npm start                  # e.g. http://localhost:4200

# Terminal 2: the playground
cd design-playground
npm start                  # http://localhost:4300
```

## Add a pattern

1. Open http://localhost:4300, sign in.
2. Add pattern → Page URL `http://localhost:4200/` → Check connection → Load page.
3. Select section → click a component → name it → Save.

The pattern is written to `data/patterns.json` in this folder and appears for everyone using this playground.

## Notes

- Capture server address in the UI is already `http://localhost:4300` (this server).
- The repo is read from `data/settings.json`. Change it any time with `npm run repo -- <path>`.
- Different port: `PORT=5000 npm start`.
- Troubleshooting: "Inspector not detected" means the repo isn't running in dev mode or `main.ts` isn't hooked. "Capture server" red means the playground server isn't running.
