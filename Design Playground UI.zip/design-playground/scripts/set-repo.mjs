#!/usr/bin/env node
// Usage: npm run repo -- /path/to/your/angular-repo   (adds the repo to the playground and installs the inspector)
import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { join, resolve, dirname, basename } from 'node:path';
import { fileURLToPath } from 'node:url';
import { installInspector } from './inspector.mjs';

const here = dirname(fileURLToPath(import.meta.url));
const repo = resolve(process.argv[2] || '');
if (!process.argv[2] || !existsSync(join(repo, 'angular.json'))) {
  console.error('\nUsage: npm run repo -- /path/to/your/angular-repo\n(angular.json must be in that folder)\n');
  process.exit(1);
}
const file = join(here, '../data/settings.json');
mkdirSync(join(here, '../data'), { recursive: true });
let s = {};
try { s = JSON.parse(readFileSync(file, 'utf8')); } catch { /* new */ }
s.repos = (s.repos ?? []).filter((r) => r.path !== repo);
const id = basename(repo).toLowerCase().replace(/[^a-z0-9]+/g, '-');
s.repos.push({ id, name: basename(repo), path: repo, url: 'http://localhost:4200' });
s.active = id;
writeFileSync(file, JSON.stringify(s, null, 2));
console.log('  ✔ added repo "' + basename(repo) + '" and made it active');
installInspector(repo).forEach((l) => console.log('  ✔ ' + l));
console.log('\nNext: restart that repo (npm start), then start the playground (npm start in this folder).');
