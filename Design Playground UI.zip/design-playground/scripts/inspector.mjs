// Shared by the server and the CLI: copies the inspector into an Angular repo and hooks main.ts.
import { existsSync, mkdirSync, copyFileSync, readFileSync, writeFileSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));

export function installInspector(repo) {
  const log = [];
  const src = join(repo, 'src');
  mkdirSync(join(src, 'app/dev'), { recursive: true });
  copyFileSync(join(here, '../helper/dp-inspector.ts'), join(src, 'app/dev/dp-inspector.ts'));
  log.push('Copied src/app/dev/dp-inspector.ts');
  const mainPath = join(src, 'main.ts');
  let main = existsSync(mainPath) ? readFileSync(mainPath, 'utf8') : '';
  if (main.includes('dp-inspector')) log.push('src/main.ts already hooked');
  else {
    const re = /(bootstrapApplication\([\s\S]*?\)|bootstrapModule\([\s\S]*?\))\s*\.catch/;
    if (re.test(main)) {
      writeFileSync(mainPath + '.bak', main);
      main = "import { isDevMode } from '@angular/core';\n" + main.replace(re, (_, a) => a + "\n  .then(() => {\n    if (isDevMode()) {\n      import('./app/dev/dp-inspector').then((m) => m.installDesignPlaygroundInspector());\n    }\n  })\n  .catch");
      writeFileSync(mainPath, main);
      log.push('Patched src/main.ts (backup: main.ts.bak)');
    } else log.push("Could not patch src/main.ts. Add: if (isDevMode()) import('./app/dev/dp-inspector').then(m => m.installDesignPlaygroundInspector());");
  }
  return log;
}
