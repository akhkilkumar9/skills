/**
 * index.js — the UX Workbench local server.
 * Serves the UI from /public and a small local API:
 *   GET  /api/overview             — aggregated dashboard data (reads stored results only)
 *   POST /api/analyze              — run a UX Audit (optionally only some categories)
 *   GET  /api/reports/:id          — a saved audit report
 *   GET  /api/patterns             — pattern index
 *   POST /api/patterns/extract     — deep-scan a URL (layout, grid metrics, labels)
 *   POST /api/patterns/save        — save the reviewed pattern as markdown + sidecar
 *   GET  /api/patterns/:id/data    — structured pattern data (for re-editing)
 *   GET  /api/patterns/:id/file    — the raw markdown pattern file
 *   POST /api/patterns/:id/prompt  — compose (and record) the apply prompt
 * Runs 100% locally. No telemetry, no external requests, no AI.
 */

const express = require('express');
const path = require('path');
const { analyze } = require('./analyzer');
const { extractPattern } = require('./pattern-extractor');
const { syncLibrary, getProgress } = require('./library-sync');
const store = require('../src/engine/store');
const overview = require('../src/engine/overview');
const patternFormat = require('../templates/pattern-format');

const app = express();
const PORT = process.env.PORT || 5000;
store.ensureDirs();

app.use(express.json({ limit: '2mb' }));
app.use(express.static(path.join(__dirname, '..', 'public')));
app.use('/patterns', express.static(store.PATTERNS_DIR)); // thumbnails + .md files
app.use('/library', express.static(store.LIBRARY_DIR));   // component screenshots + JSON

app.get('/api/health', (req, res) => res.json({ ok: true }));

/* ---- Overview: read-only aggregation, never runs analysis ---- */
app.get('/api/overview', (req, res) => res.json(overview.buildOverview()));

/* ---- UX Audit ---- */
let busy = false; // one browser job at a time keeps things predictable
app.post('/api/analyze', async (req, res) => {
  const url = (req.body && req.body.url || '').trim();
  const lenses = Array.isArray(req.body && req.body.lenses) ? req.body.lenses : null;
  if (!/^https?:\/\//i.test(url)) {
    return res.status(400).json({ error: 'Please enter a full URL starting with http:// or https:// (e.g. http://localhost:4200/trades).' });
  }
  if (busy) return res.status(409).json({ error: 'Another browser job is already running — give it a moment and try again.' });
  busy = true;
  console.log('[ux-workbench] Auditing ' + url + ' (' + (lenses && lenses.length ? lenses.join(', ') : 'all categories') + ') …');
  try {
    const report = await analyze(url, lenses);
    store.saveReport(report);
    console.log('[ux-workbench] Done in ' + Math.round(report.durationMs / 1000) + 's — ' + report.issues.length + ' issue(s), score ' + report.overall);
    res.json(report);
  } catch (e) {
    console.error('[ux-workbench] Audit failed:', e.message);
    res.status(500).json({ error: friendly(e, url) });
  } finally {
    busy = false;
  }
});

app.get('/api/reports/:id', (req, res) => {
  const report = store.getReport(req.params.id);
  if (!report) return res.status(404).json({ error: 'Report not found.' });
  res.json(report);
});

/* ---- Pattern Generator ---- */
app.get('/api/patterns', (req, res) => res.json(store.listPatterns()));

/** Capture: extract the layout, save the Copilot-readable JSON + thumbnail in one step. */
app.post('/api/patterns', async (req, res) => {
  const url = (req.body && req.body.url || '').trim();
  const name = (req.body && req.body.name || '').trim();
  if (!/^https?:\/\//i.test(url)) return res.status(400).json({ error: 'Please enter a full URL starting with http:// or https://.' });
  if (!name) return res.status(400).json({ error: 'Give the pattern a short name (e.g. "Dense trade blotter").' });
  if (busy) return res.status(409).json({ error: 'Another browser job is already running — give it a moment and try again.' });
  busy = true;
  console.log('[ux-workbench] Capturing pattern "' + name + '" from ' + url + ' …');
  try {
    const extraction = await extractPattern(url);
    const id = patternFormat.kebab(name);
    const json = patternFormat.buildPatternJson(name, extraction, store.getLibraryIndex());
    const entry = store.savePattern({ id, name, url, json, png: extraction.png });
    console.log('[ux-workbench] Pattern saved: patterns/' + id + '.json');
    res.json(Object.assign({}, entry, { json: json, thumb: extraction.png ? 'data:image/png;base64,' + extraction.png.toString('base64') : null }));
  } catch (e) {
    console.error('[ux-workbench] Capture failed:', e.message);
    res.status(500).json({ error: friendly(e, url) });
  } finally {
    busy = false;
  }
});

/* ---- Component Library (Storybook sync) ---- */
app.get('/api/library', (req, res) => {
  const index = store.getLibraryIndex();
  res.json(index || { syncedAt: null, components: [] });
});

app.get('/api/library/sync-status', (req, res) => res.json(getProgress()));

app.post('/api/library/sync', async (req, res) => {
  const url = (req.body && req.body.url || 'http://localhost:6006').trim();
  if (busy) return res.status(409).json({ error: 'Another browser job is already running — give it a moment and try again.' });
  busy = true;
  console.log('[ux-workbench] Syncing Storybook from ' + url + ' …');
  try {
    const summary = await syncLibrary(url);
    console.log('[ux-workbench] Library synced: ' + summary.components + ' components, ' + summary.variants + ' variants, ' + summary.skipped.length + ' skipped');
    res.json(summary);
  } catch (e) {
    if (e.message === 'STORYBOOK_UNREACHABLE') {
      res.status(502).json({ error: 'Could not read the Storybook index at ' + url + '. Is Storybook running? Start it in your component-library repo (usually "npm run storybook"), wait until it opens, then sync again.' });
    } else {
      console.error('[ux-workbench] Sync failed:', e.message);
      res.status(500).json({ error: 'Sync failed: ' + e.message });
    }
  } finally {
    busy = false;
  }
});

app.get('/api/library/:id', (req, res) => {
  const comp = store.getLibraryComponent(req.params.id);
  if (!comp) return res.status(404).json({ error: 'Component not found.' });
  res.json(comp);
});

app.post('/api/library/:id/notes', (req, res) => {
  const comp = store.saveLibraryNotes(req.params.id, req.body || {});
  if (!comp) return res.status(404).json({ error: 'Component not found.' });
  res.json(comp);
});

/** Turn Playwright/network errors into plain-English advice. */
function friendly(e, url) {
  const msg = String(e && e.message || e);
  if (/ERR_CONNECTION_REFUSED|ECONNREFUSED/.test(msg)) {
    return 'Could not reach ' + url + ' — is your Angular app running? Start it (e.g. "ng serve") and try again.';
  }
  if (/Timeout .*exceeded|TimeoutError/i.test(msg)) {
    return 'The page took too long to load. Check the URL opens in your normal browser, then try again.';
  }
  if (/ERR_NAME_NOT_RESOLVED/.test(msg)) {
    return 'That address could not be found. Check the URL for typos.';
  }
  if (/browserType\.launch|Executable doesn't exist/i.test(msg)) {
    return 'Chromium is not installed yet. Run "npx playwright install chromium" in this folder once, then restart.';
  }
  return 'Job failed: ' + msg;
}

const server = app.listen(PORT, () => {
  console.log('');
  console.log('  UX Workbench is running.');
  console.log('  Open  http://localhost:' + PORT + '  in your browser.');
  console.log('');
});
server.on('error', (e) => {
  if (e.code === 'EADDRINUSE') {
    console.error('\nPort ' + PORT + ' is already in use.');
    console.error('Either close the other program, or start UX Workbench on another port:');
    console.error(process.platform === 'win32' ? '  set PORT=5001 && npm start' : '  PORT=5001 npm start');
    process.exit(1);
  }
  throw e;
});
