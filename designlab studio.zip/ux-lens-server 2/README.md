# UX Workbench

> **No admin rights / can't run npm?** Use `ux-workbench-standalone.html` — zero
> installation, two ways to run it:
>
> 1. **Full automatic (recommended):** copy the file into your Angular app's
>    `src/assets/` folder, then open
>    `http://localhost:4200/assets/ux-workbench-standalone.html` while `ng serve`
>    runs. Paste a screen path (e.g. `/trades`) → Run audit. Same URL-in → report-out
>    experience as the Node version, including the automatic 150%-zoom, blank-load,
>    and Esc-dialog checks, with a live view of the screen under the issue overlay.
>    For Storybook, copy the file into its static folder and sync from there.
> 2. **Double-click the file** (no serving at all): each module gives you a small
>    read-only "check script" to paste into DevTools (F12 → Console) on the target
>    screen, and you paste the result back.
>
> No Node, no Playwright, no server. Data stays in the browser's local storage.

A local UX workbench for AI-generated Angular screens, with a left sidebar of
modules: **Overview**, **UX Audit**, and **Pattern Generator**.

- **UX Audit** loads one screen of your running app, runs rule-based UX and
  accessibility checks (you pick which categories), and gives you a visual
  report with a ready-made **fix prompt** per issue to paste into GitHub Copilot.
- **Pattern Generator** captures reference screens as reusable patterns and
  composes template-based generation prompts from them.
- **Overview** is your dashboard: it reads the locally saved results from both
  modules and shows totals, averages, recent activity, and your top recurring
  issues across all audited screens. It never runs analysis itself.

**Everything runs on your machine.** No AI, no accounts, no external calls, no
telemetry. The checks are plain rules in the `rules/` folder; all results are
plain files in `reports/` and `patterns/`.

---

## One-time setup (about 5 minutes)

1. **Install Node.js** (if you don't have it): go to [nodejs.org](https://nodejs.org),
   download the **LTS** version, and run the installer with all defaults.
2. **Open a terminal in this folder** (on Windows: open the folder in Explorer,
   click the address bar, type `cmd`, press Enter. On Mac: right-click the folder
   → Services → New Terminal at Folder).
3. Run these two commands, one after the other (each takes a minute):

   ```
   npm install
   npx playwright install chromium
   ```

That's it. You never need those commands again.

## Every day after that

```
npm start
```

Then open **http://localhost:5000** in your browser. Keep the terminal window open
while you work; press `Ctrl+C` in it to stop UX Workbench.

## The Overview page

The Overview is the landing page. Before you've done anything it shows one
empty-state card per module with a button that takes you there. As you work,
the cards fill in automatically:

- **UX Audit card** — screens audited, average overall score, the five category
  averages as mini rings, and the 5 most recent audits. Click a recent audit to
  reopen its saved report. Partial audits are marked with `*` and "n of 5 categories".
- **Pattern Generator card** — saved patterns with thumbnails, prompts composed,
  and the most recently used pattern.
- **Top recurring issues** — the 5 rule failures that appear on the most screens
  across all saved reports. This is where systemic problems show up.

The Overview only reads stored results (from `reports/` and `patterns/`) — it
never opens a browser or runs checks.

## Running a UX Audit

1. Start your Angular app as usual (e.g. `ng serve`, running at http://localhost:4200).
2. Open the **UX Audit** module, paste the full URL of one screen
   (e.g. `http://localhost:4200/trades`). Recently used URLs are suggested,
   including ones you used in the Pattern Generator.
3. **Pick the categories to run.** All five are selected by default; click a card
   to toggle it (at least one is required). Fewer categories = faster audit.

   | Category | Looks at |
   |---|---|
   | Usability Heuristics | status, control, errors, consistency |
   | Information Architecture | labels, terminology, grouping, defaults |
   | Visual Hierarchy | emphasis, density, alignment, truncation |
   | Interaction Design | keyboard, focus, dialogs, states |
   | Accessibility | contrast, ARIA, zoom, color-blind safety |

4. Click **Run audit (n of 5 categories)**. Only the selected categories' rules
   run — the others are skipped entirely. You'll get:
   - an overall score and a score per category (partial audits are clearly
     labeled "n of 5 categories" everywhere, so a partial score is never
     mistaken for a full one),
   - your screen with red (fail) and amber (improve) rectangles on it,
   - an issue list — click any issue to highlight it on the screenshot,
   - a detail panel with **Copy fix prompt** — paste that into Copilot,
   - **Manual checks** for the selected categories only,
   - **Export report** (in the sidebar) to save a single HTML file for engineers.

Every audit is saved automatically to the `reports/` folder and feeds the Overview.

Not ready to audit yet? Click **View a sample report** on the UX Audit page.

## Using the Pattern Generator

One step: **name the pattern, paste the reference screen's URL, click Capture.**
The screen's layout is measured (regions with their buttons/fields/search boxes,
grid metrics like visible columns, row height, sticky header, sort indicators,
row selection, detail-panel sections) and saved as two files in `patterns/`:

- `<name>.json` — a Copilot-readable layout description (see
  `patterns/example-trade-blotter.json`). It carries its own
  `copilot_instructions`, so you can attach it in Copilot and say
  *"build this screen with a layout like the attached pattern"* — Copilot will
  recreate the same regions, component order, and grid characteristics.
- `<name>.png` — a screenshot used as the visual thumbnail.

Each pattern card in the Library shows the thumbnail, the name, and a
**Download JSON** button. That's all there is to it.

## Using the Component Library

This module mirrors your team's **Storybook** into the Workbench.

1. Start Storybook first, in your component-library repo (usually
   `npm run storybook`), and wait until it opens — by default at
   http://localhost:6006.
2. Open **Component Library** in the Workbench, check the URL, click
   **Sync library**. Progress shows as "X of N stories"; every story is rendered
   in isolation, screenshotted, and measured (colors, font, height, padding,
   radius). Failing stories are skipped and listed in the end summary.
3. Browse the grid, open a component to see its variants side by side with their
   measured values, and fill the **designer notes** (Use when / Do not use for /
   Rules).

**Re-syncing is safe:** it refreshes screenshots and measurements but NEVER
overwrites your designer notes.

A synced library also upgrades the other modules:
- **UX Audit** gains two Visual-Hierarchy checks: *Non-library lookalike* (raw
  HTML controls where a library component exists) and *Off-library styling*
  (a library component styled unlike any approved variant) — each with a
  ready-made fix prompt.
- **Pattern Generator** JSON files mark every detected component
  "in library ✓" or "unknown ⚠" and include your use-when notes as guidance.
- **Overview** shows a library summary card, including how many components
  still need usage notes.

## Screen configs (unlocks 4 extra checks)

Your design team can teach the UX Audit about a specific screen by dropping a
JSON file into the `screen-configs/` folder. The audit picks the config whose
`match` value is the start of the screen's URL path. See
`screen-configs/sample.trades.json`.

What each field means (JSON itself can't contain comments):

| Field | What it does |
|---|---|
| `match` | URL path prefix this config applies to, e.g. `"/trades"` matches `http://localhost:4200/trades/fx`. |
| `forbiddenLabels` | Words that must never appear on screen, each with the preferred term. All visible text is scanned (check K1). |
| `shortcuts` | Keyboard shortcuts the screen should support, e.g. `["F8", "Ctrl+C"]`. Each is pressed safely and the report says whether the app reacted (K2). Enter/Delete are never simulated. |
| `defaultSort` | The column the grid should be sorted by when the screen opens, and the direction (`ascending`/`descending`) (K3). |
| `tabOrder` | Field labels in the order the Tab key should visit them (K4). Matching is forgiving — `"Search"` matches a field labelled "Search trades". |

Leave out any field you don't need. If no config matches a screen, the four
config-driven checks are skipped and the report shows a friendly note instead.

## Login-protected screens

UX Workbench can't type your password, but it can reuse a session you create yourself:

```
npm run login -- http://localhost:4200
```

A real browser window opens. Log in there, come back to the terminal, press Enter.
Your session is saved to `storageState.json` and reused by audits and pattern
captures until it expires. Delete that file to forget the session.

## Safety

- Nothing is ever clicked whose text looks destructive (submit, send, save,
  confirm, release, delete, approve, execute, buy, sell, order, pay…). The full
  list is in `server/safety.js`.
- The only button the audit may click is one that opens a dialog (Filters,
  Settings, Columns…), to test that Esc closes it.
- Enter, Delete, and Backspace are never simulated — even if a screen config asks.
- Read-only by design: pages are loaded, looked at, and closed.

## Troubleshooting

**"Could not reach http://localhost:4200…"**
Your Angular app isn't running (or is on a different port). Start it first and
check the URL opens in your normal browser.

**"Chromium is not installed yet"**
Run `npx playwright install chromium` in this folder once, then `npm start` again.

**"Port 5000 is already in use"**
Something else is using port 5000. Start on another port:
Windows: `set PORT=5001 && npm start` · Mac/Linux: `PORT=5001 npm start`
Then open http://localhost:5001.

**The page needs a login**
See "Login-protected screens" above.

**The audit takes very long or times out**
Very heavy screens can be slow the first time. Try once more; if it keeps failing,
check the terminal window for the detailed error.

**The screenshot looks different from my browser**
A clean 1440×900 Chromium window is used, with no extensions and no saved data
(unless you used `npm run login`). Differences usually mean the screen depends
on local state — worth knowing in itself!

## Folder structure

```
server/          Express server + Playwright audit engine
src/engine/      Overview aggregation + local result storage
rules/           Every check with its description, grouped by file
templates/       Fix-prompt + pattern-prompt templates
public/          The UI (plain HTML/CSS/JS)
screen-configs/  Optional per-screen JSON configs written by your design team
reports/         Saved audit reports (created automatically)
patterns/         Pattern .json layouts + .png thumbnails (created automatically)
library/          Synced Storybook components + screenshots + notes (created automatically)
```
