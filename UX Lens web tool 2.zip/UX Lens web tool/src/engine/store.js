/**
 * src/engine/store.js — local persistence for UX Workbench.
 * Everything lives in plain files next to the app:
 *   reports/index.json  + reports/<id>.json     (saved UX Audit reports)
 *   patterns/index.json                          (pattern metadata)
 *   patterns/<name>.md  + patterns/<name>.png    (pattern file + thumbnail)
 *   patterns/<name>.json                         (structured data for re-editing)
 *   patterns/prompt-history.json                 (composed generation prompts)
 * No database, nothing leaves the machine.
 */

const fs = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, '..', '..');
const REPORTS_DIR = path.join(ROOT, 'reports');
const PATTERNS_DIR = path.join(ROOT, 'patterns');
const LIBRARY_DIR = path.join(ROOT, 'library');

function ensureDirs() {
  [REPORTS_DIR, PATTERNS_DIR, LIBRARY_DIR].forEach((d) => { if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true }); });
}
function readJson(file, fallback) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; }
}
function writeJson(file, data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 1));
}
const safeId = (id) => /^[a-z0-9-]+$/.test(String(id)); // pattern ids are kebab-case

/* ---------------- reports ---------------- */
const REPORTS_INDEX = path.join(REPORTS_DIR, 'index.json');

/** Save a full audit report; keep a lightweight summary in the index. */
function saveReport(report) {
  ensureDirs();
  const id = 'a' + Date.now();
  report.id = id;
  writeJson(path.join(REPORTS_DIR, id + '.json'), report);
  const index = readJson(REPORTS_INDEX, []);
  index.unshift({
    id,
    url: report.url,
    title: report.title || '',
    timestamp: report.timestamp,
    overall: report.overall,
    lensesRun: report.lensesRun || [],
    lenses: (report.lenses || []).map(l => ({ id: l.id, score: l.score })),
    issueCount: (report.issues || []).length,
    failedRules: [...new Set((report.issues || []).map(i => i.ruleId))]
  });
  writeJson(REPORTS_INDEX, index);
  return id;
}

function listReports() { return readJson(REPORTS_INDEX, []); }

function getReport(id) {
  if (!/^a\d+$/.test(String(id))) return null;
  return readJson(path.join(REPORTS_DIR, id + '.json'), null);
}

/* ---------------- patterns ---------------- */
const PATTERNS_INDEX = path.join(PATTERNS_DIR, 'index.json');

function listPatterns() { return readJson(PATTERNS_INDEX, []); }
function getPattern(id) { return listPatterns().find(p => p.id === id) || null; }

/** Save/overwrite a pattern: JSON layout file + screenshot thumbnail + index entry. */
function savePattern({ id, name, url, json, png }) {
  ensureDirs();
  if (!safeId(id)) throw new Error('Invalid pattern id');
  fs.writeFileSync(path.join(PATTERNS_DIR, id + '.json'), json);
  if (png) fs.writeFileSync(path.join(PATTERNS_DIR, id + '.png'), png);
  const index = readJson(PATTERNS_INDEX, []);
  const existing = index.find(p => p.id === id);
  const entry = {
    id, name, url,
    timestamp: existing ? existing.timestamp : new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    format: 'json'
  };
  const next = index.filter(p => p.id !== id);
  next.unshift(entry);
  writeJson(PATTERNS_INDEX, next);
  return entry;
}

/* ---------------- component library (synced from Storybook) ---------------- */
const LIBRARY_INDEX = path.join(LIBRARY_DIR, '_index.json');

function getLibraryIndex() { return readJson(LIBRARY_INDEX, null); }
function writeLibraryIndex(index) { ensureDirs(); writeJson(LIBRARY_INDEX, index); }

function getLibraryComponent(id) {
  if (!safeId(id)) return null;
  return readJson(path.join(LIBRARY_DIR, id + '.json'), null);
}

function saveLibraryComponent(id, data) {
  ensureDirs();
  if (!safeId(id)) throw new Error('Invalid component id');
  writeJson(path.join(LIBRARY_DIR, id + '.json'), data);
}

/** Update designerNotes for a component (and its index summary). */
function saveLibraryNotes(id, notes) {
  const comp = getLibraryComponent(id);
  if (!comp) return null;
  comp.designerNotes = {
    useWhen: String(notes.useWhen || ''),
    doNotUseFor: String(notes.doNotUseFor || ''),
    rules: String(notes.rules || '')
  };
  saveLibraryComponent(id, comp);
  const index = getLibraryIndex();
  if (index) {
    const entry = index.components.find(c => c.id === id);
    if (entry) {
      entry.hasNotes = !!(comp.designerNotes.useWhen || comp.designerNotes.doNotUseFor || comp.designerNotes.rules);
      entry.useWhen = comp.designerNotes.useWhen;
      writeLibraryIndex(index);
    }
  }
  return comp;
}

module.exports = {
  ensureDirs, PATTERNS_DIR, LIBRARY_DIR,
  saveReport, listReports, getReport,
  savePattern, listPatterns, getPattern,
  getLibraryIndex, writeLibraryIndex, getLibraryComponent, saveLibraryComponent, saveLibraryNotes
};
