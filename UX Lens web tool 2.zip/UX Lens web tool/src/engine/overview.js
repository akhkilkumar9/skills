/**
 * src/engine/overview.js — the Overview dashboard aggregator.
 *
 * The Overview NEVER runs analysis. It only reads locally stored results
 * (saved audit reports, captured patterns, prompt history) and turns them
 * into summary cards.
 *
 * Future modules: call registerCard(id, buildFn) and the Overview endpoint
 * will include your card automatically. buildFn returns
 *   { empty: boolean, data: {...} }   (data shape is card-specific)
 */

const store = require('./store');
const rules = require('../../rules');

const cards = [];
function registerCard(id, build) { cards.push({ id, build }); }

/* ---- card 1: UX Audit summary ---- */
registerCard('audit', () => {
  const reports = store.listReports();
  if (!reports.length) return { empty: true };
  const avg = (nums) => Math.round(nums.reduce((s, n) => s + n, 0) / nums.length);
  // per-lens averages, only over reports where that lens actually ran
  const lensAverages = rules.LENSES.map((l) => {
    const scores = reports
      .map(r => (r.lenses || []).find(x => x.id === l.id))
      .filter(x => x && x.score !== null && x.score !== undefined)
      .map(x => x.score);
    return { id: l.id, name: l.name, avg: scores.length ? avg(scores) : null, samples: scores.length };
  });
  return {
    empty: false,
    data: {
      total: reports.length,
      avgOverall: avg(reports.map(r => r.overall)),
      lensAverages,
      recent: reports.slice(0, 5).map(r => ({
        id: r.id, url: r.url, timestamp: r.timestamp, overall: r.overall,
        lensesRun: r.lensesRun || [], partial: (r.lensesRun || []).length > 0 && (r.lensesRun || []).length < rules.LENSES.length
      }))
    }
  };
});

/* ---- card 2: Pattern Generator summary ---- */
registerCard('patterns', () => {
  const patterns = store.listPatterns();
  if (!patterns.length) return { empty: true };
  return {
    empty: false,
    data: {
      count: patterns.length,
      recent: patterns.slice(0, 6).map(p => ({ id: p.id, name: p.name, url: p.url, timestamp: p.timestamp, thumb: '/patterns/' + p.id + '.png' }))
    }
  };
});

/* ---- card 3: Component Library summary ---- */
registerCard('library', () => {
  const index = store.getLibraryIndex();
  if (!index || !index.components || !index.components.length) return { empty: true };
  return {
    empty: false,
    data: {
      count: index.components.length,
      variants: index.components.reduce((s, c) => s + (c.variantCount || 0), 0),
      syncedAt: index.syncedAt,
      needNotes: index.components.filter(c => !c.hasNotes).length
    }
  };
});

/* ---- card 4: top recurring issues across all saved audits ---- */
registerCard('topIssues', () => {
  const reports = store.listReports();
  if (!reports.length) return { empty: true };
  const screensByRule = {}; // ruleId -> number of screens it appeared on
  reports.forEach(r => (r.failedRules || []).forEach((id) => { screensByRule[id] = (screensByRule[id] || 0) + 1; }));
  const items = Object.entries(screensByRule)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)
    .map(([ruleId, screens]) => {
      const rule = rules.byId[ruleId];
      return {
        ruleId, screens,
        title: rule ? rule.title : ruleId,
        lens: rule ? rule.lens : null,
        severity: rule ? rule.severity : 'improve'
      };
    });
  return { empty: items.length ? false : true, data: { items, screensTotal: reports.length } };
});

/* ---- endpoint payload ---- */
function buildOverview() {
  const out = { generatedAt: new Date().toISOString(), cards: {} };
  for (const c of cards) {
    try { out.cards[c.id] = c.build(); }
    catch (e) { out.cards[c.id] = { empty: true, error: e.message }; }
  }
  return out;
}

module.exports = { buildOverview, registerCard };
