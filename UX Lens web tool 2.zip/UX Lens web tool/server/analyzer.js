/**
 * analyzer.js — the UX Audit engine of UX Workbench.
 *
 * Opens the target URL in headless Chromium (Playwright), runs axe-core plus all
 * rule modules, performs the SAFE-MODE keyboard/dialog checks, takes an annotated
 * full-page screenshot, and returns one big report object for the UI.
 *
 * Everything here is plain rule-based code. No AI, no network calls except to
 * the page you asked it to analyze.
 */

const fs = require('fs');
const path = require('path');
const { chromium } = require('playwright');
const rules = require('../rules');
const prompts = require('../templates/fix-prompts');
const safety = require('./safety');
const { installHelpers } = require('./inpage-helpers');
const dataStore = require('../src/engine/store');

const AXE_SOURCE = fs.readFileSync(require.resolve('axe-core/axe.min.js'), 'utf8');
const CONFIG_DIR = path.join(__dirname, '..', 'screen-configs');
const STORAGE_STATE = path.join(__dirname, '..', 'storageState.json'); // saved by `npm run login`
const VIEWPORT = { width: 1440, height: 900 };
const PENALTY = { fail: 12, improve: 5 }; // score deduction per issue

/* ------------------------------------------------------------------ */
/* Screen-config loading: match by URL pathname prefix                 */
/* ------------------------------------------------------------------ */
function loadConfig(url) {
  let pathname;
  try { pathname = new URL(url).pathname; } catch { return null; }
  if (!fs.existsSync(CONFIG_DIR)) return null;
  for (const file of fs.readdirSync(CONFIG_DIR)) {
    if (!file.endsWith('.json')) continue;
    try {
      const cfg = JSON.parse(fs.readFileSync(path.join(CONFIG_DIR, file), 'utf8'));
      if (cfg.match && pathname.startsWith(cfg.match)) return { ...cfg, _file: file };
    } catch (e) {
      console.warn('[ux-workbench] Skipping invalid config ' + file + ': ' + e.message);
    }
  }
  return null;
}

/* ------------------------------------------------------------------ */
/* Issue assembly + scoring                                            */
/* ------------------------------------------------------------------ */
let issueCounter = 0;
function makeIssue(rule, finding) {
  const data = { ...(finding.data || {}), selector: finding.selector || '(page)' };
  return {
    id: rule.id + '-' + (++issueCounter),
    ruleId: rule.id,
    category: rule.category,
    lens: rule.lens,
    severity: rule.severity,
    title: rule.title,
    why: rule.why,
    message: finding.message || rule.title,
    selector: finding.selector || '',
    rect: finding.rect || null, // null = page-level issue, no rectangle
    fixPrompt: prompts.fill(rule.id, data)
  };
}

function scoreReport(issues, activeLenses) {
  const lenses = rules.LENSES.map((l) => {
    const ran = activeLenses.has(l.id);
    const list = issues.filter(i => i.lens === l.id);
    const fail = list.filter(i => i.severity === 'fail').length;
    const improve = list.length - fail;
    const score = ran ? Math.max(0, 100 - fail * PENALTY.fail - improve * PENALTY.improve) : null;
    return { id: l.id, name: l.name, tagline: l.tagline, ran, score, counts: { fail, improve } };
  });
  const scored = lenses.filter(l => l.score !== null);
  const overall = Math.round(scored.reduce((s, l) => s + l.score, 0) / (scored.length || 1));
  return { lenses, overall };
}

/* ------------------------------------------------------------------ */
/* Tab-walk: press Tab repeatedly, recording each focused element      */
/* ------------------------------------------------------------------ */
async function tabWalk(page, maxSteps) {
  await page.evaluate(() => { if (document.activeElement) document.activeElement.blur(); });
  const seq = [];
  const seen = new Set();
  for (let i = 0; i < maxSteps; i++) {
    await page.keyboard.press('Tab');
    const info = await page.evaluate(() => {
      const U = window.__uxlens;
      const el = document.activeElement;
      if (!el || el === document.body || el === document.documentElement) return null;
      const s = getComputedStyle(el);
      // Best available human label for this element
      let label = el.getAttribute('aria-label') || '';
      if (!label && el.id) { const l = document.querySelector('label[for="' + CSS.escape(el.id) + '"]'); if (l) label = U.text(l); }
      if (!label) label = U.text(el).slice(0, 60) || el.getAttribute('placeholder') || el.name || el.tagName.toLowerCase();
      return {
        selector: U.cssPath(el),
        rect: U.docRect(el),
        label,
        focused: { outlineStyle: s.outlineStyle, outlineWidth: s.outlineWidth, boxShadow: s.boxShadow, borderColor: s.borderColor, backgroundColor: s.backgroundColor }
      };
    }).catch(() => null);
    if (!info) break;               // focus left the document / wrapped to browser UI
    if (seen.has(info.selector)) break; // wrapped around — stop
    seen.add(info.selector);
    seq.push(info);
  }
  return seq;
}

/* ------------------------------------------------------------------ */
/* Main entry                                                          */
/* ------------------------------------------------------------------ */
async function analyze(url, lensIds) {
  issueCounter = 0;
  // Which of the five lenses to run this time (default: all five)
  const validIds = rules.LENSES.map(l => l.id);
  const picked = Array.isArray(lensIds) ? lensIds.filter(id => validIds.includes(id)) : [];
  const active = new Set(picked.length ? picked : validIds);
  const on = (ruleId) => active.has(rules.byId[ruleId].lens);
  const started = Date.now();
  const config = loadConfig(url);
  const issues = [];
  const manualExtras = []; // unverifiable findings, shown under Manual checks
  const shortcuts = [];    // K2 results

  const browser = await chromium.launch({ headless: true });
  try {
    const context = await browser.newContext({
      viewport: VIEWPORT,
      // Reuse a saved login session if `npm run login` was used
      storageState: fs.existsSync(STORAGE_STATE) ? STORAGE_STATE : undefined
    });
    const page = await context.newPage();

    /* ---- S1: blank page during load ------------------------------ */
    let pending = 0;
    page.on('request', () => pending++);
    page.on('requestfinished', () => pending--);
    page.on('requestfailed', () => pending--);

    await page.goto(url, { waitUntil: 'commit', timeout: 25000 });
    await page.waitForTimeout(200); // spec: sample the page 200ms in
    const early = await page.evaluate(() => {
      const b = document.body;
      if (!b) return { text: 0, blocks: 0 };
      let blocks = 0;
      b.querySelectorAll('*').forEach((e) => { const r = e.getBoundingClientRect(); if (r.width > 60 && r.height > 40) blocks++; });
      return { text: (b.innerText || '').trim().length, blocks };
    }).catch(() => null);
    const blankAt200 = early && early.text < 10 && early.blocks < 3 && pending > 0;

    // Now let the app finish loading
    await page.waitForLoadState('load', { timeout: 25000 }).catch(() => {});
    await page.waitForLoadState('networkidle', { timeout: 8000 }).catch(() => {});
    await page.waitForTimeout(600); // let Angular render/settle

    await page.evaluate(installHelpers);

    if (blankAt200 && on('S1')) {
      issues.push(makeIssue(rules.byId.S1, {
        message: 'Body was essentially empty 200ms after navigation while requests were still loading — no loading state shown.'
      }));
    }

    const title = await page.title().catch(() => '');

    /* ---- axe-core: A1 (contrast) + label rules feeding A2 -------- */
    if (on('A1')) try {
      await page.addScriptTag({ content: AXE_SOURCE });
      const axeResults = await page.evaluate(async () =>
        await axe.run(document, { runOnly: { type: 'rule', values: ['color-contrast', 'label'] }, resultTypes: ['violations'] }));
      for (const v of axeResults.violations) {
        const rule = v.id === 'color-contrast' ? rules.byId.A1 : rules.byId.A2;
        for (const node of v.nodes.slice(0, 15)) {
          const selector = node.target.join(' ');
          const rect = await page.evaluate((sel) => {
            const el = document.querySelector(sel);
            return el ? window.__uxlens.docRect(el) : null;
          }, selector).catch(() => null);
          const d = (node.any && node.any[0] && node.any[0].data) || {};
          issues.push(makeIssue(rule, {
            selector, rect,
            message: v.id === 'color-contrast'
              ? 'Contrast ' + (d.contrastRatio || '?') + ':1 (' + (d.fgColor || '?') + ' on ' + (d.bgColor || '?') + ')'
              : node.failureSummary ? node.failureSummary.split('\n')[1] || 'Missing label' : 'Missing label',
            data: { ratio: d.contrastRatio || '?', fg: d.fgColor || '?', bg: d.bgColor || '?', placeholderNote: '' }
          }));
        }
      }
    } catch (e) {
      console.warn('[ux-workbench] axe-core failed: ' + e.message);
    }

    /* ---- All in-page rules ---------------------------------------- */
    const a2Seen = new Set(issues.filter(i => i.ruleId === 'A2').map(i => i.selector));
    for (const rule of rules.inPage) {
      if (rule.needsConfig && !config) continue;
      if (!active.has(rule.lens)) continue; // lens not selected for this run
      const found = await page.evaluate(rule.detect, config || null).catch((e) => {
        console.warn('[ux-workbench] rule ' + rule.id + ' failed: ' + e.message);
        return [];
      });
      for (const f of found) {
        if (f.data && f.data.unverifiable) { manualExtras.push({ id: rule.id + '-manual', lens: rule.lens, text: f.message }); continue; }
        if (rule.id === 'A2' && a2Seen.has(f.selector)) continue; // already flagged by axe
        issues.push(makeIssue(rule, f));
      }
    }

    /* ---- Component-library consistency rules (V1/V2) --------------- */
    const libIndex = dataStore.getLibraryIndex();
    const libraryAvailable = !!(libIndex && libIndex.components && libIndex.components.length);
    if (libraryAvailable && (on('V1') || on('V2'))) {
      const kindOf = (name) => /button/i.test(name) ? 'button' : /input|field|select|search|text/i.test(name) ? 'input' : /grid|table/i.test(name) ? 'grid' : null;
      const withTag = libIndex.components.filter(c => c.tag);
      const libArg = {
        tags: withTag.map(c => c.tag),
        buttons: withTag.filter(c => kindOf(c.component) === 'button').map(c => c.tag),
        inputs: withTag.filter(c => kindOf(c.component) === 'input').map(c => c.tag),
        grids: withTag.filter(c => kindOf(c.component) === 'grid').map(c => c.tag),
        byTag: Object.fromEntries(withTag.map(c => [c.tag, { component: c.component, variants: c.variants || [] }]))
      };
      for (const rule of rules.all.filter(r => r.engine === 'library')) {
        if (!on(rule.id)) continue;
        const found = await page.evaluate(rule.detect, libArg).catch((e) => {
          console.warn('[ux-workbench] rule ' + rule.id + ' failed: ' + e.message);
          return [];
        });
        found.forEach(f => issues.push(makeIssue(rule, f)));
      }
    }

    /* ---- Tab-walk: A4 (focus visibility) + K4 (tab order) --------- */
    const needWalk = on('A4') || (on('K4') && config && Array.isArray(config.tabOrder) && config.tabOrder.length);
    const seq = needWalk ? await tabWalk(page, 60) : [];

    if (seq.length && on('A4')) {
      // Compare each element's focused styles against its blurred styles
      await page.evaluate(() => { if (document.activeElement) document.activeElement.blur(); });
      const blurred = await page.evaluate((sels) => sels.map((sel) => {
        const el = document.querySelector(sel);
        if (!el) return null;
        const s = getComputedStyle(el);
        return { outlineStyle: s.outlineStyle, outlineWidth: s.outlineWidth, boxShadow: s.boxShadow, borderColor: s.borderColor, backgroundColor: s.backgroundColor };
      }), seq.map(s => s.selector)).catch(() => []);
      let a4Count = 0;
      seq.forEach((entry, i) => {
        const b = blurred[i];
        if (!b || a4Count >= 10) return;
        const f = entry.focused;
        const hasOutline = f.outlineStyle !== 'none' && parseFloat(f.outlineWidth) > 0;
        const changed = hasOutline || f.boxShadow !== b.boxShadow || f.borderColor !== b.borderColor || f.backgroundColor !== b.backgroundColor;
        if (changed) return;
        a4Count++;
        issues.push(makeIssue(rules.byId.A4, {
          selector: entry.selector, rect: entry.rect,
          message: 'No visible focus style on "' + entry.label + '"',
          data: { elementText: entry.label }
        }));
      });
    }

    if (on('K4') && config && Array.isArray(config.tabOrder) && config.tabOrder.length) {
      if (!seq.length) {
        manualExtras.push({ id: 'K4-manual', lens: 'interaction', text: 'K4: could not walk the tab order automatically — verify the tab order matches the spec manually.' });
      } else {
        // Expected labels must appear as a subsequence of the observed labels
        const labels = seq.map(s => s.label.toLowerCase());
        let from = 0, mismatch = null, step = 0;
        for (const want of config.tabOrder) {
          step++;
          const idx = labels.findIndex((l, i) => i >= from && l.includes(String(want).toLowerCase()));
          if (idx === -1) { mismatch = want; break; }
          from = idx + 1;
        }
        if (mismatch) {
          issues.push(makeIssue(rules.byId.K4, {
            selector: seq[0].selector, rect: seq[0].rect,
            message: 'Expected "' + mismatch + '" at step ' + step + ' of the tab order, but it was not reached in order.',
            data: {
              expected: config.tabOrder.join(' → '),
              found: seq.slice(0, 12).map(s => s.label).join(' → '),
              step
            }
          }));
        }
      }
    }

    /* ---- Full-page screenshot (BEFORE any dialog interaction) ----- */
    await page.evaluate(() => { if (document.activeElement) document.activeElement.blur(); window.scrollTo(0, 0); });
    const tallPage = await page.evaluate(() => document.documentElement.scrollHeight > 6000);
    const shot = await page.screenshot({ fullPage: !tallPage }).catch(() => null);
    let screenshot = null;
    if (shot) {
      screenshot = {
        dataUrl: 'data:image/png;base64,' + shot.toString('base64'),
        width: shot.readUInt32BE(16),  // PNG IHDR width
        height: shot.readUInt32BE(20)  // PNG IHDR height
      };
    }

    /* ---- I1 / I2: SAFE-MODE dialog checks ------------------------- */
    if (on('I1')) {
    const findDialog = () => page.evaluate(() => {
      const U = window.__uxlens;
      const c = [...document.querySelectorAll('[role="dialog"], [role="alertdialog"], dialog[open], mat-dialog-container, .cdk-dialog-container, .modal.show, .modal.in, .p-dialog')]
        .filter(U.isVisible);
      return c.length ? U.cssPath(c[0]) : null;
    }).catch(() => null);

    let dialogSel = await findDialog();
    let openedByUs = false;
    let dialogRect = null;
    if (dialogSel) {
      dialogRect = await page.evaluate((s) => { const el = document.querySelector(s); return el ? window.__uxlens.docRect(el) : null; }, dialogSel).catch(() => null);
    } else {
      // Try to open one via a SAFE opener button (never anything destructive)
      const opener = await page.evaluate(([safe, destructive]) => {
        const U = window.__uxlens;
        const SAFE = new RegExp(safe, 'i'), BAD = new RegExp(destructive, 'i');
        const btn = [...document.querySelectorAll('button, [role="button"]')].filter(U.isVisible).find((b) => {
          const t = U.text(b) + ' ' + (b.getAttribute('aria-label') || '');
          return SAFE.test(t) && !BAD.test(t);
        });
        return btn ? U.cssPath(btn) : null;
      }, [safety.SAFE_OPENERS_SRC, safety.DESTRUCTIVE_SRC]).catch(() => null);
      if (opener) {
        await page.click(opener, { timeout: 3000 }).catch(() => {});
        await page.waitForTimeout(900);
        dialogSel = await findDialog();
        openedByUs = !!dialogSel;
      }
    }

    if (dialogSel) {
      // I2: does focus stay inside while tabbing?
      let escaped = false;
      for (let i = 0; i < 12 && !escaped; i++) {
        await page.keyboard.press('Tab');
        escaped = await page.evaluate((sel) => {
          const dlg = document.querySelector(sel);
          const a = document.activeElement;
          return !!(dlg && a && a !== document.body && !dlg.contains(a));
        }, dialogSel).catch(() => false);
      }
      if (escaped) {
        issues.push(makeIssue(rules.byId.I2, {
          selector: dialogSel, rect: openedByUs ? null : dialogRect,
          message: 'Focus left the dialog while tabbing' + (openedByUs ? ' (dialog opened via a safe button; not in screenshot)' : '')
        }));
      }
      // I1: does Escape close it?
      await page.keyboard.press('Escape');
      await page.waitForTimeout(700);
      const still = await findDialog();
      if (still) {
        issues.push(makeIssue(rules.byId.I1, {
          selector: dialogSel, rect: openedByUs ? null : dialogRect,
          message: 'Dialog stayed open after pressing Escape' + (openedByUs ? ' (dialog opened via a safe button; not in screenshot)' : '')
        }));
        // Best-effort cleanup: click an explicit close affordance (safe by nature)
        await page.evaluate((sel) => {
          const dlg = document.querySelector(sel);
          if (!dlg) return;
          const close = dlg.querySelector('[aria-label*=close i], .close, .btn-close, [class*=close]');
          if (close) close.click();
        }, still).catch(() => {});
        await page.waitForTimeout(400);
      }
    }
    } // end I1/I2

    /* ---- K2: expected keyboard shortcuts (SAFE MODE) --------------- */
    if (on('K2') && config && Array.isArray(config.shortcuts)) {
      for (const sc of config.shortcuts) {
        if (safety.FORBIDDEN_KEYS.test(sc)) {
          shortcuts.push({ shortcut: sc, status: 'skipped' });
          manualExtras.push({ id: 'K2-' + sc, lens: 'usability', text: 'K2: shortcut "' + sc + '" was not simulated (unsafe key) — verify it manually.' });
          continue;
        }
        // Watch for any reaction: a prevented default or a DOM mutation
        await page.evaluate(() => {
          window.__uxlensKey = { prevented: false, mutations: 0 };
          if (!window.__uxlensKeyHooked) {
            window.__uxlensKeyHooked = true;
            window.addEventListener('keydown', (e) => {
              setTimeout(() => { if (e.defaultPrevented) window.__uxlensKey.prevented = true; }, 0);
            }, true);
            new MutationObserver((m) => { if (window.__uxlensKey) window.__uxlensKey.mutations += m.length; })
              .observe(document.body, { subtree: true, childList: true, attributes: true, characterData: true });
          }
        }).catch(() => {});
        const key = sc.trim().replace(/\bctrl\b/i, 'Control').replace(/\bcmd\b/i, 'Meta').replace(/\s*\+\s*/g, '+');
        try { await page.keyboard.press(key); } catch { shortcuts.push({ shortcut: sc, status: 'invalid' }); continue; }
        await page.waitForTimeout(450);
        const res = await page.evaluate(() => window.__uxlensKey).catch(() => null);
        const reacted = !!(res && (res.prevented || res.mutations > 0));
        shortcuts.push({ shortcut: sc, status: reacted ? 'reacted' : 'no-reaction' });
        if (!reacted) {
          issues.push(makeIssue(rules.byId.K2, {
            message: 'Shortcut ' + sc + ': no handler reaction detected (no preventDefault, no DOM change)',
            data: { shortcut: sc }
          }));
          manualExtras.push({ id: 'K2-' + sc, lens: 'usability', text: 'K2: "' + sc + '" showed no detectable reaction — it may still work invisibly; verify manually.' });
        }
        await page.keyboard.press('Escape').catch(() => {}); // close anything a shortcut opened
        await page.waitForTimeout(150);
      }
    }

    /* ---- A7: 150% zoom check (fresh page, narrower viewport) ------- */
    if (on('A7')) try {
      const zp = await context.newPage();
      // 1440px viewport at 150% zoom ≈ 960 CSS px of layout width
      await zp.setViewportSize({ width: Math.round(VIEWPORT.width / 1.5), height: Math.round(VIEWPORT.height / 1.5) });
      await zp.goto(url, { waitUntil: 'load', timeout: 25000 });
      await zp.waitForTimeout(1500);
      const ov = await zp.evaluate(() => ({
        sw: document.documentElement.scrollWidth,
        cw: document.documentElement.clientWidth
      }));
      if (ov.sw > ov.cw + 8) {
        issues.push(makeIssue(rules.byId.A7, {
          message: 'Horizontal overflow at 150% zoom: ' + ov.sw + 'px content in a ' + ov.cw + 'px viewport',
          data: { scrollWidth: ov.sw, clientWidth: ov.cw }
        }));
      }
      await zp.close();
    } catch (e) {
      console.warn('[ux-workbench] zoom check failed: ' + e.message);
    }

    /* ---- Assemble the report --------------------------------------- */
    const { lenses, overall } = scoreReport(issues, active);
    return {
      url, title,
      timestamp: new Date().toISOString(),
      durationMs: Date.now() - started,
      viewport: VIEWPORT,
      screenshot,
      overall, lenses, issues,
      lensesRun: [...active],
      manualChecks: [
        // only the manual checks for the categories that were run
        ...rules.manualChecks.filter(m => !m.lens || active.has(m.lens)),
        ...manualExtras.map(m => ({ id: m.id, lens: m.lens, text: m.text, hint: 'Raised by an automated check that could not verify this.' }))
      ],
      shortcuts,
      library: { available: libraryAvailable, syncedAt: libraryAvailable ? libIndex.syncedAt : null },
      config: { found: !!config, file: config ? config._file : null }
    };
  } finally {
    await browser.close().catch(() => {});
  }
}

module.exports = { analyze };
