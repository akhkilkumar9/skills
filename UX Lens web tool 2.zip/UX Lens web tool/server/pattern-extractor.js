/**
 * server/pattern-extractor.js — deep, rule-based pattern extraction.
 *
 * Opens the URL in headless Chromium and MEASURES the page (no AI, no guessing):
 *   - layout regions (top/left/center/right/bottom) with their real contents
 *   - grid metrics: visible columns, row height, sticky header (by scrolling),
 *     sort indicators, selection mode (SAFE MODE: one click on the first data row)
 *   - button/action labels per region → pre-filled placeholder examples
 *   - detail panel: does a row click populate a side region, and with what headings
 */

const fs = require('fs');
const path = require('path');
const { chromium } = require('playwright');
const { installHelpers } = require('./inpage-helpers');
const safety = require('./safety');

const STORAGE_STATE = path.join(__dirname, '..', 'storageState.json');

/** Runs in the page: geometric zone scan + static grid metrics. */
function pageScan(destructiveSrc) {
  const U = window.__uxlens;
  const BAD = new RegExp(destructiveSrc, 'i');
  const W = innerWidth, H = innerHeight;
  const zoneOf = (r) => {
    const cx = r.x + r.width / 2, cy = r.y + r.height / 2;
    if (cy < H * 0.18) return 'top';
    if (cy > H * 0.88) return 'bottom';
    if (cx < W * 0.22) return 'left';
    if (cx > W * 0.78) return 'right';
    return 'center';
  };
  const mk = () => ({ buttons: [], fields: [], searches: 0, hasGrid: false });
  const zones = { top: mk(), left: mk(), center: mk(), right: mk(), bottom: mk() };

  // buttons / actions per zone
  const seenBtn = new Set();
  document.querySelectorAll('button, [role="button"], input[type="button"], input[type="submit"], a[class*="btn"], a[class*="button"]').forEach((b) => {
    if (!U.isVisible(b)) return;
    const label = (U.text(b) || b.value || b.getAttribute('aria-label') || '').trim().slice(0, 40);
    if (!label) return;
    const z = zoneOf(b.getBoundingClientRect());
    if (zones[z].buttons.length >= 12 || seenBtn.has(z + '|' + label)) return;
    seenBtn.add(z + '|' + label);
    zones[z].buttons.push(label);
  });

  // form fields per zone
  document.querySelectorAll('input:not([type=hidden]):not([type=button]):not([type=submit]):not([type=checkbox]):not([type=radio]), select, textarea').forEach((f) => {
    if (!U.isVisible(f)) return;
    const z = zoneOf(f.getBoundingClientRect());
    const ph = f.getAttribute('placeholder') || '';
    const isSearch = f.type === 'search' || /search|filter|find/i.test(ph + ' ' + (f.getAttribute('aria-label') || ''));
    if (isSearch) { zones[z].searches++; return; }
    let label = '';
    if (f.id) { const l = document.querySelector('label[for="' + CSS.escape(f.id) + '"]'); if (l) label = U.text(l); }
    if (!label) { const l = f.closest('label'); if (l) label = U.text(l).slice(0, 30); }
    if (!label) label = ph.slice(0, 30);
    if (label && zones[z].fields.length < 10) zones[z].fields.push(label);
  });

  // main grid
  let grid = null;
  const gs = U.grids().filter(g => g.rows.length > 0 || g.headers.length > 0);
  if (gs.length) {
    const main = gs.map(g => { const r = g.el.getBoundingClientRect(); return { g, area: r.width * r.height }; })
      .sort((a, b) => b.area - a.area)[0].g;
    const gr = main.el.getBoundingClientRect();
    zones[zoneOf(gr)].hasGrid = true;
    const visHeaders = main.headers.filter(h => { const r = h.getBoundingClientRect(); return r.left < W && r.right > 0 && U.isVisible(h); });
    const rows = main.rows.slice(0, 10).map(r => r.getBoundingClientRect().height).filter(h => h > 0);
    const rowHeight = rows.length ? Math.round(rows.reduce((s, h) => s + h, 0) / rows.length) : 0;
    const sortIndicators = main.headers.some(h =>
      ['ascending', 'descending'].includes(h.getAttribute('aria-sort')) ||
      /(sorted|sort-asc|sort-desc)/.test(h.className + '') || h.querySelector('[class*="sort"]'));
    // row actions: buttons inside the first 3 rows
    const rowActions = [];
    main.rows.slice(0, 3).forEach((row) => {
      row.querySelectorAll('button, [role="button"], a[class*="btn"]').forEach((b) => {
        const label = (U.text(b) || b.getAttribute('aria-label') || b.getAttribute('title') || '').trim().slice(0, 30);
        if (label && !rowActions.includes(label) && rowActions.length < 10) rowActions.push(label);
      });
    });
    const checkboxRows = !!main.rows.slice(0, 3).some(r => r.querySelector('input[type=checkbox]'));
    // scroll container of the rows (for the sticky test)
    let scroller = main.rows.length ? main.rows[0].parentElement : null;
    while (scroller && scroller !== document.body) {
      const s = getComputedStyle(scroller);
      if (/(auto|scroll)/.test(s.overflowY) && scroller.scrollHeight > scroller.clientHeight + 10) break;
      scroller = scroller.parentElement;
    }
    // safest cell in the first row to click: plain text, no controls, not destructive
    let firstCellSel = '';
    if (main.rows.length) {
      const cells = main.cellsOf(main.rows[0]);
      const cell = cells.find(c => U.text(c) && !c.querySelector('button, a, input') && !BAD.test(U.text(c)));
      if (cell) firstCellSel = U.cssPath(cell);
    }
    grid = {
      columnsVisible: visHeaders.length || (main.rows.length ? main.cellsOf(main.rows[0]).length : 0),
      columnNames: main.headers.map(h => U.text(h)).filter(Boolean).slice(0, 20),
      rowCount: main.rows.length,
      rowHeight,
      sortIndicators,
      checkboxRows,
      rowActions,
      headerSel: main.headers.length ? U.cssPath(main.headers[0]) : '',
      firstRowSel: main.rows.length ? U.cssPath(main.rows[0]) : '',
      firstCellSel,
      scrollerSel: scroller && scroller !== document.body ? U.cssPath(scroller) : ''
    };
  }

  // component inventory: custom elements (Angular components) by tag
  const counts = {};
  document.querySelectorAll('*').forEach((n) => {
    const t = n.tagName.toLowerCase();
    if (t.includes('-') && !t.startsWith('x-')) counts[t] = (counts[t] || 0) + 1;
  });
  const components = Object.entries(counts).sort((a, b) => b[1] - a[1]).slice(0, 10)
    .map(([tag, count]) => ({ tag, count }));

  // snapshot of the right zone's text (detail-panel detection baseline)
  const rightText = [...document.querySelectorAll('*')]
    .filter(e => U.isVisible(e) && e.children.length === 0 && zoneOf(e.getBoundingClientRect()) === 'right')
    .map(e => U.text(e)).join('|').slice(0, 4000);

  return { zones, grid, components, rightText, title: document.title };
}

/** Runs in the page after the safe row click: selection state + detail headings. */
function afterClickScan(args) {
  const U = window.__uxlens;
  const W = innerWidth, H = innerHeight;
  const zoneOf = (r) => {
    const cx = r.x + r.width / 2, cy = r.y + r.height / 2;
    if (cy < H * 0.18) return 'top';
    if (cy > H * 0.88) return 'bottom';
    if (cx < W * 0.22) return 'left';
    if (cx > W * 0.78) return 'right';
    return 'center';
  };
  const row = args.firstRowSel ? document.querySelector(args.firstRowSel) : null;
  const selected = !!(row && (row.getAttribute('aria-selected') === 'true' ||
    /(^|\s)(selected|active|highlight|row-selected|ag-row-selected)/.test(row.className + '')));
  const rightEls = [...document.querySelectorAll('*')]
    .filter(e => U.isVisible(e) && zoneOf(e.getBoundingClientRect()) === 'right');
  const rightText = rightEls.filter(e => e.children.length === 0).map(e => U.text(e)).join('|').slice(0, 4000);
  const sections = [];
  rightEls.forEach((e) => {
    if (sections.length >= 8) return;
    if (/^H[1-6]$/.test(e.tagName) || /(title|heading|header|section-name)/i.test(e.className + '') || e.tagName === 'DT') {
      const t = U.text(e).slice(0, 40);
      if (t && !sections.includes(t)) sections.push(t);
    }
  });
  return { selected, rightText, sections };
}

async function extractPattern(url) {
  const browser = await chromium.launch({ headless: true });
  try {
    const context = await browser.newContext({
      viewport: { width: 1440, height: 900 },
      storageState: fs.existsSync(STORAGE_STATE) ? STORAGE_STATE : undefined
    });
    const page = await context.newPage();
    await page.goto(url, { waitUntil: 'load', timeout: 25000 });
    await page.waitForLoadState('networkidle', { timeout: 8000 }).catch(() => {});
    await page.waitForTimeout(600);
    await page.evaluate(installHelpers);

    const png = await page.screenshot();
    const base = await page.evaluate(pageScan, safety.DESTRUCTIVE_SRC);

    /* sticky header: scroll and see whether the header cell moves */
    let stickyHeader = false;
    if (base.grid && base.grid.headerSel) {
      stickyHeader = await page.evaluate((g) => {
        const h = document.querySelector(g.headerSel);
        if (!h) return false;
        const scroller = g.scrollerSel ? document.querySelector(g.scrollerSel) : null;
        const before = h.getBoundingClientRect().top;
        if (scroller) scroller.scrollTop += 300; else window.scrollBy(0, 300);
        // force layout
        const after = h.getBoundingClientRect().top;
        const row = g.firstRowSel ? document.querySelector(g.firstRowSel) : null;
        const contentMoved = !row || Math.abs(row.getBoundingClientRect().top) >= 0; // rows exist either way
        if (scroller) scroller.scrollTop -= 300; else window.scrollBy(0, -300);
        return contentMoved && Math.abs(after - before) < 5;
      }, base.grid).catch(() => false);
    }

    /* SAFE MODE row click: selection mode + detail panel (first data row only) */
    let selectionMode = 'none';
    let detailPanel = { exists: false, sections: [] };
    if (base.grid && base.grid.checkboxRows) selectionMode = 'multi';
    if (base.grid && base.grid.firstCellSel) {
      try {
        await page.click(base.grid.firstCellSel, { timeout: 3000 });
        await page.waitForTimeout(700);
        const after = await page.evaluate(afterClickScan, { firstRowSel: base.grid.firstRowSel });
        if (after.selected && selectionMode === 'none') selectionMode = 'single';
        const changed = after.rightText !== base.rightText && after.rightText.length > base.rightText.length + 30;
        if (changed) detailPanel = { exists: true, sections: after.sections };
        await page.keyboard.press('Escape').catch(() => {});
      } catch (e) { /* row not clickable — fine */ }
    }

    return {
      url,
      capturedOn: new Date().toISOString(),
      title: base.title,
      zones: base.zones,
      grid: base.grid ? {
        columnsVisible: base.grid.columnsVisible,
        columnNames: base.grid.columnNames,
        rowCount: base.grid.rowCount,
        rowHeight: base.grid.rowHeight,
        stickyHeader,
        sortIndicators: base.grid.sortIndicators,
        selectionMode,
        rowActions: base.grid.rowActions
      } : null,
      components: base.components,
      detailPanel,
      placeholders: {
        grid_columns: base.grid ? base.grid.columnNames : [],
        row_actions: base.grid ? base.grid.rowActions : [],
        detail_sections: detailPanel.sections,
        bulk_actions: base.zones.top.buttons
      },
      png
    };
  } finally {
    await browser.close().catch(() => {});
  }
}

module.exports = { extractPattern };
