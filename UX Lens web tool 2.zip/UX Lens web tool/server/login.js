/**
 * login.js — helper for login-protected apps.
 *
 * Usage:  npm run login -- http://localhost:4200
 *
 * Opens a REAL (visible) browser window. Log in normally, then come back to the
 * terminal and press Enter. Your session cookies are saved to storageState.json,
 * and every later analysis reuses them automatically. Delete storageState.json
 * to forget the session.
 */

const { chromium } = require('playwright');

(async () => {
  const url = process.argv[2] || 'http://localhost:4200';
  console.log('\nOpening a browser at ' + url);
  console.log('Log in there, then come back HERE and press Enter to save the session…\n');

  const browser = await chromium.launch({ headless: false });
  const context = await browser.newContext();
  const page = await context.newPage();
  await page.goto(url).catch(() => console.log('(Could not open the URL — you can still navigate manually in the window.)'));

  process.stdin.resume();
  await new Promise((resolve) => process.stdin.once('data', resolve));

  await context.storageState({ path: 'storageState.json' });
  console.log('Session saved to storageState.json — analyses will now use it.\n');
  await browser.close();
  process.exit(0);
})();
