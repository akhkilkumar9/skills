/**
 * safety.js — the single source of truth for what UX Lens may and may not touch.
 *
 * UX Lens is READ-ONLY by design. The only interactions it ever performs:
 *   - Pressing Tab / Escape / configured shortcuts (never Enter)
 *   - Clicking ONE button to open a dialog, and only if its text matches
 *     the SAFE_OPENERS list below and does NOT match DESTRUCTIVE.
 */

// Never click anything whose text or aria-label matches this (case-insensitive).
const DESTRUCTIVE = /\b(submit|send|save|confirm|release|delete|remove|approve|execute|buy|sell|order|pay|apply|cancel order|terminate|revoke)\b/i;

// Buttons that are safe to click to try opening a dialog (I1/I2 checks).
const SAFE_OPENERS = /\b(filter|filters|settings|columns|options|preferences|view|customi[sz]e|more)\b/i;

// Keys we refuse to simulate even if a screen-config asks for them.
const FORBIDDEN_KEYS = /\b(enter|delete|backspace)\b/i;

module.exports = {
  DESTRUCTIVE,
  SAFE_OPENERS,
  FORBIDDEN_KEYS,
  // Source strings so the same patterns can be re-created inside the page context.
  DESTRUCTIVE_SRC: DESTRUCTIVE.source,
  SAFE_OPENERS_SRC: SAFE_OPENERS.source
};
