/**
 * server/library-sync.js — syncs a locally running Storybook into /library.
 *
 * Rule-based and local only: fetches the Storybook index (index.json for v7+,
 * stories.json for v6), renders each story in isolation with Playwright, and
 * captures a clipped screenshot + measured computed styles per variant.
 * designerNotes on existing components are ALWAYS preserved across re-syncs.
 */

const fs = require('fs');
const path = require('path');
const { chromium } = require('playwright');
const store = require('../src/engine/store');

/* live progress for the UI to poll */
const progress = { running: false, done: 0, total: 0 };
function getProgress() { return { ...progress }; }

async function fetchJson(url) {
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), 6000);
  try {
    const res = await fetch(url, { signal: ctl.signal });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    return await res.json();
  } finally {
    clearTimeout(timer);
  }
}

function kebab(s) {
  return String(s).toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 80) || 'component';
}

/** Read the story list from a Storybook (v7 index.json, falling back to v6 stories.json). */
async function loadStoryIndex(base) {
  let idx = null;
  try { idx = await fetchJson(base + '/index.json'); } catch (e) { /* try v6 */ }
  if (idx && idx.entries) {
    return Object.values(idx.entries)
      .filter(e => (e.type ? e.type === 'story' : true))
      .map(e => ({ id: e.id, title: e.title, name: e.name }));
  }
  const v6 = await fetchJson(base + '/stories.json'); // throws if unreachable
  if (!v6 || !v6.stories) throw new Error('Unrecognized Storybook index format.');
  return Object.values(v6.stories)
    .filter(e => !(e.parameters && e.parameters.docsOnly))
    .map(e => ({ id: e.id, title: e.kind || e.title, name: e.story || e.name }));
}

/** Runs in the story iframe: locate the rendered component, measure it. */
function measureStory() {
  const root = document.querySelector('#storybook-root, #root');
  if (!root) return null;
  let el = root.firstElementChild || root;
  while (el && el.getBoundingClientRect().width === 0 && el.firstElementChild) el = el.firstElementChild;
  if (!el) return null;
  const r = el.getBoundingClientRect();
  if (r.width === 0 || r.height === 0) return null;
  const meas = (n) => {
    const cs = getComputedStyle(n);
    const b = n.getBoundingClientRect();
    return {
      backgroundColor: cs.backgroundColor, color: cs.color,
      fontSize: cs.fontSize, fontFamily: (cs.fontFamily || '').split(',')[0].replace(/"/g, ''),
      height: Math.round(b.height), padding: cs.padding, borderRadius: cs.borderRadius
    };
  };
  // root custom-element tag (the component itself or its first custom-element descendant)
  const ce = [el, ...el.querySelectorAll('*')].find(x => x.tagName && x.tagName.includes('-'));
  const child = el.querySelector('button, input, select, [role=button]');
  return {
    rect: { x: r.x, y: r.y, w: r.width, h: r.height },
    tag: ce ? ce.tagName.toLowerCase() : null,
    measured: { root: meas(el), child: child && child !== el ? meas(child) : null }
  };
}

async function syncLibrary(baseUrl) {
  const base = String(baseUrl || 'http://localhost:6006').trim().replace(/\/+$/, '');
  let stories;
  try {
    stories = await loadStoryIndex(base);
  } catch (e) {
    const err = new Error('STORYBOOK_UNREACHABLE');
    err.detail = e.message;
    throw err;
  }
  if (!stories.length) throw new Error('The Storybook index contains no stories.');

  store.ensureDirs();
  progress.running = true; progress.done = 0; progress.total = stories.length;
  const failures = [];
  const byComponent = {}; // title -> { variants: [] }

  const browser = await chromium.launch({ headless: true });
  try {
    const context = await browser.newContext({ viewport: { width: 1200, height: 800 } });
    const page = await context.newPage();
    for (const story of stories) {
      try {
        await page.goto(base + '/iframe.html?id=' + encodeURIComponent(story.id) + '&viewMode=story', { waitUntil: 'load', timeout: 15000 });
        await page.waitForTimeout(450);
        const info = await page.evaluate(measureStory);
        if (!info) throw new Error('nothing rendered');
        // clipped screenshot around the component's bounding box (small margin)
        const clip = {
          x: Math.max(0, info.rect.x - 4),
          y: Math.max(0, info.rect.y - 4),
          width: Math.max(10, Math.min(1200 - Math.max(0, info.rect.x - 4), info.rect.w + 8)),
          height: Math.max(10, Math.min(800 - Math.max(0, info.rect.y - 4), info.rect.h + 8))
        };
        const png = await page.screenshot({ clip });
        const shotName = kebab(story.id) + '.png';
        fs.writeFileSync(path.join(store.LIBRARY_DIR, shotName), png);
        (byComponent[story.title] = byComponent[story.title] || { variants: [], tags: [] });
        byComponent[story.title].variants.push({
          name: story.name, storyId: story.id, screenshot: shotName, measured: info.measured
        });
        if (info.tag) byComponent[story.title].tags.push(info.tag);
      } catch (e) {
        failures.push({ storyId: story.id, error: String(e.message || e).slice(0, 100) });
      }
      progress.done++;
    }
  } finally {
    progress.running = false;
    await browser.close().catch(() => {});
  }

  /* write one JSON per component — MERGING designerNotes from any previous sync */
  const indexComponents = [];
  let variantCount = 0;
  Object.entries(byComponent).forEach(([title, data]) => {
    const id = kebab(title);
    const componentName = title.split('/').pop();
    // most frequent detected tag wins
    const tagCounts = {};
    data.tags.forEach(t => { tagCounts[t] = (tagCounts[t] || 0) + 1; });
    const tag = Object.entries(tagCounts).sort((a, b) => b[1] - a[1]).map(e => e[0])[0] || null;
    const existing = store.getLibraryComponent(id);
    const designerNotes = (existing && existing.designerNotes) || { useWhen: '', doNotUseFor: '', rules: '' };
    const file = { id, component: componentName, title, tag, variants: data.variants, designerNotes };
    store.saveLibraryComponent(id, file);
    variantCount += data.variants.length;
    indexComponents.push({
      id, component: componentName, title, tag,
      variantCount: data.variants.length,
      hasNotes: !!(designerNotes.useWhen || designerNotes.doNotUseFor || designerNotes.rules),
      useWhen: designerNotes.useWhen || '',
      variants: data.variants.map(v => ({ name: v.name, measured: v.measured }))
    });
  });
  const index = { syncedAt: new Date().toISOString(), source: base, components: indexComponents };
  store.writeLibraryIndex(index);
  return {
    components: indexComponents.length,
    variants: variantCount,
    skipped: failures,
    syncedAt: index.syncedAt
  };
}

module.exports = { syncLibrary, getProgress };
