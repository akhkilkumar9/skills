/**
 * inpage-helpers.js — helpers injected INTO the analyzed page as window.__uxlens.
 * The exported function is serialized by Playwright and executed in the browser,
 * so it must be fully self-contained (no Node APIs, no closures over this file).
 */

function installHelpers() {
  if (window.__uxlens) return;

  /** Is the element actually rendered and visible? */
  function isVisible(el) {
    if (!el || el.nodeType !== 1) return false;
    const s = getComputedStyle(el);
    if (s.display === 'none' || s.visibility === 'hidden' || parseFloat(s.opacity) === 0) return false;
    const r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0;
  }

  /** Build a short, stable CSS selector for an element (id > classes > nth-of-type). */
  function cssPath(el) {
    if (!el || el.nodeType !== 1) return '';
    if (el.id) return '#' + CSS.escape(el.id);
    const parts = [];
    let node = el;
    while (node && node.nodeType === 1 && node !== document.body && parts.length < 6) {
      if (node.id) { parts.unshift('#' + CSS.escape(node.id)); break; }
      let sel = node.tagName.toLowerCase();
      // Skip Angular's volatile ng-* state classes; keep up to 2 meaningful ones
      const cls = [...node.classList].filter(c => !/^(ng-|cdk-focused|cdk-)/.test(c)).slice(0, 2);
      if (cls.length) sel += '.' + cls.map(c => CSS.escape(c)).join('.');
      const parent = node.parentElement;
      if (parent) {
        const same = [...parent.children].filter(s => s.tagName === node.tagName);
        if (same.length > 1) sel += ':nth-of-type(' + (same.indexOf(node) + 1) + ')';
      }
      parts.unshift(sel);
      node = parent;
    }
    return parts.join(' > ');
  }

  /** Bounding box in DOCUMENT coordinates (matches the full-page screenshot). */
  function docRect(el) {
    const r = el.getBoundingClientRect();
    return { x: Math.round(r.x + scrollX), y: Math.round(r.y + scrollY), w: Math.round(r.width), h: Math.round(r.height) };
  }

  /** Trimmed visible text. */
  function text(el) {
    return ((el.innerText !== undefined ? el.innerText : el.textContent) || '').trim().replace(/\s+/g, ' ');
  }

  /** Does a string parse as a number once currency symbols / grouping are stripped? */
  function isNumeric(s) {
    const cleaned = String(s).trim().replace(/[₹$€£%()\s]/g, '').replace(/,/g, '');
    if (cleaned === '' || cleaned === '-') return false;
    return !isNaN(Number(cleaned));
  }

  /**
   * Discover data grids: native <table> and ARIA grids (ag-Grid, Material, custom).
   * Returns [{ el, kind, headers[], rows[], cellsOf(row) }]
   */
  function grids() {
    const out = [];
    document.querySelectorAll('table').forEach((t) => {
      if (!isVisible(t)) return;
      const headers = [...t.querySelectorAll('thead th, thead td')];
      const rows = [...t.querySelectorAll('tbody tr')].filter(isVisible);
      if (!rows.length && !headers.length) return;
      out.push({ el: t, kind: 'table', headers, rows, cellsOf: (r) => [...r.children] });
    });
    document.querySelectorAll('[role="grid"], [role="table"], [role="treegrid"]').forEach((g) => {
      if (g.closest('table') || !isVisible(g)) return;
      const headers = [...g.querySelectorAll('[role="columnheader"]')].filter(isVisible);
      const rows = [...g.querySelectorAll('[role="row"]')]
        .filter(r => isVisible(r) && !r.querySelector('[role="columnheader"]'));
      out.push({ el: g, kind: 'aria', headers, rows, cellsOf: (r) => [...r.querySelectorAll('[role="gridcell"], [role="cell"]')] });
    });
    return out;
  }

  /** Column model for a grid: [{ index, name, header, cells[] }] (samples up to 50 rows). */
  function columns(grid) {
    const cols = [];
    grid.rows.slice(0, 50).forEach((r) => {
      grid.cellsOf(r).forEach((c, i) => { (cols[i] = cols[i] || []).push(c); });
    });
    return cols.map((cells, i) => ({
      index: i, cells,
      header: grid.headers[i] || null,
      name: grid.headers[i] ? text(grid.headers[i]) : 'column ' + (i + 1)
    }));
  }

  window.__uxlens = { isVisible, cssPath, docRect, text, isNumeric, grids, columns };
}

module.exports = { installHelpers };
