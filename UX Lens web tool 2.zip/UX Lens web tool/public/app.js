/**
 * app.js — UX DesignLab UI.
 * Plain JavaScript, no framework. Three modules in the left rail:
 *   Overview          — dashboard built only from locally stored results
 *   UX Audit          — run rule-based audits with selectable categories
 *   Pattern Generator — capture reference patterns + compose generation prompts
 *
 * The same file powers exported reports: when window.UXLENS_EMBEDDED holds a
 * report object, we render just that report and hide the app chrome.
 */

/* ---------- icons ---------- */
const ICON = {
  overview: '<path d="M4 4h7v7H4zM13 4h7v7h-7zM4 13h7v7H4zM13 13h7v7h-7z"/>',
  audit: '<circle cx="11" cy="11" r="7"/><path d="M16.5 16.5L21 21"/>',
  patterns: '<rect x="3" y="3" width="13" height="13" rx="2"/><path d="M8 21h11a2 2 0 002-2V8"/>',
  library: '<path d="M12 3l9 5-9 5-9-5z"/><path d="M3 13l9 5 9-5"/>',
  usability: '<path d="M5 3l14 7-6 2-2 6z"/>',
  ia: '<circle cx="12" cy="4" r="1.7"/><path d="M12 6v4m0 0c-4.5 0-7 1.5-7 5m7-5c4.5 0 7 1.5 7 5m-7-5v5"/><circle cx="5" cy="18" r="2"/><circle cx="12" cy="18" r="2"/><circle cx="19" cy="18" r="2"/>',
  hierarchy: '<path d="M4 5h16M4 10h11M4 15h13M4 20h7"/>',
  interaction: '<path d="M9 3.5v2.5M3.5 9H6M5 5l1.8 1.8M13 13l7.5 3-3.4 1.6L15.5 21z"/>',
  accessibility: '<circle cx="12" cy="4.5" r="2"/><path d="M4 9.5h16M12 9.5v5l-3.5 6M12 14.5l3.5 6"/>'
};
const icon = (id, size) => '<svg width="' + (size || 15) + '" height="' + (size || 15) + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + ICON[id] + '</svg>';

/* ---------- the five categories (mirrors rules/index.js lenses) ---------- */
const LENSES = [
  { id: 'usability', name: 'Usability Heuristics', desc: 'Status, control, errors, consistency', tagline: 'Is it intuitive and easy to use?' },
  { id: 'ia', name: 'Information Architecture', desc: 'Labels, terminology, grouping, defaults', tagline: 'Is information organized and easy to find?' },
  { id: 'hierarchy', name: 'Visual Hierarchy', desc: 'Emphasis, density, alignment, truncation', tagline: 'Is the right information and action emphasized?' },
  { id: 'interaction', name: 'Interaction Design', desc: 'Keyboard, focus, dialogs, states', tagline: 'Are actions, states, and feedback clear?' },
  { id: 'accessibility', name: 'Accessibility', desc: 'Contrast, ARIA, zoom, color-blind safety', tagline: 'Can users with different abilities use it effectively?' }
];
const lensById = Object.fromEntries(LENSES.map(l => [l.id, l]));
const MODULES = [
  { id: 'overview', name: 'Overview' },
  { id: 'audit', name: 'UX Audit' },
  { id: 'patterns', name: 'Pattern Generator' },
  { id: 'library', name: 'Component Library' }
];

/* ---------- helpers ---------- */
const $ = (id) => document.getElementById(id);
const el = (tag, cls, text) => {
  const n = document.createElement(tag);
  if (cls) n.className = cls;
  if (text !== undefined) n.textContent = text;
  return n;
};
const SEV_LABEL = { fail: 'Fail', improve: 'Improve' };
const gradeOf = (s) => s >= 90 ? 'good' : s >= 70 ? 'warn' : 'bad';
const gradeWord = (s) => s >= 90 ? 'Looking solid' : s >= 70 ? 'Needs polish' : 'Needs work';
const scoreColor = (s) => s >= 90 ? '#00A251' : s >= 70 ? '#E9690C' : '#D92D20';
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

/* ---------- state ---------- */
let module_ = 'overview';   // 'overview' | 'audit' | 'patterns'
let report = null;          // currently shown audit report
let lensFilter = 'all';     // filter inside the report view
let selectedCats = new Set(LENSES.map(l => l.id)); // audit category selection
let auditUrl = '';          // preserved across re-renders
let selectedId = null;
let scale = 1;
let searchQuery = ''; // sidebar search: filters issues + pattern library

/* ---------- recent URLs (per module, in localStorage) ---------- */
function recKey(mod) { return 'uxdl-recent-' + mod; }
function getRecent(mod) {
  try { return JSON.parse(localStorage.getItem(recKey(mod)) || '[]'); } catch { return []; }
}
function addRecent(mod, url) {
  const list = getRecent(mod).filter(u => u !== url);
  list.unshift(url);
  try { localStorage.setItem(recKey(mod), JSON.stringify(list.slice(0, 8))); } catch (e) {}
}
/** Own module's URLs first, then the other module's, labeled. */
function datalistOptions(ownMod, otherMod, otherLabel) {
  const own = getRecent(ownMod);
  const other = getRecent(otherMod).filter(u => !own.includes(u));
  return own.map(u => '<option value="' + esc(u) + '"></option>').join('') +
    other.map(u => '<option value="' + esc(u) + '" label="(from ' + otherLabel + ')"></option>').join('');
}

/* ---------- boot ---------- */
document.addEventListener('DOMContentLoaded', () => {
  buildSideNav();
  $('exportBtn').addEventListener('click', exportReport);
  window.addEventListener('resize', fitScreenshot);
  const gs = $('globalSearch');
  if (gs) gs.addEventListener('input', () => {
    searchQuery = gs.value.trim().toLowerCase();
    if (module_ === 'audit' && report && !$('auditReport').hidden) renderIssueList();
    if (module_ === 'patterns') renderPatterns();
    if (module_ === 'library') renderLibrary();
  });
  if (window.UXLENS_EMBEDDED) {
    document.body.classList.add('embedded');
    report = window.UXLENS_EMBEDDED;
    showModule('audit');
    return;
  }
  showModule('overview');
});

function buildSideNav() {
  const nav = $('sideNav');
  nav.innerHTML = '';
  const groups = [
    { label: 'Overview', items: [MODULES[0]] },
    { label: 'Modules', items: [MODULES[1], MODULES[2], MODULES[3]] }
  ];
  groups.forEach((g) => {
    nav.appendChild(el('div', 'nav-label', g.label));
    g.items.forEach((m) => {
      const b = el('button', 'nav-item');
      b.dataset.view = m.id;
      b.innerHTML = icon(m.id) + '<span class="nav-name">' + m.name + '</span>';
      b.addEventListener('click', () => showModule(m.id));
      nav.appendChild(b);
    });
  });
}

function showModule(id) {
  module_ = id;
  hideError();
  document.querySelectorAll('.nav-item').forEach(n => n.classList.toggle('active', n.dataset.view === id));
  const crumb = $('crumbModule');
  if (crumb) crumb.textContent = ({ overview: 'Overview', audit: 'UX Audit', patterns: 'Pattern Generator', library: 'Component Library' })[id] || id;
  ['loading', 'page-overview', 'page-audit', 'page-patterns', 'page-library'].forEach(p => { $(p).hidden = true; });
  $('page-' + id).hidden = false;
  if (id === 'overview') renderOverview();
  if (id === 'audit') { renderAuditSetup(); renderReportSection(); }
  if (id === 'patterns') renderPatterns();
  if (id === 'library') renderLibrary();
}

function setLoading(onMsg, sub) {
  ['page-overview', 'page-audit', 'page-patterns', 'page-library'].forEach(p => { $(p).hidden = true; });
  $('loading').hidden = false;
  $('loadingMsg').textContent = onMsg;
  $('loadingSub').textContent = sub || '';
}
function showError(msg) { const b = $('errorBanner'); b.textContent = msg; b.hidden = false; }
function hideError() { $('errorBanner').hidden = true; }

/* ================================================================ */
/* OVERVIEW — reads stored results only, never runs analysis        */
/* ================================================================ */
async function renderOverview() {
  const page = $('page-overview');
  const today = new Date().toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
  page.innerHTML =
    '<div class="greet"><div>' +
    '<div class="overline">' + today + '</div>' +
    '<h1>Welcome to UX Workbench</h1>' +
    '<p>Your team\u2019s UX intelligence for the modernization.</p>' +
    '</div></div>' +
    '<div class="ov-grid" id="ovGrid"><div class="card ov-card ov-empty">Loading stored results\u2026</div></div>';
  let data = null;
  try {
    const res = await fetch('/api/overview');
    if (res.ok) data = await res.json();
  } catch (e) { /* server not running (e.g. static preview) */ }
  const grid = $('ovGrid');
  grid.innerHTML = '';
  if (!data) {
    const c = el('div', 'card ov-card ov-empty');
    c.innerHTML = 'The UX Workbench server is not reachable, so stored results can\u2019t be read.<br>Start it with <code>npm start</code> and open <code>http://localhost:5000</code>.';
    grid.appendChild(c);
    grid.appendChild(ovEmptyCard('audit', 'No screens audited yet — run your first UX Audit', 'Run a UX Audit'));
    grid.appendChild(ovEmptyCard('patterns', 'No patterns captured yet — capture your first pattern', 'Capture a pattern'));
    grid.appendChild(ovEmptyCard('library', 'No library synced yet', 'Sync the component library'));
    return;
  }
  grid.appendChild(ovAuditCard(data.cards.audit));
  grid.appendChild(ovPatternsCard(data.cards.patterns));
  grid.appendChild(ovLibraryCard(data.cards.library));
  grid.appendChild(ovTopIssuesCard(data.cards.topIssues));
}

function ovEmptyCard(moduleId, message, buttonText) {
  const card = el('div', 'card ov-card');
  const name = moduleId === 'audit' ? 'UX Audit' : moduleId === 'library' ? 'Component Library' : 'Pattern Generator';
  card.innerHTML = '<h2><span class="icon-chip tint-' + moduleId + '">' + icon(moduleId, 14) + '</span>' + name + '</h2>';
  const box = el('div', 'ov-empty');
  box.appendChild(el('div', null, message));
  const btn = el('button', 'btn-ghost', buttonText);
  btn.addEventListener('click', () => showModule(moduleId));
  box.appendChild(btn);
  card.appendChild(box);
  return card;
}

function miniRing(score, label) {
  const box = el('div', 'mini-ring');
  const has = score !== null && score !== undefined;
  const svg = arcSvg(has ? score : null, 44, 5);
  box.appendChild(svg);
  const val = el('span', 'mr-val', has ? String(score) : '—');
  val.style.color = has ? scoreColor(score) : '#90A5BB';
  box.appendChild(val);
  box.appendChild(el('span', 'mr-lbl', label));
  return box;
}

function ovAuditCard(c) {
  if (!c || c.empty) return ovEmptyCard('audit', 'No screens audited yet — run your first UX Audit', 'Run a UX Audit');
  const d = c.data;
  const card = el('div', 'card ov-card');
  card.innerHTML = '<h2><span class="icon-chip tint-audit">' + icon('audit', 14) + '</span>UX Audit</h2>';
  const stats = el('div', 'ov-stats');
  [[d.total, 'screens audited'], [d.avgOverall, 'average score']].forEach(([num, lbl]) => {
    const s = el('div', 'ov-stat');
    const n = el('div', 'num', String(num));
    if (lbl === 'average score') n.style.color = scoreColor(d.avgOverall);
    s.appendChild(n);
    s.appendChild(el('div', 'lbl', lbl));
    stats.appendChild(s);
  });
  card.appendChild(stats);
  const rings = el('div', 'mini-rings');
  d.lensAverages.forEach(l => rings.appendChild(miniRing(l.avg, lensById[l.id] ? lensById[l.id].name.split(' ')[0] : l.id)));
  card.appendChild(rings);
  const list = el('div', 'row-list');
  d.recent.forEach((r) => {
    const row = el('button', 'row-item');
    const main = el('div', 'r-main');
    main.appendChild(el('div', 'r-url', r.url));
    main.appendChild(el('div', 'r-sub', new Date(r.timestamp).toLocaleString() + (r.partial ? ' · ' + r.lensesRun.length + ' of 5 categories' : '')));
    row.appendChild(main);
    const score = el('span', 'r-score', String(r.overall));
    score.style.color = scoreColor(r.overall);
    if (r.partial) score.textContent = r.overall + '*';
    row.appendChild(score);
    row.title = r.partial ? 'Partial audit — ' + r.lensesRun.length + ' of 5 categories' : 'Open saved report';
    row.addEventListener('click', () => openSavedReport(r.id));
    list.appendChild(row);
  });
  card.appendChild(list);
  if (d.recent.some(r => r.partial)) card.appendChild(el('div', 'r-sub', '* partial audit — score covers only the categories that were run'));
  return card;
}

function ovPatternsCard(c) {
  if (!c || c.empty) return ovEmptyCard('patterns', 'No patterns captured yet — capture your first pattern', 'Capture a pattern');
  const d = c.data;
  const card = el('div', 'card ov-card');
  card.innerHTML = '<h2><span class="icon-chip tint-patterns">' + icon('patterns', 14) + '</span>Pattern Generator</h2>';
  const stats = el('div', 'ov-stats');
  [[d.count, 'saved patterns']].forEach(([num, lbl]) => {
    const s = el('div', 'ov-stat');
    s.appendChild(el('div', 'num', String(num)));
    s.appendChild(el('div', 'lbl', lbl));
    stats.appendChild(s);
  });
  card.appendChild(stats);
  const thumbs = el('div', 'thumb-row');
  d.recent.forEach((p) => {
    const img = document.createElement('img');
    img.src = p.thumb; img.alt = p.name; img.title = p.name;
    thumbs.appendChild(img);
  });
  card.appendChild(thumbs);
  const open = el('button', 'link-btn', 'Open Pattern Generator \u2192');
  open.style.marginTop = '10px';
  open.addEventListener('click', () => showModule('patterns'));
  card.appendChild(open);
  return card;
}

function ovLibraryCard(c) {
  if (!c || c.empty) return ovEmptyCard('library', 'No library synced yet', 'Sync the component library');
  const d = c.data;
  const card = el('div', 'card ov-card');
  card.innerHTML = '<h2><span class="icon-chip tint-library">' + icon('library', 14) + '</span>Component Library</h2>';
  const stats = el('div', 'ov-stats');
  [[d.count, 'components synced'], [d.variants, 'variants']].forEach(([num, lbl]) => {
    const s = el('div', 'ov-stat');
    s.appendChild(el('div', 'num', String(num)));
    s.appendChild(el('div', 'lbl', lbl));
    stats.appendChild(s);
  });
  card.appendChild(stats);
  card.appendChild(el('div', 'r-sub', 'Last sync: ' + new Date(d.syncedAt).toLocaleString()));
  if (d.needNotes > 0) {
    const warn = el('div', 'warn-note', d.needNotes + ' component' + (d.needNotes === 1 ? '' : 's') + ' need' + (d.needNotes === 1 ? 's' : '') + ' usage notes.');
    card.appendChild(warn);
  }
  const open = el('button', 'link-btn', 'Open Component Library \u2192');
  open.style.marginTop = '10px';
  open.addEventListener('click', () => showModule('library'));
  card.appendChild(open);
  return card;
}

function ovTopIssuesCard(c) {
  const card = el('div', 'card ov-card');
  card.innerHTML = '<h2><span class="icon-chip tint-top">' + icon('hierarchy', 14) + '</span>Top recurring issues</h2>';
  if (!c || c.empty) {
    const box = el('div', 'ov-empty', 'Once audits are saved, the most frequent rule failures across all screens show up here \u2014 your systemic problems.');
    card.appendChild(box);
    return card;
  }
  const d = c.data;
  const wrap = el('div', 'meter-row');
  d.items.forEach((it) => {
    const item = el('div', 'm-item');
    const top = el('div', 'm-top');
    const name = el('span');
    name.innerHTML = '<strong>' + esc(it.title) + '</strong> <span style="color:#6C849D">\u00B7 ' + esc(lensById[it.lens] ? lensById[it.lens].name : '') + '</span>';
    top.appendChild(name);
    top.appendChild(el('span', 'm-count', it.screens + ' of ' + d.screensTotal + ' screens'));
    item.appendChild(top);
    const bar = el('div', 'm-bar');
    const fill = el('i');
    fill.style.width = Math.round(100 * it.screens / d.screensTotal) + '%';
    fill.style.background = it.severity === 'fail' ? '#D92D20' : '#E9690C';
    bar.appendChild(fill);
    item.appendChild(bar);
    wrap.appendChild(item);
  });
  card.appendChild(wrap);
  return card;
}

async function openSavedReport(id) {
  hideError();
  try {
    const res = await fetch('/api/reports/' + encodeURIComponent(id));
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Could not load the report.');
    report = data;
    lensFilter = 'all';
    selectedId = null;
    showModule('audit');
  } catch (e) {
    showError(e.message);
  }
}

/* ================================================================ */
/* UX AUDIT                                                          */
/* ================================================================ */
function renderAuditSetup() {
  const box = $('auditSetup');
  box.innerHTML = '';
  const card = el('div', 'card setup-card');
  card.innerHTML = '<h2>UX Audit</h2><p class="setup-sub">Rule-based checks against one screen of your running app. Pick the categories to run \u2014 fewer categories, faster audit.</p>';

  // URL row (module-local, with recent URLs from both modules)
  const row = el('div', 'url-row');
  row.innerHTML =
    '<div class="url-pill"><span class="url-prefix">screen</span>' +
    '<input id="auditUrl" list="auditRecentList" type="text" placeholder="http://localhost:4200/trades" spellcheck="false" aria-label="URL of the screen to audit" value="' + esc(auditUrl) + '"></div>' +
    '<datalist id="auditRecentList">' + datalistOptions('audit', 'pattern', 'Pattern Generator') + '</datalist>';
  const demo = el('button', 'btn-ghost', 'View a sample report');
  demo.type = 'button';
  demo.addEventListener('click', loadDemo);
  row.appendChild(demo);
  card.appendChild(row);

  // category cards
  const grid = el('div', 'cat-grid');
  LENSES.forEach((l) => {
    const c = el('button', 'cat-card' + (selectedCats.has(l.id) ? ' on' : ''));
    c.type = 'button';
    c.setAttribute('role', 'checkbox');
    c.setAttribute('aria-checked', selectedCats.has(l.id) ? 'true' : 'false');
    c.innerHTML = '<div class="cc-top"><span class="icon-chip tint-' + l.id + '">' + icon(l.id, 13) + '</span>' + esc(l.name) + '</div>' +
      '<div class="cc-desc">' + esc(l.desc) + '</div>' +
      '<span class="cc-check">\u2713</span>';
    c.addEventListener('click', () => {
      if (selectedCats.has(l.id)) selectedCats.delete(l.id); else selectedCats.add(l.id);
      c.classList.toggle('on', selectedCats.has(l.id));
      c.setAttribute('aria-checked', selectedCats.has(l.id) ? 'true' : 'false');
      updateRunButton();
    });
    grid.appendChild(c);
  });
  card.appendChild(grid);

  // run row
  const run = el('div', 'run-row');
  const runBtn = el('button', 'btn-primary');
  runBtn.id = 'runBtn';
  runBtn.type = 'button';
  runBtn.addEventListener('click', runAudit);
  run.appendChild(runBtn);
  const selAll = el('button', 'link-btn', 'Select all');
  selAll.type = 'button';
  selAll.addEventListener('click', () => {
    const all = selectedCats.size === LENSES.length;
    selectedCats = new Set(all ? [] : LENSES.map(l => l.id));
    renderAuditSetup(); // re-render cards + button
  });
  run.appendChild(selAll);
  run.appendChild(el('span', 'run-hint', 'At least one category is required. Partial audits are clearly marked in reports and on the Overview.'));
  card.appendChild(run);
  box.appendChild(card);
  const input = card.querySelector('#auditUrl');
  input.addEventListener('input', () => { auditUrl = input.value; });
  input.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); runAudit(); } });
  updateRunButton();
  // library-consistency unlock hint (only when the server is reachable and no library is synced)
  fetch('/api/library').then(r => r.ok ? r.json() : null).then((lib) => {
    if (!lib || (lib.components && lib.components.length)) return;
    const note = el('div', 'not-run-note');
    note.appendChild(document.createTextNode('Sync your component library to unlock consistency checks (non-library lookalikes, off-library styling) under Visual Hierarchy. '));
    const go = el('button', 'link-btn', 'Open Component Library \u2192');
    go.addEventListener('click', () => showModule('library'));
    note.appendChild(go);
    box.appendChild(note);
  }).catch(() => {});
}

function updateRunButton() {
  const btn = $('runBtn');
  if (!btn) return;
  const n = selectedCats.size;
  btn.disabled = n === 0;
  btn.textContent = n === 0 ? 'Select at least one category' : 'Run audit (' + n + ' of ' + LENSES.length + ' categories)';
}

const LOADING_MSGS = [
  'Opening the page in a headless browser\u2026',
  'Waiting for the app to finish loading\u2026',
  'Running the selected categories\u2019 rules\u2026',
  'Walking the keyboard tab order\u2026',
  'Testing dialogs and shortcuts (safe mode)\u2026',
  'Taking the annotated screenshot\u2026',
  'Building your report\u2026'
];
let loadingTimer = null;

async function runAudit() {
  const url = ($('auditUrl') ? $('auditUrl').value : auditUrl).trim();
  auditUrl = url;
  hideError();
  if (!url) { showError('Paste the URL of the screen you want to audit, e.g. http://localhost:4200/trades'); return; }
  if (!selectedCats.size) { showError('Select at least one category to run.'); return; }
  const lensIds = selectedCats.size === LENSES.length ? null : [...selectedCats];
  setLoading(LOADING_MSGS[0], 'Running ' + selectedCats.size + ' of ' + LENSES.length + ' categories.');
  let i = 0;
  loadingTimer = setInterval(() => { i = Math.min(i + 1, LOADING_MSGS.length - 1); $('loadingMsg').textContent = LOADING_MSGS[i]; }, 4500);
  try {
    const res = await fetch('/api/analyze', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url, lenses: lensIds || undefined })
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || 'Audit failed (' + res.status + ')');
    report = data;
    lensFilter = 'all';
    selectedId = null;
    addRecent('audit', url);
  } catch (e) {
    showError(e.message.includes('Failed to fetch')
      ? 'Could not reach the UX Workbench server. Start it with "npm start" and open http://localhost:5000.'
      : e.message);
  } finally {
    clearInterval(loadingTimer);
    $('loading').hidden = true;
    showModule('audit');
  }
}

async function loadDemo() {
  hideError();
  try {
    const res = await fetch('demo-data.json');
    report = await res.json();
    lensFilter = 'all';
    selectedId = null;
    showModule('audit');
  } catch (e) {
    showError('Could not load the sample report.');
  }
}

/* ---- the report section inside UX Audit ---- */
function ranLensIds() { return (report && (report.lensesRun || (report.lenses || []).filter(l => l.ran).map(l => l.id))) || []; }
function isPartial() { return ranLensIds().length > 0 && ranLensIds().length < LENSES.length; }

function renderReportSection() {
  const wrap = $('auditReport');
  if (!report) { wrap.hidden = true; $('exportBtn').hidden = true; return; }
  wrap.hidden = false;
  $('exportBtn').hidden = false;
  renderReportHead();
  renderLensCards();
  renderIssueList();
  renderScreenshot();
  renderDetail(null);
  renderManual();
}

function arcSvg(score, size, width) {
  const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  const w = width || 7;
  const r = (size - w - 3) / 2, c = size / 2, circ = 2 * Math.PI * r;
  const has = score !== null && score !== undefined;
  const val = has ? score : 0;
  const color = has ? scoreColor(val) : '#CBD5E2';
  svg.setAttribute('class', 'score-arc');
  svg.setAttribute('viewBox', '0 0 ' + size + ' ' + size);
  svg.setAttribute('width', size); svg.setAttribute('height', size);
  svg.innerHTML =
    '<circle cx="' + c + '" cy="' + c + '" r="' + r + '" fill="none" stroke="#E3EAF3" stroke-width="' + w + '"/>' +
    '<circle cx="' + c + '" cy="' + c + '" r="' + r + '" fill="none" stroke="' + color + '" stroke-width="' + w + '" ' +
    'stroke-linecap="round" stroke-dasharray="' + (circ * val / 100) + ' ' + circ + '" transform="rotate(-90 ' + c + ' ' + c + ')"/>';
  return svg;
}

function renderReportHead() {
  const head = $('viewHead');
  head.innerHTML = '';
  const box = el('div', 'view-head');
  const num = el('div', 'big-score', String(report.overall));
  num.style.color = scoreColor(report.overall);
  const numWrap = el('div');
  numWrap.style.display = 'flex'; numWrap.style.alignItems = 'center'; numWrap.style.gap = '18px';
  numWrap.appendChild(num); numWrap.appendChild(arcSvg(report.overall, 88));
  box.appendChild(numWrap);
  const meta = el('div', 'head-meta');
  meta.appendChild(el('div', 'overline', isPartial() ? 'Partial score \u2014 ' + ranLensIds().length + ' of 5 categories' : 'Overall score'));
  meta.appendChild(el('div', 'head-title', report.title || 'Audited screen'));
  const when = new Date(report.timestamp);
  meta.appendChild(el('div', 'head-sub', when.toLocaleString() + (report.durationMs ? ' \u00B7 analyzed in ' + Math.round(report.durationMs / 1000) + 's' : '')));
  meta.appendChild(el('div', 'head-url', report.url));
  box.appendChild(meta);
  const actions = el('div', 'head-actions');
  if (isPartial()) actions.appendChild(el('span', 'grade warn', ranLensIds().length + ' of 5 categories'));
  actions.appendChild(el('span', 'grade ' + gradeOf(report.overall), gradeWord(report.overall)));
  actions.appendChild(el('div', 'head-sub', report.issues.length + ' issue' + (report.issues.length === 1 ? '' : 's') + ' found'));
  box.appendChild(actions);
  head.appendChild(box);
  if (isPartial()) {
    const n = el('div', 'not-run-note');
    n.textContent = 'This is a partial audit: only ' + ranLensIds().map(id => lensById[id].name).join(', ') +
      ' ran. The score covers those categories only \u2014 do not compare it with full-audit scores.';
    head.appendChild(n);
  }
}

function renderLensCards() {
  const wrap = $('lensCards');
  wrap.innerHTML = '';
  (report.lenses || []).forEach((lens) => {
    const def = lensById[lens.id];
    const card = el('button', 'lens-card' + (lensFilter === lens.id ? ' filter-on' : ''));
    const top = el('div', 'lc-top');
    top.innerHTML = '<span class="icon-chip tint-' + lens.id + '">' + icon(lens.id, 14) + '</span>' + (lens.ran
      ? '<span class="badge ' + (lens.counts.fail ? 'badge-fail' : lens.counts.improve ? 'badge-improve' : 'badge-pass') + '">' +
        (lens.counts.fail ? lens.counts.fail + ' fail' : lens.counts.improve ? lens.counts.improve + ' improve' : 'clean') + '</span>'
      : '<span class="badge">not run</span>');
    card.appendChild(top);
    const score = el('div', 'lc-score', lens.ran ? String(lens.score) : '\u2014');
    score.style.color = lens.ran ? scoreColor(lens.score) : '#90A5BB';
    card.appendChild(score);
    card.appendChild(el('div', 'lc-name', lens.name));
    card.appendChild(el('div', 'lc-tag', def ? def.tagline : ''));
    const meter = el('div', 'lc-meter');
    const fill = el('i');
    fill.style.width = (lens.ran ? lens.score : 0) + '%';
    fill.style.background = lens.ran ? scoreColor(lens.score) : '#CBD5E2';
    meter.appendChild(fill);
    card.appendChild(meter);
    card.appendChild(el('div', 'lc-counts', lens.ran
      ? (lensFilter === lens.id ? 'Showing only this category \u2014 click to clear' : 'Click to filter the report to this category')
      : 'Not selected for this run'));
    if (lens.ran) {
      card.addEventListener('click', () => {
        lensFilter = lensFilter === lens.id ? 'all' : lens.id;
        selectedId = null;
        renderLensCards(); renderIssueList(); renderScreenshot(); renderDetail(null);
      });
    }
    wrap.appendChild(card);
  });
}

function visibleIssues() {
  if (!report) return [];
  return lensFilter === 'all' ? report.issues : report.issues.filter(i => i.lens === lensFilter);
}

function renderIssueList() {
  const list = $('issueList');
  list.innerHTML = '';
  const match = (i) => !searchQuery || (i.title + ' ' + i.message + ' ' + i.ruleId).toLowerCase().includes(searchQuery);
  const groups = lensFilter === 'all'
    ? LENSES.map(l => ({ name: l.name, items: report.issues.filter(i => i.lens === l.id && match(i)) })).filter(g => g.items.length)
    : [{ name: lensById[lensFilter].name, items: visibleIssues().filter(match) }];
  let any = false;
  groups.forEach((g) => {
    const head = el('div', 'group-head');
    head.appendChild(el('span', null, g.name));
    head.appendChild(el('span', 'group-count', String(g.items.length)));
    list.appendChild(head);
    g.items.forEach((issue) => {
      any = true;
      const btn = el('button', 'issue-item');
      btn.id = 'item-' + issue.id;
      btn.appendChild(el('span', 'badge badge-' + issue.severity, SEV_LABEL[issue.severity]));
      const body = el('div');
      body.appendChild(el('div', 'issue-title', issue.title));
      body.appendChild(el('div', 'issue-msg', issue.message));
      btn.appendChild(body);
      btn.addEventListener('click', () => selectIssue(issue.id));
      list.appendChild(btn);
    });
  });
  if (!any) list.appendChild(el('div', 'list-empty', searchQuery ? 'No issues match “' + searchQuery + '”.' : 'No automated issues found here — nice!'));
}

function renderScreenshot() {
  const img = $('shotImg'), overlay = $('overlay');
  overlay.innerHTML = '';
  if (!report.screenshot || !report.screenshot.dataUrl) {
    $('shotScroll').innerHTML = '<div class="shot-missing">No screenshot available for this report.</div>';
    return;
  }
  if (img.getAttribute('src') !== report.screenshot.dataUrl) img.src = report.screenshot.dataUrl;
  img.onload = fitScreenshot;
  fitScreenshot();
  visibleIssues().filter(i => i.rect).forEach((issue) => {
    const d = el('div', 'rect' + (issue.severity === 'improve' ? ' improve' : ''));
    d.id = 'rect-' + issue.id;
    d.title = issue.title;
    const { x, y, w, h } = issue.rect;
    d.style.left = (x - 3) + 'px';
    d.style.top = (y - 3) + 'px';
    d.style.width = Math.max(10, w + 6) + 'px';
    d.style.height = Math.max(10, h + 6) + 'px';
    d.addEventListener('click', () => selectIssue(issue.id));
    overlay.appendChild(d);
  });
}

function fitScreenshot() {
  if (!report || !report.screenshot) return;
  const img = $('shotImg'), wrap = $('shotWrap'), scroll = $('shotScroll');
  if (!scroll || !wrap) return;
  const natural = report.screenshot.width || img.naturalWidth;
  if (!natural) return;
  scale = Math.min(1, scroll.clientWidth / natural);
  wrap.style.transform = 'scale(' + scale + ')';
  wrap.style.width = natural + 'px';
  scroll.style.height = Math.min((report.screenshot.height || img.naturalHeight) * scale, innerHeight * 0.66) + 'px';
}

function selectIssue(id) {
  selectedId = id;
  const issue = report.issues.find(i => i.id === id);
  document.querySelectorAll('.issue-item.selected').forEach(n => n.classList.remove('selected'));
  document.querySelectorAll('.rect.selected').forEach(n => n.classList.remove('selected'));
  const item = $('item-' + id), rect = $('rect-' + id);
  if (item) {
    item.classList.add('selected');
    const list = $('issueList');
    list.scrollTo({ top: Math.max(0, item.offsetTop - list.clientHeight / 2 + 40), behavior: 'smooth' });
  }
  if (rect && issue.rect) {
    rect.classList.add('selected');
    const scroll = $('shotScroll');
    scroll.scrollTo({
      top: Math.max(0, issue.rect.y * scale - scroll.clientHeight / 2),
      left: Math.max(0, issue.rect.x * scale - scroll.clientWidth / 2),
      behavior: 'smooth'
    });
  }
  renderDetail(issue);
}

function renderDetail(issue) {
  const pane = $('detail');
  pane.innerHTML = '';
  if (!issue) {
    pane.appendChild(el('div', 'detail-empty', 'Select an issue to see the explanation and its ready-made fix prompt.'));
    return;
  }
  const lensName = lensById[issue.lens] ? lensById[issue.lens].name : issue.category;
  pane.appendChild(el('div', 'detail-rule', issue.ruleId + ' \u00B7 ' + lensName + ' \u00B7 ' + SEV_LABEL[issue.severity]));
  pane.appendChild(el('div', 'detail-title', issue.title));
  pane.appendChild(el('div', 'detail-msg', issue.message));
  const why = el('div', 'detail-why');
  why.innerHTML = '<strong>Why this matters:</strong> ';
  why.appendChild(document.createTextNode(issue.why));
  pane.appendChild(why);
  if (issue.selector) pane.appendChild(el('div', 'detail-selector', issue.selector));
  if (issue.fixPrompt) {
    pane.appendChild(el('div', 'prompt-box', issue.fixPrompt));
    const btn = el('button', 'copy-btn', 'Copy fix prompt');
    btn.addEventListener('click', () => copyText(issue.fixPrompt, btn, 'Copy fix prompt'));
    pane.appendChild(btn);
  }
}

function copyText(text, btn, restoreLabel) {
  const done = () => {
    btn.classList.add('copied');
    btn.textContent = 'Copied \u2014 paste into Copilot';
    setTimeout(() => { btn.classList.remove('copied'); btn.textContent = restoreLabel; }, 2000);
  };
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(text).then(done).catch(() => fallbackCopy(text, done));
  } else fallbackCopy(text, done);
}
function fallbackCopy(text, done) {
  const ta = document.createElement('textarea');
  ta.value = text;
  ta.style.position = 'fixed'; ta.style.opacity = '0';
  document.body.appendChild(ta);
  ta.select();
  try { document.execCommand('copy'); done(); } catch (e) {}
  ta.remove();
}

/* ---- manual checks (filtered to the categories that were run) ---- */
function renderManual() {
  const card = $('manual');
  card.innerHTML = '';
  const ran = ranLensIds();
  const checks = (report.manualChecks || []).filter(c => !c.lens || !ran.length || ran.includes(c.lens));
  card.appendChild(el('h2', null, 'Manual checks'));
  card.appendChild(el('p', 'manual-sub',
    (isPartial() ? 'Showing only the manual checks for the categories that were run. ' : '') +
    'Things code cannot verify \u2014 tick them off as you review. Your ticks are saved on this computer.'));
  const list = el('ul', 'manual-list');
  const storeKey = 'uxlens-manual-' + report.url;
  let saved = {};
  try { saved = JSON.parse(localStorage.getItem(storeKey) || '{}'); } catch (e) {}
  checks.forEach((check, idx) => {
    const li = el('li', 'manual-item');
    const cb = document.createElement('input');
    cb.type = 'checkbox';
    cb.id = 'mc-' + idx;
    cb.checked = !!saved[check.id];
    if (cb.checked) li.classList.add('checked');
    cb.addEventListener('change', () => {
      saved[check.id] = cb.checked;
      li.classList.toggle('checked', cb.checked);
      try { localStorage.setItem(storeKey, JSON.stringify(saved)); } catch (e) {}
    });
    const label = el('label', null, check.text);
    label.htmlFor = cb.id;
    if (check.hint) label.appendChild(el('span', 'hint', check.hint));
    li.appendChild(cb);
    li.appendChild(label);
    list.appendChild(li);
  });
  card.appendChild(list);

  if (report.shortcuts && report.shortcuts.length && (!ran.length || ran.includes('usability'))) {
    const h = el('div', 'group-head');
    h.appendChild(el('span', null, 'Keyboard shortcuts tested'));
    h.style.padding = '14px 0 4px';
    card.appendChild(h);
    report.shortcuts.forEach((s) => {
      const row = el('div', 'shortcut-row');
      const kbd = document.createElement('kbd'); kbd.textContent = s.shortcut;
      row.appendChild(kbd);
      row.appendChild(el('span', 'badge ' + (s.status === 'reacted' ? 'badge-pass' : 'badge-improve'),
        s.status === 'reacted' ? 'Reacted' : s.status === 'skipped' ? 'Skipped (unsafe)' : 'No reaction'));
      card.appendChild(row);
    });
  }

  const note = el('div', 'config-note');
  if (report.config && report.config.found) {
    note.innerHTML = '<strong>Screen config:</strong> using <code>screen-configs/' + esc(report.config.file) + '</code> \u2014 the config-driven checks ran.';
  } else {
    note.innerHTML = '<strong>Add a screen config to unlock 4 more checks</strong> (forbidden labels, shortcuts, default sort, tab order).<br>' +
      'Save a JSON file in the <code>screen-configs/</code> folder, for example:' +
      '<pre>{\n  "match": "/trades",\n  "forbiddenLabels": [{ "term": "CTPY_ID", "preferred": "Counterparty" }],\n  "shortcuts": ["F8", "Ctrl+C"],\n  "defaultSort": { "column": "Trade Date", "direction": "descending" },\n  "tabOrder": ["Search", "Filters", "Trade grid"]\n}</pre>';
  }
  card.appendChild(note);
}

/* ================================================================ */
/* PATTERN GENERATOR — capture layout as Copilot-readable JSON      */
/* ================================================================ */
async function renderPatterns() {
  const page = $('page-patterns');
  page.innerHTML = '';
  const card = el('div', 'card setup-card');
  card.innerHTML = '<h2>Capture a pattern</h2>' +
    '<p class="setup-sub">Name it, paste the screen URL, click Capture. The layout is extracted into a Copilot-readable JSON file with a screenshot thumbnail. In Copilot, attach the JSON and ask for a layout like the attached pattern.</p>' +
    '<label class="field-label" for="patternName">Pattern name</label>' +
    '<input id="patternName" class="text-input" type="text" placeholder="e.g. Dense trade blotter" style="max-width:420px;margin-bottom:14px">' +
    '<label class="field-label" for="patternUrl">Screen URL</label>' +
    '<div class="url-row"><div class="url-pill"><span class="url-prefix">screen</span>' +
    '<input id="patternUrl" list="patternRecentList" type="text" placeholder="http://localhost:4200/trades" spellcheck="false"></div>' +
    '<datalist id="patternRecentList">' + datalistOptions('pattern', 'audit', 'UX Audit') + '</datalist></div>';
  const btn = el('button', 'btn-primary', 'Capture pattern');
  btn.type = 'button';
  btn.addEventListener('click', capturePattern);
  card.appendChild(btn);
  page.appendChild(card);
  await renderPatternLibrary(page);
}

async function capturePattern() {
  const name = $('patternName').value.trim();
  const url = $('patternUrl').value.trim();
  hideError();
  if (!name) { showError('Give the pattern a short name first.'); return; }
  if (!url) { showError('Paste the URL of the screen to capture.'); return; }
  setLoading('Capturing "' + name + '"…', 'Extracting the layout and taking the screenshot.');
  try {
    const res = await fetch('/api/patterns', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, url })
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || 'Capture failed (' + res.status + ')');
    addRecent('pattern', url);
  } catch (e) {
    showError(e.message.includes('Failed to fetch')
      ? 'Could not reach the UX Workbench server. Start it with "npm start".'
      : e.message);
  } finally {
    $('loading').hidden = true;
    showModule('patterns');
  }
}

async function renderPatternLibrary(page) {
  let patterns = [];
  let offline = false;
  try {
    const res = await fetch('/api/patterns');
    if (res.ok) patterns = await res.json(); else offline = true;
  } catch (e) { offline = true; }
  if (offline) {
    page.appendChild(el('div', 'card ov-card ov-empty', 'The server is not reachable — start UX Workbench with "npm start" to see your pattern library.'));
    return;
  }
  if (!patterns.length) {
    page.appendChild(el('div', 'card ov-card ov-empty', 'No patterns captured yet — your library will appear here.'));
    return;
  }
  const shown = searchQuery ? patterns.filter(p => (p.name + ' ' + (p.url || '')).toLowerCase().includes(searchQuery)) : patterns;
  if (!shown.length) {
    page.appendChild(el('div', 'card ov-card ov-empty', 'No patterns match "' + searchQuery + '".'));
    return;
  }
  const grid = el('div', 'pattern-grid');
  shown.forEach((p) => grid.appendChild(patternCard(p)));
  page.appendChild(grid);
}

function patternCard(p) {
  const card = el('div', 'card pattern-card');
  const img = document.createElement('img');
  img.src = '/patterns/' + p.id + '.png';
  img.alt = p.name;
  card.appendChild(img);
  const body = el('div', 'p-body');
  body.appendChild(el('div', 'p-name', p.name));
  body.appendChild(el('div', 'r-sub', new Date(p.timestamp).toLocaleDateString()));
  const dl = document.createElement('a');
  dl.className = 'btn-primary';
  dl.style.display = 'inline-block';
  dl.style.marginTop = '10px';
  dl.style.padding = '7px 16px';
  dl.style.fontSize = '12px';
  dl.textContent = 'Download JSON';
  dl.href = '/patterns/' + p.id + '.json';
  dl.download = p.id + '.json';
  body.appendChild(dl);
  card.appendChild(body);
  return card;
}

/* ================================================================ */
/* COMPONENT LIBRARY — Storybook sync + browsing + designer notes    */
/* ================================================================ */
let libDetailId = null;  // open component in detail view, or null for the grid
let libSyncTimer = null; // polls sync progress

async function renderLibrary() {
  const page = $('page-library');
  page.innerHTML = '';
  if (libDetailId) { await renderLibraryDetail(page, libDetailId); return; }

  /* sync card */
  const card = el('div', 'card setup-card');
  card.innerHTML = '<h2>Component Library</h2>' +
    '<p class="setup-sub">Syncs your locally running Storybook into the Workbench: every story is rendered in isolation, screenshotted, and measured. Re-syncing updates variants but never touches your usage notes.</p>' +
    '<label class="field-label" for="sbUrl">Storybook URL</label>' +
    '<div class="url-row"><div class="url-pill"><span class="url-prefix">storybook</span>' +
    '<input id="sbUrl" type="text" value="http://localhost:6006" spellcheck="false"></div></div>';
  const row = el('div', 'run-row');
  const btn = el('button', 'btn-primary', 'Sync library');
  btn.type = 'button';
  btn.addEventListener('click', syncLibraryNow);
  row.appendChild(btn);
  row.appendChild(el('span', 'run-hint', 'Start Storybook first (usually "npm run storybook" in your component-library repo).'));
  card.appendChild(row);
  const status = el('div', 'r-sub');
  status.id = 'syncStatus';
  status.style.marginTop = '10px';
  card.appendChild(status);
  page.appendChild(card);

  /* component grid */
  let index = null;
  try {
    const res = await fetch('/api/library');
    if (res.ok) index = await res.json();
  } catch (e) { /* server offline */ }
  if (!index) {
    page.appendChild(el('div', 'card ov-card ov-empty', 'The server is not reachable — start UX Workbench with "npm start" to sync and browse your library.'));
    return;
  }
  const comps = index.components || [];
  if (!comps.length) {
    page.appendChild(el('div', 'card ov-card ov-empty', 'No library synced yet — sync your Storybook above to fill this grid.'));
    return;
  }
  const meta = el('div', 'r-sub', comps.length + ' components · last sync ' + new Date(index.syncedAt).toLocaleString());
  meta.style.margin = '0 0 10px';
  page.appendChild(meta);
  const shown = searchQuery ? comps.filter(c => (c.component + ' ' + c.title + ' ' + (c.tag || '')).toLowerCase().includes(searchQuery)) : comps;
  if (!shown.length) {
    page.appendChild(el('div', 'card ov-card ov-empty', 'No components match "' + searchQuery + '".'));
    return;
  }
  const grid = el('div', 'pattern-grid');
  shown.forEach((c) => {
    const cc = el('button', 'card pattern-card lib-card');
    // detail JSON knows the screenshots; index carries variants without files — fetch lazily via first variant naming convention is not safe, so use the component endpoint on click only. Thumbnail: kebab(storyId).png of first variant is stored in the component file; the index doesn't carry it, so use a generic placeholder box replaced after fetch.
    const img = document.createElement('img');
    img.alt = c.component;
    fetch('/api/library/' + encodeURIComponent(c.id)).then(r => r.ok ? r.json() : null).then((full) => {
      if (full && full.variants && full.variants.length) img.src = '/library/' + full.variants[0].screenshot;
    }).catch(() => {});
    cc.appendChild(img);
    const body = el('div', 'p-body');
    body.appendChild(el('div', 'p-name', c.component));
    body.appendChild(el('div', 'p-url', (c.tag || 'no tag detected') + ' · ' + c.variantCount + ' variant' + (c.variantCount === 1 ? '' : 's')));
    if (!c.hasNotes) body.appendChild(el('div', 'r-sub', 'Needs usage notes'));
    cc.appendChild(body);
    cc.addEventListener('click', () => { libDetailId = c.id; renderLibrary(); });
    grid.appendChild(cc);
  });
  page.appendChild(grid);
}

async function syncLibraryNow() {
  const url = $('sbUrl').value.trim() || 'http://localhost:6006';
  hideError();
  const status = $('syncStatus');
  status.textContent = 'Reading the Storybook index…';
  clearInterval(libSyncTimer);
  libSyncTimer = setInterval(async () => {
    try {
      const p = await fetch('/api/library/sync-status').then(r => r.json());
      if (p.running && p.total) status.textContent = 'Capturing ' + p.done + ' of ' + p.total + ' stories…';
    } catch (e) { /* ignore */ }
  }, 800);
  try {
    const res = await fetch('/api/library/sync', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url })
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || 'Sync failed (' + res.status + ')');
    clearInterval(libSyncTimer);
    let msg = 'Synced ' + data.components + ' components (' + data.variants + ' variants).';
    if (data.skipped && data.skipped.length) {
      msg += ' Skipped ' + data.skipped.length + ' failing stor' + (data.skipped.length === 1 ? 'y' : 'ies') + ': ' +
        data.skipped.slice(0, 5).map(s => s.storyId).join(', ') + (data.skipped.length > 5 ? '…' : '');
    }
    status.textContent = msg;
    renderLibrary();
  } catch (e) {
    clearInterval(libSyncTimer);
    status.textContent = '';
    showError(e.message.includes('Failed to fetch')
      ? 'Could not reach the UX Workbench server. Start it with "npm start".'
      : e.message);
  }
}

async function renderLibraryDetail(page, id) {
  let comp = null;
  try {
    const res = await fetch('/api/library/' + encodeURIComponent(id));
    if (res.ok) comp = await res.json();
  } catch (e) { /* offline */ }
  if (!comp) {
    libDetailId = null;
    page.appendChild(el('div', 'card ov-card ov-empty', 'Could not load this component.'));
    return;
  }
  const card = el('div', 'card setup-card');
  const back = el('button', 'link-btn', '\u2190 All components');
  back.addEventListener('click', () => { libDetailId = null; renderLibrary(); });
  card.appendChild(back);
  const h = el('h2', null, comp.component);
  h.style.marginTop = '8px';
  card.appendChild(h);
  card.appendChild(el('p', 'setup-sub', comp.title + (comp.tag ? ' · <' + comp.tag + '>' : '') + ' · ' + comp.variants.length + ' variant' + (comp.variants.length === 1 ? '' : 's')));

  /* variants side by side with measured values */
  const row = el('div', 'variant-row');
  comp.variants.forEach((v) => {
    const vc = el('div', 'variant-card');
    const img = document.createElement('img');
    img.src = '/library/' + v.screenshot;
    img.alt = v.name;
    vc.appendChild(img);
    vc.appendChild(el('div', 'p-name', v.name));
    const m = v.measured && v.measured.root;
    if (m) {
      vc.appendChild(el('div', 'measured',
        'bg ' + m.backgroundColor + '\ntext ' + m.color + '\nfont ' + m.fontSize + ' ' + m.fontFamily +
        '\nheight ' + m.height + 'px · pad ' + m.padding + '\nradius ' + m.borderRadius));
    }
    row.appendChild(vc);
  });
  card.appendChild(row);

  /* designer notes (never touched by re-sync) */
  const notes = comp.designerNotes || { useWhen: '', doNotUseFor: '', rules: '' };
  const sec = el('div', 'rev-section req');
  const sh = el('h3', null, 'Designer notes');
  sh.appendChild(el('span', 'req-badge', 'Preserved on re-sync'));
  sec.appendChild(sh);
  sec.appendChild(el('p', 'sec-hint', 'These feed pattern JSONs (use-when guidance) and future generation prompts.'));
  const fields = {};
  [['useWhen', 'Use when'], ['doNotUseFor', 'Do not use for'], ['rules', 'Rules']].forEach(([key, label]) => {
    sec.appendChild(el('label', 'field-label', label));
    const t = document.createElement('textarea');
    t.className = 'text-input';
    t.style.marginBottom = '10px';
    t.value = notes[key] || '';
    fields[key] = t;
    sec.appendChild(t);
  });
  const save = el('button', 'btn-primary', 'Save notes');
  save.addEventListener('click', async () => {
    try {
      const res = await fetch('/api/library/' + encodeURIComponent(id) + '/notes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ useWhen: fields.useWhen.value, doNotUseFor: fields.doNotUseFor.value, rules: fields.rules.value })
      });
      if (!res.ok) throw new Error('Save failed');
      save.textContent = 'Saved \u2713';
      setTimeout(() => { save.textContent = 'Save notes'; }, 1800);
    } catch (e) { showError('Could not save the notes: ' + e.message); }
  });
  sec.appendChild(save);
  card.appendChild(sec);
  page.appendChild(card);
}

/* ================================================================ */
/* EXPORT — standalone HTML of the current report                    */
/* ================================================================ */
async function exportReport() {
  if (!report) return;
  const [css, js, page] = await Promise.all([
    fetch('styles.css').then(r => r.text()),
    fetch('app.js').then(r => r.text()),
    fetch('index.html').then(r => r.text())
  ]);
  // Escape "<" so the embedded JSON/JS can never terminate their <script> tags early
  const data = JSON.stringify(report).replace(/</g, '\\u003c');
  const closeTag = '</scr' + 'ipt>'; // built in two parts so this file can embed itself
  const safeJs = js.split(closeTag).join('<\\/scr' + 'ipt>');
  const html = page
    .replace('<link rel="stylesheet" href="styles.css">', '<style>\n' + css + '\n</style>')
    .replace('<script src="app.js">' + closeTag,
      '<script>window.UXLENS_EMBEDDED = ' + data + ';' + closeTag + '\n<script>\n' + safeJs + '\n' + closeTag);
  const blob = new Blob([html], { type: 'text/html' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'ux-audit-report-' + new Date(report.timestamp).toISOString().slice(0, 10) + '.html';
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 5000);
}
