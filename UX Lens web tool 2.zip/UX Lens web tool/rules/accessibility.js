/**
 * rules/accessibility.js — category "Accessibility" (A1–A8).
 *
 * Each rule has:
 *   id / category / severity ('fail' | 'improve') / title / why (one PM-friendly sentence)
 *   engine: 'axe'      → detected by axe-core (analyzer maps results here)
 *           'inpage'   → `detect` runs INSIDE the page via Playwright page.evaluate.
 *                        It may only use the DOM and window.__uxlens helpers.
 *           'analyzer' → needs multi-step browser control; implemented in server/analyzer.js
 *
 * In-page detect functions return: [{ selector, rect, message, data }]
 */

module.exports = [
  {
    id: 'A1', category: 'Accessibility', severity: 'fail',
    title: 'Text contrast below 4.5:1',
    why: 'Low-contrast text is hard to read in bright rooms and fails WCAG AA.',
    engine: 'axe', axeRule: 'color-contrast'
  },

  {
    id: 'A2', category: 'Accessibility', severity: 'fail',
    title: 'Input without a visible label',
    why: 'Placeholders disappear on input — users forget what a filled field means.',
    engine: 'inpage',
    detect: (cfg) => {
      const U = window.__uxlens, out = [];
      const fields = document.querySelectorAll(
        'input:not([type=hidden]):not([type=checkbox]):not([type=radio]):not([type=button]):not([type=submit]), select, textarea');
      fields.forEach((el) => {
        if (!U.isVisible(el)) return;
        // A visible label = <label for>, wrapping <label>, or mat-label style sibling
        let lab = el.id ? document.querySelector('label[for="' + CSS.escape(el.id) + '"]') : null;
        if (!lab) lab = el.closest('label');
        if (!lab) { // Angular Material puts mat-label inside the form field wrapper
          const wrap = el.closest('mat-form-field, .form-field, .form-group, .field');
          if (wrap) lab = wrap.querySelector('mat-label, label');
        }
        const hasVisibleLabel = lab && U.isVisible(lab) && U.text(lab).length > 0;
        if (hasVisibleLabel) return;
        const ph = el.getAttribute('placeholder') || '';
        out.push({
          selector: U.cssPath(el), rect: U.docRect(el),
          message: ph ? 'Placeholder-only label ("' + ph + '")' : 'No visible label',
          data: {
            placeholderNote: ph ? ' (the placeholder "' + ph + '" is being used as the label)' : ''
          }
        });
      });
      return out.slice(0, 15);
    }
  },

  {
    id: 'A3', category: 'Accessibility', severity: 'improve',
    title: 'Text smaller than 12px',
    why: 'Sub-12px text slows scanning and causes misreads of critical figures.',
    engine: 'inpage',
    detect: (cfg) => {
      const U = window.__uxlens, out = [], seen = new Set();
      const all = document.body.querySelectorAll('*');
      for (const el of all) {
        if (out.length >= 15) break;
        // Only elements with their OWN text (not just text in children)
        const own = [...el.childNodes].some(n => n.nodeType === 3 && n.textContent.trim().length > 1);
        if (!own || !U.isVisible(el)) continue;
        const fs = parseFloat(getComputedStyle(el).fontSize);
        if (fs >= 12) continue;
        const sel = U.cssPath(el);
        if (seen.has(sel)) continue;
        seen.add(sel);
        out.push({
          selector: sel, rect: U.docRect(el),
          message: Math.round(fs * 10) / 10 + 'px text: "' + U.text(el).slice(0, 50) + '"',
          data: { fontSize: Math.round(fs * 10) / 10 + 'px' }
        });
      }
      return out;
    }
  },

  {
    id: 'A4', category: 'Accessibility', severity: 'fail',
    title: 'Keyboard focus not visible',
    why: "Keyboard users can't see where they are on the screen.",
    engine: 'analyzer' // Tab-walk: compares focused vs unfocused computed styles
  },

  {
    id: 'A5', category: 'Accessibility', severity: 'fail',
    title: 'Element unreachable by keyboard',
    why: 'Keyboard-first users simply cannot operate this control.',
    engine: 'inpage',
    detect: (cfg) => {
      const U = window.__uxlens, out = [];
      // Clickable-looking elements that are NOT natively focusable and have no tabindex
      const natively = 'a[href],button,input,select,textarea,[contenteditable="true"],audio[controls],video[controls],iframe';
      const cands = document.body.querySelectorAll('[onclick],[role=button],[role=link],[role=menuitem],[role=tab]');
      const extra = [...document.body.querySelectorAll('div,span,td,li,i')].filter(el =>
        getComputedStyle(el).cursor === 'pointer' && !el.querySelector('a,button,input,select,label'));
      const all = new Set([...cands, ...extra]);
      for (const el of all) {
        if (out.length >= 10) break;
        if (!U.isVisible(el)) continue;
        if (el.closest(natively)) continue;           // inside a real control
        if (el.matches(natively)) continue;           // is a real control
        const ti = el.getAttribute('tabindex');
        if (ti !== null && parseInt(ti, 10) >= 0) continue; // focusable via tabindex
        // pointer-cursor on big container elements is usually row hover styling — skip huge ones
        const r = el.getBoundingClientRect();
        if (r.width > 500 && r.height > 200) continue;
        out.push({
          selector: U.cssPath(el), rect: U.docRect(el),
          message: 'Clickable ' + el.tagName.toLowerCase() + ' ("' + (U.text(el).slice(0, 40) || el.getAttribute('aria-label') || 'no text') + '") is not keyboard-focusable',
          data: { elementText: U.text(el).slice(0, 40) || el.getAttribute('aria-label') || el.tagName.toLowerCase() }
        });
      }
      return out;
    }
  },

  {
    id: 'A6', category: 'Accessibility', severity: 'improve',
    title: 'Click target smaller than 24x24px',
    why: 'Small targets cause misclicks — dangerous on trading screens.',
    engine: 'inpage',
    detect: (cfg) => {
      const U = window.__uxlens, out = [];
      const targets = document.querySelectorAll('button, a[href], [role=button], input[type=button], input[type=submit], input[type=checkbox], input[type=radio]');
      for (const el of targets) {
        if (out.length >= 12) break;
        if (!U.isVisible(el)) continue;
        const r = el.getBoundingClientRect();
        if (r.width >= 24 && r.height >= 24) continue;
        if (r.width === 0 || r.height === 0) continue;
        // If a parent label/button provides the real hit area, skip
        const p = el.parentElement && el.parentElement.getBoundingClientRect();
        if (p && p.width >= 24 && p.height >= 24 && (el.closest('label') || el.parentElement.matches('button,[role=button]'))) continue;
        out.push({
          selector: U.cssPath(el), rect: U.docRect(el),
          message: Math.round(r.width) + 'x' + Math.round(r.height) + 'px target ("' + (U.text(el).slice(0, 30) || el.getAttribute('aria-label') || el.type || 'icon') + '")',
          data: {
            width: Math.round(r.width), height: Math.round(r.height),
            elementText: U.text(el).slice(0, 30) || el.getAttribute('aria-label') || 'icon button'
          }
        });
      }
      return out;
    }
  },

  {
    id: 'A7', category: 'Accessibility', severity: 'fail',
    title: 'Page breaks at 150% zoom',
    why: 'Many users work zoomed; sideways scrolling hides data off-screen.',
    engine: 'analyzer' // re-rendered at a 150%-zoom-equivalent viewport
  },

  {
    id: 'A8', category: 'Accessibility', severity: 'improve',
    title: 'Suspected color-only status signal',
    why: "Color-blind users (8% of men) can't distinguish red/green-only signals.",
    engine: 'inpage',
    detect: (cfg) => {
      const U = window.__uxlens, out = [];
      const parse = (c) => { const m = c && c.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/); return m ? [+m[1], +m[2], +m[3]] : null; };
      const strong = (rgb) => {
        if (!rgb) return null;
        const [r, g, b] = rgb;
        if (r > 140 && g < 110 && b < 110) return 'red';
        if (g > 120 && r < 110 && b < 120) return 'green';
        return null;
      };
      const all = document.body.querySelectorAll('*');
      for (const el of all) {
        if (out.length >= 8) break;
        if (el.children.length > 1 || !U.isVisible(el)) continue;
        const r = el.getBoundingClientRect();
        if (r.width > 160 || r.height > 60) continue; // status signals are small
        const s = getComputedStyle(el);
        const hue = strong(parse(s.backgroundColor)) || strong(parse(s.color));
        if (!hue) continue;
        const txt = U.text(el);
        // If the text itself says the status ("Failed", "Settled"), color is not the only cue
        if (/[a-z]{3,}/i.test(txt)) continue;
        // An icon sibling/child also counts as a second cue
        const zone = el.parentElement || el;
        if (zone.querySelector('svg, img, i[class*=icon], mat-icon, .icon')) continue;
        out.push({
          selector: U.cssPath(el), rect: U.docRect(el),
          message: 'Small ' + hue + ' element with no text or icon — possible color-only signal (review manually)',
          data: { color: hue }
        });
      }
      return out;
    }
  }
];
