/**
 * rules/library.js — component-library consistency rules (V1–V2).
 * Active only when a synced Storybook library exists in /library.
 * Their detect functions receive the LIBRARY summary (not the screen config):
 *   { tags: [..], buttons: [..], inputs: [..], grids: [..],
 *     byTag: { "app-button": { component, variants: [{name, measured}] } } }
 */

module.exports = [
  {
    id: 'V1', category: 'Component library', severity: 'improve',
    title: 'Non-library lookalike',
    why: 'Hand-rolled controls drift from the design system and double the maintenance cost.',
    engine: 'library',
    detect: (lib) => {
      const U = window.__uxlens, out = [];
      const libTags = new Set(lib.tags);
      const insideLib = (el) => {
        let n = el;
        while (n && n !== document.body) {
          if (n.tagName && libTags.has(n.tagName.toLowerCase())) return true;
          n = n.parentElement;
        }
        return false;
      };
      const flag = (el, kind, tag) => {
        const label = (U.text(el) || el.value || el.getAttribute('aria-label') || '').slice(0, 30);
        out.push({
          selector: U.cssPath(el), rect: U.docRect(el),
          message: 'Raw <' + el.tagName.toLowerCase() + '>' + (label ? ' ("' + label + '")' : '') + ' — the library has <' + tag + '>',
          data: { kind, tag, elementText: label || kind }
        });
      };
      if (lib.buttons.length) {
        for (const b of document.querySelectorAll('button, input[type=button], input[type=submit], [role=button]')) {
          if (out.length >= 6) break;
          if (!U.isVisible(b) || insideLib(b) || b.tagName.includes('-')) continue;
          flag(b, 'button', lib.buttons[0]);
        }
      }
      if (lib.inputs.length) {
        for (const f of document.querySelectorAll('input:not([type=hidden]):not([type=button]):not([type=submit]):not([type=checkbox]):not([type=radio]), select, textarea')) {
          if (out.length >= 10) break;
          if (!U.isVisible(f) || insideLib(f)) continue;
          flag(f, 'input', lib.inputs[0]);
        }
      }
      if (lib.grids.length) {
        for (const t of document.querySelectorAll('table, [role=grid]')) {
          if (out.length >= 12) break;
          if (!U.isVisible(t) || insideLib(t) || t.tagName.includes('-')) continue;
          flag(t, 'data grid', lib.grids[0]);
        }
      }
      return out;
    }
  },

  {
    id: 'V2', category: 'Component library', severity: 'improve',
    title: 'Off-library styling',
    why: 'Overridden styles silently fork the design system, one screen at a time.',
    engine: 'library',
    detect: (lib) => {
      const U = window.__uxlens, out = [];
      const parse = (c) => { const m = c && c.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/); return m ? [+m[1], +m[2], +m[3]] : null; };
      const near = (a, b, t) => Math.abs(a - b) <= t;
      const colorNear = (c1, c2) => {
        const a = parse(c1), b = parse(c2);
        if (!a || !b) return String(c1) === String(c2);
        return near(a[0], b[0], 6) && near(a[1], b[1], 6) && near(a[2], b[2], 6);
      };
      Object.entries(lib.byTag).forEach(([tag, comp]) => {
        if (!comp.variants || !comp.variants.length) return;
        const els = [...document.querySelectorAll(tag)].filter(U.isVisible).slice(0, 20);
        els.forEach((el) => {
          if (out.length >= 8) return;
          const s = getComputedStyle(el);
          const r = el.getBoundingClientRect();
          const m = { bg: s.backgroundColor, fg: s.color, fs: parseFloat(s.fontSize), h: Math.round(r.height) };
          const matchesSome = comp.variants.some((v) => {
            const vm = v.measured && v.measured.root;
            if (!vm) return true; // nothing measured — can't judge, don't flag
            return colorNear(m.bg, vm.backgroundColor) && colorNear(m.fg, vm.color) &&
              near(m.fs, parseFloat(vm.fontSize) || m.fs, 0.6) && near(m.h, vm.height || m.h, 3);
          });
          if (matchesSome) return;
          out.push({
            selector: U.cssPath(el), rect: U.docRect(el),
            message: '<' + tag + '> matches no approved variant (height ' + m.h + 'px, font ' + m.fs + 'px)',
            data: {
              tag, variant: comp.variants[0].name,
              diff: 'height ' + m.h + 'px, background ' + m.bg + ', text ' + m.fg + ', font ' + m.fs + 'px'
            }
          });
        });
      });
      return out;
    }
  }
];
