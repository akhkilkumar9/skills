/**
 * rules/knowledge.js — category "Screen knowledge" (K1–K4).
 *
 * These rules only run when a screen-config JSON in /screen-configs matches the
 * analyzed URL's path (see README). Findings whose data.unverifiable === true are
 * routed to the Manual checks section instead of the issue list.
 */

module.exports = [
  {
    id: 'K1', category: 'Screen knowledge', severity: 'fail',
    title: 'Forbidden label on screen',
    why: 'Internal jargon confuses users and violates the team glossary.',
    engine: 'inpage', needsConfig: true,
    detect: (cfg) => {
      const U = window.__uxlens, out = [];
      if (!cfg || !Array.isArray(cfg.forbiddenLabels)) return out;
      const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
      const seen = new Set();
      let node;
      while ((node = walker.nextNode()) && out.length < 25) {
        const txt = node.textContent;
        if (!txt.trim()) continue;
        const el = node.parentElement;
        if (!el || !U.isVisible(el)) continue;
        for (const f of cfg.forbiddenLabels) {
          const esc = String(f.term).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
          if (!new RegExp('\\b' + esc + '\\b', 'i').test(txt)) continue;
          const key = f.term + '|' + U.cssPath(el);
          if (seen.has(key)) continue;
          seen.add(key);
          out.push({
            selector: U.cssPath(el), rect: U.docRect(el),
            message: 'Forbidden term "' + f.term + '" — use "' + (f.preferred || '?') + '"',
            data: { term: f.term, preferred: f.preferred || '?', found: txt.trim().slice(0, 80) }
          });
        }
      }
      return out;
    }
  },

  {
    id: 'K2', category: 'Screen knowledge', severity: 'improve',
    title: 'Expected keyboard shortcut has no effect',
    why: 'Legacy users rely on these shortcuts for speed.',
    engine: 'analyzer', needsConfig: true // SAFE-MODE key simulation in server/analyzer.js
  },

  {
    id: 'K3', category: 'Screen knowledge', severity: 'improve',
    title: 'Default sort column differs from spec',
    why: 'Users expect the same default ordering as the legacy screen.',
    engine: 'inpage', needsConfig: true,
    detect: (cfg) => {
      const U = window.__uxlens;
      if (!cfg || !cfg.defaultSort || !cfg.defaultSort.column) return [];
      const want = cfg.defaultSort;
      const sorted = [...document.querySelectorAll('[aria-sort]')]
        .filter(h => ['ascending', 'descending'].includes(h.getAttribute('aria-sort')) && U.isVisible(h));
      if (!sorted.length) {
        return [{
          selector: '', rect: null,
          message: 'K3: could not read the grid\'s sort state (no aria-sort found). Verify the default sort is "' + want.column + '" manually.',
          data: { unverifiable: true }
        }];
      }
      const match = sorted.find(h => U.text(h).toLowerCase().includes(String(want.column).toLowerCase()));
      if (match && (!want.direction || match.getAttribute('aria-sort') === want.direction)) return [];
      const actual = sorted.map(h => '"' + U.text(h) + '" (' + h.getAttribute('aria-sort') + ')').join(', ') || 'no sorted column';
      return [{
        selector: U.cssPath(match || sorted[0]), rect: U.docRect(match || sorted[0]),
        message: 'Expected default sort on "' + want.column + '" ' + (want.direction || '') + ' — found: ' + actual,
        data: { column: want.column, direction: want.direction || 'any direction', actual: actual }
      }];
    }
  },

  {
    id: 'K4', category: 'Screen knowledge', severity: 'fail',
    title: 'Tab order differs from spec',
    why: 'Muscle-memory tab order from the legacy screen must be preserved.',
    engine: 'analyzer', needsConfig: true // uses the analyzer's Tab-walk sequence
  }
];
