/**
 * rules/manual-checks.js — things code cannot verify.
 * Always shown in the report as a checklist the designer ticks off.
 * (Tick state is saved per-URL in the browser's localStorage.)
 * `lens` ties each check to a category so partial audits show only
 * the manual checks for the categories that were run.
 */

module.exports = [
  {
    id: 'M1', lens: 'interaction',
    text: 'Does Enter behave exactly like the legacy screen (advance to next field vs submit)?',
    hint: 'Enter is never simulated for safety — test this by hand.'
  },
  {
    id: 'M2', lens: 'ia',
    text: "Do labels and messages make sense in the users' language?",
    hint: 'Terminology, tone, and translations need a human eye.'
  },
  {
    id: 'M3', lens: 'usability',
    text: 'Loading, error, and no-permission states reviewed with real data?',
    hint: 'Automated checks only see the state the page happened to be in.'
  },
  {
    id: 'M4', lens: 'usability',
    text: 'Are confirmations present on genuinely risky business actions — and absent on high-volume routine actions?',
    hint: 'Only the business knows which actions are risky vs routine.'
  }
];
