/**
 * rules/states.js — category "States" (S1–S2).
 */

module.exports = [
  {
    id: 'S1', category: 'States', severity: 'fail',
    title: 'Blank page during load',
    why: 'A blank screen makes users think the app is broken.',
    engine: 'analyzer' // sampled 200ms after navigation, while requests are in flight
  },

  {
    id: 'S2', category: 'States', severity: 'fail',
    title: 'Empty grid with no empty-state message',
    why: 'An empty grid with no message reads as a bug, not a state.',
    engine: 'inpage',
    detect: (cfg) => {
      const U = window.__uxlens, out = [];
      const EMPTY_MSG = /no (data|results|records|rows|items|trades|matches)|nothing (to|found)|not found|empty|start by|get started/i;
      U.grids().forEach((g) => {
        if (g.rows.length > 0 || !g.headers.length) return;
        // Look for an empty-state message inside the grid or its parent container
        const zone = g.el.parentElement || g.el;
        const hasMsg = [...zone.querySelectorAll('*')].some(el =>
          U.isVisible(el) && el.children.length === 0 && EMPTY_MSG.test(U.text(el)));
        if (hasMsg) return;
        out.push({
          selector: U.cssPath(g.el), rect: U.docRect(g.el),
          message: 'Grid has headers but zero rows and no explanation',
          data: {}
        });
      });
      return out;
    }
  }
];
