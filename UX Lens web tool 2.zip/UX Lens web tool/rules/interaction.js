/**
 * rules/interaction.js — category "Interaction" (I1–I3).
 * I1/I2 need multi-step browser control (SAFE MODE dialog engine in server/analyzer.js).
 */

module.exports = [
  {
    id: 'I1', category: 'Interaction', severity: 'fail',
    title: 'Esc does not close the dialog',
    why: "Esc is the universal 'get me out' — power users expect it.",
    engine: 'analyzer'
  },

  {
    id: 'I2', category: 'Interaction', severity: 'fail',
    title: 'Missing focus trap in modal',
    why: 'Focus escaping a modal lets keyboard users act on hidden content.',
    engine: 'analyzer'
  },

  {
    id: 'I3', category: 'Interaction', severity: 'fail',
    title: 'Destructive button adjacent to primary action',
    why: 'A destructive button beside the primary one invites costly misclicks.',
    engine: 'inpage',
    detect: (cfg) => {
      const U = window.__uxlens, out = [];
      const DESTRUCTIVE = /\b(delete|remove|release|void|terminate|revoke|cancel\s+order|reject)\b/i;
      const parse = (c) => { const m = c && c.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?/); return m ? [+m[1], +m[2], +m[3], m[4] === undefined ? 1 : +m[4]] : null; };
      const btns = [...document.querySelectorAll('button, [role=button], input[type=button], input[type=submit], a.btn, a[class*=button]')]
        .filter(U.isVisible)
        .map(el => {
          const t = (U.text(el) || el.value || el.getAttribute('aria-label') || '').trim();
          const bg = parse(getComputedStyle(el).backgroundColor);
          // "Primary-looking": named primary class, or a saturated solid background
          const sat = bg && bg[3] > 0.5 && (Math.max(bg[0], bg[1], bg[2]) - Math.min(bg[0], bg[1], bg[2])) > 60;
          const primary = /(^|[\s-])(primary|cta|mat-primary|btn-primary|p-button)(?![\w-]*(secondary|text|outline))/i.test(el.className + '') || sat;
          return { el, t, destructive: DESTRUCTIVE.test(t), primary, r: el.getBoundingClientRect() };
        });
      const gap = (a, b) => {
        const yOverlap = Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top);
        const xOverlap = Math.min(a.right, b.right) - Math.max(a.left, b.left);
        if (yOverlap > 0) return Math.max(0, Math.max(a.left - b.right, b.left - a.right)); // side by side
        if (xOverlap > 0) return Math.max(0, Math.max(a.top - b.bottom, b.top - a.bottom)); // stacked
        return Infinity;
      };
      btns.filter(b => b.destructive).forEach((d) => {
        btns.filter(b => b.primary && !b.destructive && b.el !== d.el).forEach((p) => {
          const g = gap(d.r, p.r);
          if (g >= 16 || out.length >= 6) return;
          out.push({
            selector: U.cssPath(d.el), rect: U.docRect(d.el),
            message: '"' + d.t + '" is ' + Math.round(g) + 'px from primary "' + p.t + '"',
            data: { destructiveText: d.t, primaryText: p.t, gap: Math.round(g) }
          });
        });
      });
      return out;
    }
  }
];
