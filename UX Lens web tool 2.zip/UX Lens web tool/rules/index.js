/**
 * rules/index.js — the rule registry.
 *
 * Every rule from every module, plus the five LENSES the tool is organized by.
 * Each rule keeps its technical `category` (where it lives in the code) and is
 * assigned to exactly one LENS (how designers think about it in the UI).
 */

const all = [
  ...require('./accessibility'),
  ...require('./tables'),
  ...require('./interaction'),
  ...require('./states'),
  ...require('./knowledge'),
  ...require('./library')
];

/* The five lenses — run all of them, or any one on its own. */
const LENSES = [
  { id: 'usability',     name: 'Usability Heuristics',     tagline: 'Is it intuitive and easy to use?' },
  { id: 'ia',            name: 'Information Architecture', tagline: 'Is information organized and easy to find?' },
  { id: 'hierarchy',     name: 'Visual Hierarchy',         tagline: 'Is the right information and action emphasized?' },
  { id: 'interaction',   name: 'Interaction Design',       tagline: 'Are actions, states, and feedback clear?' },
  { id: 'accessibility', name: 'Accessibility',            tagline: 'Can users with different abilities use it effectively?' }
];

/* Which lens each rule belongs to. */
const LENS_OF = {
  // Usability heuristics: system status, recognition, error prevention, efficiency
  S1: 'usability', S2: 'usability', I3: 'usability', K2: 'usability',
  // Information architecture: terminology, orientation, ordering
  K1: 'ia', K3: 'ia', T5: 'ia', T6: 'ia',
  // Visual hierarchy: what the eye can compare and read in dense grids
  T1: 'hierarchy', T2: 'hierarchy', T3: 'hierarchy', T4: 'hierarchy',
  // Component-library consistency (active only when a library is synced)
  V1: 'hierarchy', V2: 'hierarchy',
  // Interaction design: dialogs, focus flow, keyboard paths
  I1: 'interaction', I2: 'interaction', K4: 'interaction',
  // Accessibility: WCAG-grounded checks
  A1: 'accessibility', A2: 'accessibility', A3: 'accessibility', A4: 'accessibility',
  A5: 'accessibility', A6: 'accessibility', A7: 'accessibility', A8: 'accessibility'
};
all.forEach((r) => { r.lens = LENS_OF[r.id]; });

const byId = Object.fromEntries(all.map(r => [r.id, r]));
const inPage = all.filter(r => r.engine === 'inpage');

module.exports = { all, byId, inPage, LENSES, LENS_OF, manualChecks: require('./manual-checks') };
