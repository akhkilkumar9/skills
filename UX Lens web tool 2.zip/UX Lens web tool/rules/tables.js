/**
 * rules/tables.js — category "Tables & density" (T1–T6).
 * Aimed at dense financial data grids (native <table>, ag-Grid, Material table, ARIA grids).
 * Grid discovery lives in window.__uxlens.grids() / .columns() (see server/inpage-helpers.js).
 */

module.exports = [
  {
    id: 'T1', category: 'Tables & density', severity: 'improve',
    title: 'Numeric column not right-aligned',
    why: "Left-aligned numbers can't be compared by magnitude at a glance.",
    engine: 'inpage',
    detect: (cfg) => {
      const U = window.__uxlens, out = [];
      U.grids().forEach((g) => {
        U.columns(g).forEach((col) => {
          const vals = col.cells.map(c => U.text(c)).filter(Boolean);
          if (vals.length < 3) return;
          const numeric = vals.filter(v => U.isNumeric(v)).length;
          if (numeric / vals.length <= 0.8) return; // spec: >80% of cells parse as numbers
          const cell = col.cells.find(c => U.text(c));
          const ta = getComputedStyle(cell).textAlign;
          if (ta === 'right' || ta === 'end') return;
          out.push({
            selector: U.cssPath(cell), rect: U.docRect(col.header || cell),
            message: 'Numeric column "' + col.name + '" is ' + (ta || 'left') + '-aligned',
            data: { columnName: col.name, align: ta || 'left' }
          });
        });
      });
      return out.slice(0, 10);
    }
  },

  {
    id: 'T2', category: 'Tables & density', severity: 'improve',
    title: 'Numeric column not using tabular figures',
    why: 'Without tabular figures, digits have uneven widths and rows misalign.',
    engine: 'inpage',
    detect: (cfg) => {
      const U = window.__uxlens, out = [];
      U.grids().forEach((g) => {
        U.columns(g).forEach((col) => {
          const vals = col.cells.map(c => U.text(c)).filter(Boolean);
          if (vals.length < 3) return;
          if (vals.filter(v => U.isNumeric(v)).length / vals.length <= 0.8) return;
          const cell = col.cells.find(c => U.text(c));
          const s = getComputedStyle(cell);
          const tabular = /tabular-nums/.test(s.fontVariantNumeric) || /["']tnum["']/.test(s.fontFeatureSettings)
            || /mono/i.test(s.fontFamily); // monospace fonts are inherently tabular
          if (tabular) return;
          out.push({
            selector: U.cssPath(cell), rect: U.docRect(col.header || cell),
            message: 'Numeric column "' + col.name + '" uses proportional digits',
            data: { columnName: col.name }
          });
        });
      });
      return out.slice(0, 10);
    }
  },

  {
    id: 'T3', category: 'Tables & density', severity: 'improve',
    title: 'Truncated cell values',
    why: 'Truncated values can be misread as different (smaller) numbers.',
    engine: 'inpage',
    detect: (cfg) => {
      const U = window.__uxlens, out = [];
      U.grids().forEach((g) => {
        g.rows.slice(0, 80).forEach((row) => {
          g.cellsOf(row).forEach((cell) => {
            if (out.length >= 10) return;
            // The overflowing element may be the cell or an inner value wrapper
            const nodes = [cell, ...[...cell.children].slice(0, 2)];
            const ov = nodes.find(n => n.scrollWidth > n.clientWidth + 2 && /hidden|clip/.test(getComputedStyle(n).overflowX));
            if (!ov) return;
            out.push({
              selector: U.cssPath(cell), rect: U.docRect(cell),
              message: 'Truncated: "' + U.text(cell).slice(0, 40) + '…"',
              data: { content: U.text(cell).slice(0, 60) }
            });
          });
        });
      });
      return out;
    }
  },

  {
    id: 'T4', category: 'Tables & density', severity: 'improve',
    title: 'Low data density (fewer than 15 rows visible)',
    why: 'Fewer visible rows means more scrolling and slower workflows.',
    engine: 'inpage',
    detect: (cfg) => {
      const U = window.__uxlens;
      const gs = U.grids().filter(g => g.rows.length > 0);
      if (!gs.length) return [];
      // "Main" grid = the one covering the most area
      const main = gs.map(g => ({ g, area: g.el.getBoundingClientRect().width * g.el.getBoundingClientRect().height }))
        .sort((a, b) => b.area - a.area)[0];
      if (main.area < innerWidth * innerHeight * 0.15) return []; // not a main grid
      const g = main.g;
      const visible = g.rows.filter(r => { const b = r.getBoundingClientRect(); return b.bottom > 0 && b.top < innerHeight && b.height > 0; });
      if (visible.length >= 15) return [];
      if (g.rows.length < 15 && visible.length === g.rows.length) return []; // there just isn't more data
      const avgH = Math.round(visible.reduce((s, r) => s + r.getBoundingClientRect().height, 0) / (visible.length || 1));
      return [{
        selector: U.cssPath(g.el), rect: U.docRect(g.el),
        message: 'Only ' + visible.length + ' rows visible (row height ≈ ' + avgH + 'px)',
        data: { rowsVisible: visible.length, rowHeight: avgH }
      }];
    }
  },

  {
    id: 'T5', category: 'Tables & density', severity: 'improve',
    title: 'Table header not sticky on scroll',
    why: 'Without a sticky header, users lose track of what columns mean.',
    engine: 'inpage',
    detect: (cfg) => {
      const U = window.__uxlens, out = [];
      U.grids().forEach((g) => {
        if (!g.headers.length || g.rows.length < 5) return;
        const h = g.headers[0];
        // Sticky if the header cell or a close ancestor is sticky/fixed…
        let node = h, sticky = false;
        for (let i = 0; i < 4 && node; i++) {
          const p = getComputedStyle(node).position;
          if (p === 'sticky' || p === 'fixed') { sticky = true; break; }
          node = node.parentElement;
        }
        // …or the header lives OUTSIDE the row scroller (ag-Grid style)
        let scroller = g.rows[0].parentElement;
        while (scroller && scroller !== document.body) {
          const s = getComputedStyle(scroller);
          if (/(auto|scroll)/.test(s.overflowY) && scroller.scrollHeight > scroller.clientHeight + 10) break;
          scroller = scroller.parentElement;
        }
        const separate = scroller && scroller !== document.body && !scroller.contains(h);
        // If nothing scrolls at all (short grid), the check is moot
        const pageScrolls = document.documentElement.scrollHeight > innerHeight + 40;
        const gridScrolls = scroller && scroller !== document.body;
        if (sticky || separate || (!pageScrolls && !gridScrolls)) return;
        out.push({
          selector: U.cssPath(g.el), rect: U.docRect(h),
          message: 'Header scrolls away with the rows',
          data: {}
        });
      });
      return out;
    }
  },

  {
    id: 'T6', category: 'Tables & density', severity: 'improve',
    title: 'No visible sort indicator',
    why: "Users can't tell how the data is ordered.",
    engine: 'inpage',
    detect: (cfg) => {
      const U = window.__uxlens, out = [];
      U.grids().forEach((g) => {
        if (!g.headers.length || g.rows.length < 5) return;
        const sorted = g.headers.some(h =>
          ['ascending', 'descending'].includes(h.getAttribute('aria-sort')) ||
          /(^|[\s-])(sorted|sort-asc|sort-desc|asc\b|desc\b)/.test(h.className + '') ||
          h.querySelector('[class*=sort-icon], [class*=sort-indicator], .ag-sort-indicator-icon'));
        if (sorted) return;
        out.push({
          selector: U.cssPath(g.el), rect: U.docRect(g.headers[0]),
          message: 'No aria-sort or sort indicator found on any column header',
          data: {}
        });
      });
      return out;
    }
  }
];
