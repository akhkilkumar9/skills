/**
 * fix-prompts.js — one Copilot-ready prompt template per rule.
 *
 * Placeholders like {selector} are filled with REAL values found on the page
 * by templates.fill(ruleId, data). No AI writes these — they are plain strings.
 */

const TEMPLATES = {
  A1: `In the Angular component for this screen, the text at selector "{selector}" has a contrast ratio of {ratio}:1 ({fg} on {bg}), below the WCAG AA minimum of 4.5:1. Adjust the text or background color to reach at least 4.5:1 while staying close to the current palette. Do not change font size, weight, or layout.`,

  A2: `The form field at selector "{selector}" has no visible label{placeholderNote}. Add a visible <label> (or mat-label) associated with the field via for/id, positioned above the field. Keep the placeholder only as an example value, never as the label. Do not change the field's behavior.`,

  A3: `The text at selector "{selector}" is {fontSize} — below the 12px minimum for dense data screens. Increase it to at least 12px, keeping the type hierarchy consistent with sibling text. Do not change layout or truncate content.`,

  A4: `The focusable element at selector "{selector}" ({elementText}) shows no visible change when it receives keyboard focus. Add a clearly visible focus style via :focus-visible, e.g. outline: 2px solid the app's focus color with outline-offset: 2px. Apply it consistently to all interactive elements on this screen.`,

  A5: `The clickable element at selector "{selector}" ({elementText}) cannot be reached with the keyboard. If it is a custom control, add tabindex="0", an appropriate role, and a keydown handler for Enter/Space — or better, replace it with a native <button>. Do not change its visual appearance.`,

  A6: `The click target at selector "{selector}" ({elementText}) is {width}x{height}px — below the 24x24px minimum. Increase its clickable area to at least 24x24px (padding or min-width/min-height on the interactive element itself) without shifting surrounding layout.`,

  A7: `At 150% browser zoom this screen overflows horizontally ({scrollWidth}px of content in a {clientWidth}px viewport), forcing sideways scrolling. Make the layout reflow at higher zoom: use flexible widths (%, fr, minmax), let the main grid scroll inside its own container, and avoid fixed pixel widths on page-level containers.`,

  A8: `The element at selector "{selector}" appears to signal status using color alone ({color}). Add a non-color cue: an icon plus a text label or tooltip, so the state is understandable to color-blind users. Keep the existing colors.`,

  T1: `In the Angular component for this screen, the numeric column "{columnName}" (selector: {selector}) is {align}-aligned. Right-align it and apply font-variant-numeric: tabular-nums. Apply the same to all numeric columns. Do not change column order or row heights.`,

  T2: `The numeric column "{columnName}" (selector: {selector}) does not use tabular figures, so digits have uneven widths and misalign vertically. Apply font-variant-numeric: tabular-nums (or font-feature-settings: "tnum") to all numeric cells in this grid. Do not change fonts or sizes otherwise.`,

  T3: `Cell values in this grid are truncated (example: selector {selector}, content "{content}"). Give affected columns enough width, and add a tooltip with the full value on hover (title attribute or matTooltip). Keep text-overflow: ellipsis as the visual treatment. Do not reduce font size.`,

  T4: `The main data grid on this screen shows only {rowsVisible} rows in the viewport (row height ≈ {rowHeight}px). Users of dense financial grids need at least 15 visible rows. Reduce vertical padding in cells and the header, target a row height of ~28-32px, and remove non-essential vertical whitespace above the grid. Do not remove columns.`,

  T5: `The header of the grid at selector "{selector}" scrolls out of view with the rows. Make it sticky: position: sticky; top: 0 on the header row (with an opaque background and a z-index above the rows), or enable the grid library's fixed-header option. Do not change column widths.`,

  T6: `No visible sort indicator was detected on the grid at selector "{selector}". Add aria-sort="ascending"/"descending" to the sorted column header and render a visible arrow icon in it. Ensure clicking a header updates both the order and the indicator.`,

  I1: `The dialog at selector "{selector}" does not close when Escape is pressed. Wire the Escape key to the same handler as the Cancel/Close button (e.g. Angular Material MatDialog's escape handling or (keydown.escape)). Do not change what closing does.`,

  I2: `Keyboard focus escapes the open dialog at selector "{selector}" while tabbing. Trap focus inside the dialog while it is open (e.g. cdkTrapFocus from @angular/cdk/a11y) and return focus to the triggering element when it closes.`,

  I3: `The destructive button "{destructiveText}" (selector: {selector}) sits only {gap}px from the primary action "{primaryText}". Separate them by at least 16px, or move the destructive action to the opposite side or into an overflow menu. Style it as a danger/secondary variant, never adjacent to and matching the primary.`,

  S1: `This screen shows a blank page during its first moments while data loads. Render the page shell (header, grid frame) immediately and show skeleton rows or a spinner inside the grid area until data arrives, so users never see an empty white page.`,

  S2: `The data grid at selector "{selector}" renders zero rows with no message. Add an empty state inside the grid area: one short line explaining why it is empty and what to do next (e.g. "No trades match your filters — clear filters"). Keep the header row visible.`,

  K1: `The screen shows the forbidden label "{term}" (selector: {selector}, text: "{found}"). Replace it with the approved term "{preferred}" everywhere on this screen, including column headers, tooltips, and messages. Only change user-visible text, never code identifiers.`,

  K2: `The expected keyboard shortcut {shortcut} produced no detectable reaction on this screen. Implement it as specified by the design team, show it in a tooltip on the related control, and call preventDefault to suppress the browser default. If it is already implemented, verify it manually.`,

  K3: `This screen should open sorted by "{column}" ({direction}). It currently shows: {actual}. Set the grid's default sort to "{column}" {direction} and reflect it with aria-sort and a visible arrow on that column header.`,

  K4: `The keyboard tab order on this screen does not match the spec. Expected order: {expected}. Observed: {found}. First mismatch at step {step}. Reorder the DOM (preferred) or set tabindex so Tab moves through fields in the specified order.`,

  V1: `Replace this custom {kind} (selector {selector}) with <{tag}> from the component library; keep its label ("{elementText}"), behavior, and position unchanged.`,

  V2: `The <{tag}> at selector {selector} is styled off-library ({diff}). Remove the local style overrides so it matches an approved variant (e.g. '{variant}') from the component library. Do not change its behavior or position.`
};

/** Replace {placeholders} with real values; unknown keys are left visible so gaps are obvious. */
function fill(ruleId, data) {
  const t = TEMPLATES[ruleId];
  if (!t) return '';
  return t.replace(/\{(\w+)\}/g, (m, k) => (data && data[k] !== undefined && data[k] !== null) ? String(data[k]) : m);
}

module.exports = { TEMPLATES, fill };
