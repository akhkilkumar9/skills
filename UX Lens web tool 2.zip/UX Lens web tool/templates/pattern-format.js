/**
 * templates/pattern-format.js — builds the saved pattern JSON file.
 *
 * The JSON is written for Copilot: attach the file and ask for "a layout like
 * this pattern" — the copilot_instructions field tells it to recreate the
 * regions, component order, and grid characteristics exactly.
 */

function kebab(name) {
  return String(name).toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 60) || 'pattern';
}

/** Turn a measured zone into an ordered component list. */
function zoneComponents(zone) {
  const out = [];
  (zone.buttons || []).forEach((label) => out.push({ type: 'button', label }));
  for (let i = 0; i < (zone.searches || 0); i++) out.push({ type: 'search-field' });
  (zone.fields || []).forEach((label) => out.push({ type: 'input-field', label }));
  return out;
}

function buildPatternJson(name, x, library) {
  const z = x.zones || {};
  const libByTag = {};
  if (library && library.components) {
    library.components.forEach((c) => { if (c.tag) libByTag[c.tag] = c; });
  }
  const regions = ['top', 'left', 'center', 'right', 'bottom'];
  const gridZone = regions.find(r => z[r] && z[r].hasGrid) || 'center';
  const layout = {};
  regions.forEach((r) => {
    const components = zoneComponents(z[r] || {});
    if (x.grid && r === gridZone) {
      components.unshift({
        type: 'data-grid',
        columns: x.grid.columnNames || [],
        columns_visible: x.grid.columnsVisible,
        row_height_px: x.grid.rowHeight,
        sticky_header: !!x.grid.stickyHeader,
        sort_indicators: !!x.grid.sortIndicators,
        row_selection: x.grid.selectionMode || 'none',
        row_actions: x.grid.rowActions || []
      });
    }
    if (x.detailPanel && x.detailPanel.exists && r === 'right') {
      components.unshift({
        type: 'detail-panel',
        populated_by: 'row selection',
        sections: x.detailPanel.sections || []
      });
    }
    layout[r] = { components };
  });
  return JSON.stringify({
    $schema: 'ux-workbench-pattern/v1',
    pattern: kebab(name),
    name,
    captured_from: x.url || '',
    captured_on: (x.capturedOn || new Date().toISOString()).slice(0, 10),
    copilot_instructions: 'This file describes a reference screen layout. When asked to build a screen "like this pattern", recreate this layout EXACTLY: the same regions (top/left/center/right/bottom), the same component types in the same order and placement, and the same grid characteristics (visible column count, row height, sticky header, sort indicators, row selection). Reuse the components listed in components_used where the project already has them. Use the project\'s own design tokens, styling, and real data fields — the labels in this file are examples from the reference screen, not required text.',
    viewport: { width: 1440, height: 900 },
    layout,
    components_used: (x.components || []).map((c) => ({
      tag: c.tag, count: c.count,
      in_library: libByTag[c.tag] ? true : false,
      status: libByTag[c.tag] ? 'in library \u2713' : 'unknown \u26a0'
    })),
    library_guidance: (x.components || [])
      .filter(c => libByTag[c.tag] && libByTag[c.tag].useWhen)
      .map(c => ({ tag: c.tag, component: libByTag[c.tag].component, use_when: libByTag[c.tag].useWhen }))
  }, null, 2);
}

module.exports = { kebab, buildPatternJson };
