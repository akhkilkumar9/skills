/**
 * templates/pattern-prompts.js — the generation-prompt template for captured
 * patterns. Plain string templates, filled with real values — no AI writes these.
 */

const TEMPLATE = `Use the captured UI pattern "{name}" as the visual and structural reference (source screen: {url}, captured {date} — see the attached screenshot).

Build the new Angular component to match this pattern:
- Same layout structure, spacing rhythm, and alignment
- Same interaction affordances (buttons, inputs, table behaviors) in the same positions
- Use OUR design tokens, component library, and naming conventions — do not invent new colors or fonts
- Do not copy the text content verbatim; use our real labels and data bindings

List any deviations you make from the pattern and why.`;

function fill(pattern) {
  return TEMPLATE
    .replace(/\{name\}/g, pattern.name)
    .replace(/\{url\}/g, pattern.url)
    .replace(/\{date\}/g, new Date(pattern.timestamp).toLocaleDateString());
}

module.exports = { TEMPLATE, fill };
